﻿Imports System.Data.OleDb
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Public Class ADMentry
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"
    Dim con, con1, con2, con3, con4 As New OleDbConnection(connectionString)
    Dim adapter As New OleDbDataAdapter()
    Dim str, str0, str1, str2, str3, str4 As String
    Dim com, com0, com1, com2, com3, com4 As OleDbCommand
    Dim oledbda As OleDbDataAdapter
    Dim ds, ds1, ds2, ds3, ds4 As DataSet
    Dim dt As New DataTable
    Dim invdt As String
    Dim cmdOLEDB As New OleDbCommand
    Public dr As OleDbDataReader
    Dim da As OleDb.OleDbDataAdapter
    Dim totadm, totexp, totbal, totpend As Int64
    Dim rowno, wono, rt, itro, rwno As Integer
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboDiv.DropDownStyle = ComboBoxStyle.DropDownList
        ComboBox2.DropDownStyle = ComboBoxStyle.DropDownList
        ComboMPMLA.DropDownStyle = ComboBoxStyle.DropDownList
        ComboFdNm.DropDownStyle = ComboBoxStyle.DropDownList
        ComboAgrYr.DropDownStyle = ComboBoxStyle.DropDownList

        'GroupBox1.Enabled = True
        GroupBox2.Enabled = True
        GroupBox3.Enabled = False
        GroupBox4.Enabled = False

        ComboDiv.SelectedIndex = 0
        ComboBox2.SelectedIndex = 0
        ComboAgrYr.SelectedIndex = 0

        dateadm.Value = Today()

        con.Open()
        rowno = 1
        totadm = 0
        wono = 0
        rt = 1

        str = "select Distinct MPMLA_Name from MP_MLA"
        com = New OleDbCommand(str, con)
        oledbda = New OleDbDataAdapter(com)
        ds = New DataSet
        oledbda.Fill(ds, "MP_MLA")
        ComboMPMLA.DataSource = ds.Tables("MP_MLA")
        ComboMPMLA.ValueMember = "MPMLA_Name"
        ComboMPMLA.DisplayMember = "MPMLA_Name"
        ComboMPMLA.Focus()

        str0 = "select Distinct Fund_Name from FundHead"
        com0 = New OleDbCommand(str0, con)
        oledbda = New OleDbDataAdapter(com0)
        ds = New DataSet
        oledbda.Fill(ds, "FundHead")
        ComboFdNm.DataSource = ds.Tables("FundHead")
        ComboFdNm.ValueMember = "Fund_Name"
        ComboFdNm.DisplayMember = "Fund_Name"
        ComboFdNm.Focus()

    End Sub
    Private Sub ComboFdNm_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboFdNm.SelectionChangeCommitted

        str = "select * from FundHead where Fund_Name='" & ComboFdNm.SelectedValue & "' "
        com = New OleDbCommand(str, con)
        dr = com.ExecuteReader
        While dr.Read()
            txtfundhd.Text = dr("Govt_Fund_Head").ToString
            txtfundhdm.Text = dr("Mhada_Fund_Head").ToString
        End While

    End Sub

    Private Sub TextTotAdmAmt_PreviewKeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.PreviewKeyDownEventArgs) Handles TextTotAdmAmt.PreviewKeyDown
        If e.KeyCode = Keys.Enter Then
            Call ButtonSubmit_Click(sender, e)
        End If

    End Sub
    Private Sub TextTotAdmAmt_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextTotAdmAmt.TextChanged
        If IsNumeric(txtadmamt.Text) And Val(txtadmamt.Text) <> 0 Then
            Exit Sub
        Else
            txtadmamt.Text = ""
            txtadmamt.Focus()
        End If
    End Sub
    Private Sub TextNoWork_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextNoWork.TextChanged
        If IsNumeric(TextNoWork.Text) And Val(TextNoWork.Text) <> 0 Then
            Exit Sub
        Else
            TextNoWork.Text = ""
            TextNoWork.Focus()
        End If
    End Sub
    Private Sub ButtonSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSubmit.Click
        If ComboDiv.SelectedItem.ToString = String.Empty Then
            MsgBox("Please Select Division Name.")
            ComboDiv.Focus()
        ElseIf ComboMPMLA.SelectedValue.ToString = String.Empty Then
            MsgBox("Please Select MP/MLA Name.")
            ComboMPMLA.Focus()
        ElseIf ComboFdNm.SelectedValue.ToString = String.Empty Then
            MsgBox("Please Select Fund Name.")
            ComboFdNm.Focus()
        ElseIf txtadmno.Text = String.Empty Then
            MsgBox("Please enter ADM Number.")
            txtadmno.Focus()
        ElseIf TextNoWork.Text = String.Empty Then
            MsgBox("Please enter Number of Works.")
            TextNoWork.Focus()
        ElseIf TextTotAdmAmt.Text = String.Empty Then
            MsgBox("Please enter Total ADM Amount.")
            TextTotAdmAmt.Focus()
        Else

            totadm = Val(TextNoWork.Text)
            wono = Val(TextTotAdmAmt.Text)

            GroupBox2.Enabled = False
            GroupBox3.Enabled = True
            GroupBox4.Enabled = True

            Textsubtot.Text = Val(Textsubtot.Text) + Val(txtadmamt.Text)
        End If
        txtgpno.Focus()

    End Sub
    Private Sub txtadmamt_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtadmamt.TextChanged
        If IsNumeric(txtadmamt.Text) And Val(txtadmamt.Text) <> 0 Then
            If (Val(txtadmamt.Text) + Val(Textsubtot.Text)) > Val(TextTotAdmAmt.Text) Then
                MsgBox("ADM amount is High.")
                txtadmamt.Focus()
            End If
            Exit Sub
        Else
            txtadmamt.Text = ""
            txtadmamt.Focus()
        End If
    End Sub
    Private Sub AddItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddItem.Click
        If rowno <= totadm Then
            If txtgpno.Text = String.Empty Then
                MsgBox("Enter GP No.")
                txtgpno.Focus()
            ElseIf txtadmamt.Text = String.Empty Then
                MsgBox("Enter ADM Amount")
                txtadmamt.Focus()
            ElseIf TextB1no.Text = String.Empty Then
                MsgBox("Please enter B1 Number.")
                TextB1no.Focus()
            ElseIf ComboAgrYr.SelectedItem.ToString = String.Empty Then
                MsgBox("Please Select Agreement Year.")
                ComboAgrYr.Focus()
            ElseIf txtwrknm.Text = String.Empty Then
                MsgBox("Please Enter Work Name.")
                txtwrknm.Focus()
            Else
                Textsubtot.Text = Val(Textsubtot.Text) + Val(txtadmamt.Text)
                ListBox1.Items.Add(rowno)
                ListBox2.Items.Add(txtgpno.Text)
                ListBox3.Items.Add(txtwrknm.Text)
                ListBox4.Items.Add(TextB1no.Text)
                ListBox5.Items.Add(ComboAgrYr.SelectedItem.ToString)
                ListBox6.Items.Add(Val(txtadmamt.Text))
                rowno = rowno + 1
                txtgpno.Text = ""
                txtwrknm.Text = ""
                TextB1no.Text = ""
                If rowno = totadm Then
                    txtadmamt.Text = Val(TextTotAdmAmt.Text) - Val(Textsubtot.Text)
                    txtadmamt.Enabled = False
                Else
                    txtadmamt.Text = ""
                End If

                txtgpno.Focus()
                If rowno > totadm Then
                    GroupBox3.Enabled = False
                    GroupBox4.Enabled = False
                    ButtonSv.Enabled = True
                    MsgBox("Number of works are completed.")
                    Exit Sub
                End If
            End If
        Else
            GroupBox3.Enabled = False
            GroupBox4.Enabled = False
            ButtonSv.Enabled = True
            MsgBox("Number of works are completed.")
            Exit Sub
        End If

    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSv.Click
        If Val(TextTotAdmAmt.Text) = Val(Textsubtot.Text) Then

            Dim itemrow, totitem As Integer
            itemrow = 0
            totitem = ListBox2.Items.Count

            For itemrow = 0 To totitem - 1 Step 1
                Dim RowofText As String
                Dim rt As Integer
                Dim aryTextFile() As String
                RowofText = ListBox2.Items(itemrow).ToString

                aryTextFile = RowofText.Split(",")

                For rt = 0 To UBound(aryTextFile)
                    rwno = itemrow
                    Dim da As New OleDbDataAdapter
                    da = New OleDbDataAdapter("SELECT * FROM Testing", con)
                    da.Fill(dt)
                    Dim newRow As DataRow = dt.NewRow

                    newRow.Item("Div_Name") = ComboDiv.SelectedItem.ToString()
                    newRow.Item("MP_MLA_MLC") = ComboMPMLA.SelectedValue
                    newRow.Item("Fund_Name") = ComboFdNm.SelectedValue
                    newRow.Item("Govt_Fund_Head") = txtfundhd.Text
                    newRow.Item("Mhada_Fund_Head") = txtfundhdm.Text
                    newRow.Item("ADM_Year") = ComboBox2.SelectedItem.ToString()

                    newRow.Item("ADM_No") = txtadmno.Text
                    newRow.Item("Adm_Date") = dateadm.Value
                    newRow.Item("GP_No") = ListBox2.Items(itemrow).ToString
                    newRow.Item("Work_Name") = ListBox3.Items(itemrow).ToString
                    newRow.Item("B1_No") = ListBox4.Items(itemrow).ToString
                    newRow.Item("Agreement_Year") = ListBox5.Items(itemrow).ToString
                    newRow.Item("Adm_Amt") = ListBox6.Items(itemrow).ToString
                    'newRow.Item("created") = Now()
                    'newRow.Item("CreateBy") = "Admin"

                    dt.Rows.Add(newRow)
                    Dim cb As New OleDbCommandBuilder(da)
                    da.Update(dt)

                    itro = itemrow
                Next rt
            Next

            Dim result = MessageBox.Show("Entry successfully Done. Do you want to Continue ? ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If result = DialogResult.No Then
                con.Close()
                Me.Close()
            ElseIf result = DialogResult.Yes Then
                ButtonSv.Enabled = False
                Call ButtonResetADM_Click(sender, e)
            End If
        Else
            MsgBox("Total ADM Amount is not match with all ADM Amount.", vbCritical, "ADM Details")
        End If
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        con.Close()
        Me.Close()
    End Sub
    Private Sub ButtonResetADM_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonResetADM.Click
        'GroupBox1.Enabled = True
        GroupBox2.Enabled = True
        txtadmno.Text = ""
        TextNoWork.Text = ""
        TextTotAdmAmt.Text = ""

        txtgpno.Text = ""
        txtwrknm.Text = ""
        TextB1no.Text = ""
        txtadmamt.Text = ""
        Textsubtot.Text = ""
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
        ListBox3.Items.Clear()
        ListBox4.Items.Clear()
        ListBox5.Items.Clear()
        ListBox6.Items.Clear()

        GroupBox3.Enabled = False
        GroupBox4.Enabled = False

        rowno = 1
        totadm = 0
        wono = 0
        rt = 1

    End Sub
    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        txtgpno.Text = ""
        txtwrknm.Text = ""
        TextB1no.Text = ""
        txtadmamt.Text = ""
        Textsubtot.Text = ""
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
        ListBox3.Items.Clear()
        ListBox4.Items.Clear()
        ListBox5.Items.Clear()
        ListBox6.Items.Clear()

        rowno = 1

        GroupBox3.Enabled = True
        GroupBox4.Enabled = True

    End Sub

    Private Sub txtwrknm_PreviewKeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.PreviewKeyDownEventArgs) Handles txtwrknm.PreviewKeyDown
        If e.KeyCode = Keys.Enter Then
            Call AddItem_Click(sender, e)
        End If

    End Sub

    Private Sub txtwrknm_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtwrknm.TextChanged

    End Sub
End Class