﻿Imports System.Data.OleDb

Public Class EEAdd
    Dim con As New OleDbConnection
    Dim cmdOLEDB As New OleDbCommand

    Private Sub AddEE_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'MhadaDataSet2.EElist' table. You can move, or remove it, as needed.
        Me.EElistTableAdapter.Fill(Me.MhadaDataSet2.EElist)

    End Sub

    Private Sub Button_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_save.Click
        If txtEE.Text = String.Empty Then
            MsgBox("Please Enter Executive Engineer Name.")
            txtEE.Focus()
        Else
            Dim dt As New DataTable
            Dim ds As New DataSet
            con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"

            con.Open()

            cmdOLEDB.CommandText = "Select EE_Name from EElist where EE_Name= '" & txtEE.Text & "'"
            cmdOLEDB.Connection = con
            Dim rdrOLEDB As OleDbDataReader = cmdOLEDB.ExecuteReader

            If rdrOLEDB.Read = True Then
                MsgBox("Executive Engineer already Exit.")
                rdrOLEDB.Close()
                txtEE.Focus()
                txtEE.Text = ""
            Else
                ds.Tables.Add(dt)
                Dim da, da1 As New OleDbDataAdapter
                da = New OleDbDataAdapter("SELECT * FROM EElist", con)
                da.Fill(dt)
                Dim newRow As DataRow = dt.NewRow
                newRow.Item("EE_Name") = txtEE.Text
                newRow.Item("created") = Now()
                newRow.Item("Entry_By") = "Admin"
                dt.Rows.Add(newRow)
                Dim cb As New OleDbCommandBuilder(da)
                da.Update(dt)
                MsgBox("Junior Engineer successfully saved.", vbInformation)
                EElistTableAdapter.Fill(MhadaDataSet2.EElist)
                con.Close()
                txtEE.Text = ""
            End If
        End If

    End Sub

    Private Sub Button_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Exit.Click
        con.Close()
        Me.Close()

    End Sub
End Class