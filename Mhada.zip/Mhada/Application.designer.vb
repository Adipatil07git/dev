﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Application
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Application))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.MasterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SecondToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AddToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ChangeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RemoveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FirstToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AddToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem
        Me.ChangeToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem
        Me.RemoveToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem
        Me.ExecutiveEngToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AddToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ChangeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.RemoveToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.DeputyEngToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AddToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem
        Me.ChangeToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem
        Me.RemoveToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem
        Me.JuniorEngToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AddToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem
        Me.ChangeToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem
        Me.RemoveToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem
        Me.DataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ADMEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ADMEntry2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AccEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PaymentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.YearWiseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HeadWiseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PaidYearlyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.UnpaidYearlyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OrderwiseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PaidExpenditureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PurchaseToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.EXITToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.MenuStrip1.Font = New System.Drawing.Font("Franklin Gothic Book", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MasterToolStripMenuItem, Me.DataToolStripMenuItem, Me.ReportToolStripMenuItem, Me.EXITToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(8, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(1207, 29)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MasterToolStripMenuItem
        '
        Me.MasterToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SecondToolStripMenuItem, Me.FirstToolStripMenuItem, Me.ExecutiveEngToolStripMenuItem, Me.DeputyEngToolStripMenuItem, Me.JuniorEngToolStripMenuItem})
        Me.MasterToolStripMenuItem.Name = "MasterToolStripMenuItem"
        Me.MasterToolStripMenuItem.Size = New System.Drawing.Size(68, 25)
        Me.MasterToolStripMenuItem.Text = "Master"
        '
        'SecondToolStripMenuItem
        '
        Me.SecondToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddToolStripMenuItem, Me.ChangeToolStripMenuItem, Me.RemoveToolStripMenuItem})
        Me.SecondToolStripMenuItem.Name = "SecondToolStripMenuItem"
        Me.SecondToolStripMenuItem.Size = New System.Drawing.Size(174, 26)
        Me.SecondToolStripMenuItem.Text = "MP / MLA"
        '
        'AddToolStripMenuItem
        '
        Me.AddToolStripMenuItem.Name = "AddToolStripMenuItem"
        Me.AddToolStripMenuItem.Size = New System.Drawing.Size(134, 26)
        Me.AddToolStripMenuItem.Text = "Add"
        '
        'ChangeToolStripMenuItem
        '
        Me.ChangeToolStripMenuItem.Name = "ChangeToolStripMenuItem"
        Me.ChangeToolStripMenuItem.Size = New System.Drawing.Size(134, 26)
        Me.ChangeToolStripMenuItem.Text = "Change"
        '
        'RemoveToolStripMenuItem
        '
        Me.RemoveToolStripMenuItem.Name = "RemoveToolStripMenuItem"
        Me.RemoveToolStripMenuItem.Size = New System.Drawing.Size(134, 26)
        Me.RemoveToolStripMenuItem.Text = "Remove"
        '
        'FirstToolStripMenuItem
        '
        Me.FirstToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddToolStripMenuItem4, Me.ChangeToolStripMenuItem4, Me.RemoveToolStripMenuItem4})
        Me.FirstToolStripMenuItem.Name = "FirstToolStripMenuItem"
        Me.FirstToolStripMenuItem.Size = New System.Drawing.Size(174, 26)
        Me.FirstToolStripMenuItem.Text = "Contractor"
        '
        'AddToolStripMenuItem4
        '
        Me.AddToolStripMenuItem4.Name = "AddToolStripMenuItem4"
        Me.AddToolStripMenuItem4.Size = New System.Drawing.Size(134, 26)
        Me.AddToolStripMenuItem4.Text = "Add"
        '
        'ChangeToolStripMenuItem4
        '
        Me.ChangeToolStripMenuItem4.Name = "ChangeToolStripMenuItem4"
        Me.ChangeToolStripMenuItem4.Size = New System.Drawing.Size(134, 26)
        Me.ChangeToolStripMenuItem4.Text = "Change"
        '
        'RemoveToolStripMenuItem4
        '
        Me.RemoveToolStripMenuItem4.Name = "RemoveToolStripMenuItem4"
        Me.RemoveToolStripMenuItem4.Size = New System.Drawing.Size(134, 26)
        Me.RemoveToolStripMenuItem4.Text = "Remove"
        '
        'ExecutiveEngToolStripMenuItem
        '
        Me.ExecutiveEngToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddToolStripMenuItem1, Me.ChangeToolStripMenuItem1, Me.RemoveToolStripMenuItem1})
        Me.ExecutiveEngToolStripMenuItem.Name = "ExecutiveEngToolStripMenuItem"
        Me.ExecutiveEngToolStripMenuItem.Size = New System.Drawing.Size(174, 26)
        Me.ExecutiveEngToolStripMenuItem.Text = "Executive Eng"
        '
        'AddToolStripMenuItem1
        '
        Me.AddToolStripMenuItem1.Name = "AddToolStripMenuItem1"
        Me.AddToolStripMenuItem1.Size = New System.Drawing.Size(134, 26)
        Me.AddToolStripMenuItem1.Text = "Add"
        '
        'ChangeToolStripMenuItem1
        '
        Me.ChangeToolStripMenuItem1.Name = "ChangeToolStripMenuItem1"
        Me.ChangeToolStripMenuItem1.Size = New System.Drawing.Size(134, 26)
        Me.ChangeToolStripMenuItem1.Text = "Change"
        '
        'RemoveToolStripMenuItem1
        '
        Me.RemoveToolStripMenuItem1.Name = "RemoveToolStripMenuItem1"
        Me.RemoveToolStripMenuItem1.Size = New System.Drawing.Size(134, 26)
        Me.RemoveToolStripMenuItem1.Text = "Remove"
        '
        'DeputyEngToolStripMenuItem
        '
        Me.DeputyEngToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddToolStripMenuItem2, Me.ChangeToolStripMenuItem2, Me.RemoveToolStripMenuItem2})
        Me.DeputyEngToolStripMenuItem.Name = "DeputyEngToolStripMenuItem"
        Me.DeputyEngToolStripMenuItem.Size = New System.Drawing.Size(174, 26)
        Me.DeputyEngToolStripMenuItem.Text = "Deputy Eng"
        '
        'AddToolStripMenuItem2
        '
        Me.AddToolStripMenuItem2.Name = "AddToolStripMenuItem2"
        Me.AddToolStripMenuItem2.Size = New System.Drawing.Size(134, 26)
        Me.AddToolStripMenuItem2.Text = "Add"
        '
        'ChangeToolStripMenuItem2
        '
        Me.ChangeToolStripMenuItem2.Name = "ChangeToolStripMenuItem2"
        Me.ChangeToolStripMenuItem2.Size = New System.Drawing.Size(134, 26)
        Me.ChangeToolStripMenuItem2.Text = "Change"
        '
        'RemoveToolStripMenuItem2
        '
        Me.RemoveToolStripMenuItem2.Name = "RemoveToolStripMenuItem2"
        Me.RemoveToolStripMenuItem2.Size = New System.Drawing.Size(134, 26)
        Me.RemoveToolStripMenuItem2.Text = "Remove"
        '
        'JuniorEngToolStripMenuItem
        '
        Me.JuniorEngToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddToolStripMenuItem3, Me.ChangeToolStripMenuItem3, Me.RemoveToolStripMenuItem3})
        Me.JuniorEngToolStripMenuItem.Name = "JuniorEngToolStripMenuItem"
        Me.JuniorEngToolStripMenuItem.Size = New System.Drawing.Size(174, 26)
        Me.JuniorEngToolStripMenuItem.Text = "Junior Eng"
        '
        'AddToolStripMenuItem3
        '
        Me.AddToolStripMenuItem3.Name = "AddToolStripMenuItem3"
        Me.AddToolStripMenuItem3.Size = New System.Drawing.Size(134, 26)
        Me.AddToolStripMenuItem3.Text = "Add"
        '
        'ChangeToolStripMenuItem3
        '
        Me.ChangeToolStripMenuItem3.Name = "ChangeToolStripMenuItem3"
        Me.ChangeToolStripMenuItem3.Size = New System.Drawing.Size(134, 26)
        Me.ChangeToolStripMenuItem3.Text = "Change"
        '
        'RemoveToolStripMenuItem3
        '
        Me.RemoveToolStripMenuItem3.Name = "RemoveToolStripMenuItem3"
        Me.RemoveToolStripMenuItem3.Size = New System.Drawing.Size(134, 26)
        Me.RemoveToolStripMenuItem3.Text = "Remove"
        '
        'DataToolStripMenuItem
        '
        Me.DataToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ADMEntryToolStripMenuItem, Me.ADMEntry2ToolStripMenuItem, Me.AccEntryToolStripMenuItem, Me.PaymentToolStripMenuItem})
        Me.DataToolStripMenuItem.Name = "DataToolStripMenuItem"
        Me.DataToolStripMenuItem.Size = New System.Drawing.Size(53, 25)
        Me.DataToolStripMenuItem.Text = "Data"
        '
        'ADMEntryToolStripMenuItem
        '
        Me.ADMEntryToolStripMenuItem.Name = "ADMEntryToolStripMenuItem"
        Me.ADMEntryToolStripMenuItem.Size = New System.Drawing.Size(169, 26)
        Me.ADMEntryToolStripMenuItem.Text = "ADM Entry"
        '
        'ADMEntry2ToolStripMenuItem
        '
        Me.ADMEntry2ToolStripMenuItem.Name = "ADMEntry2ToolStripMenuItem"
        Me.ADMEntry2ToolStripMenuItem.Size = New System.Drawing.Size(169, 26)
        Me.ADMEntry2ToolStripMenuItem.Text = "Work Entry"
        '
        'AccEntryToolStripMenuItem
        '
        Me.AccEntryToolStripMenuItem.Name = "AccEntryToolStripMenuItem"
        Me.AccEntryToolStripMenuItem.Size = New System.Drawing.Size(169, 26)
        Me.AccEntryToolStripMenuItem.Text = "Nidhi Vitaran"
        '
        'PaymentToolStripMenuItem
        '
        Me.PaymentToolStripMenuItem.Name = "PaymentToolStripMenuItem"
        Me.PaymentToolStripMenuItem.Size = New System.Drawing.Size(169, 26)
        Me.PaymentToolStripMenuItem.Text = "Payment"
        '
        'ReportToolStripMenuItem
        '
        Me.ReportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.YearWiseToolStripMenuItem, Me.DToolStripMenuItem, Me.HeadWiseToolStripMenuItem, Me.PaidYearlyToolStripMenuItem, Me.UnpaidYearlyToolStripMenuItem, Me.OrderwiseToolStripMenuItem, Me.PaidExpenditureToolStripMenuItem, Me.PurchaseToolStripMenuItem1})
        Me.ReportToolStripMenuItem.Name = "ReportToolStripMenuItem"
        Me.ReportToolStripMenuItem.Size = New System.Drawing.Size(67, 25)
        Me.ReportToolStripMenuItem.Text = "Report"
        '
        'YearWiseToolStripMenuItem
        '
        Me.YearWiseToolStripMenuItem.Name = "YearWiseToolStripMenuItem"
        Me.YearWiseToolStripMenuItem.Size = New System.Drawing.Size(241, 26)
        Me.YearWiseToolStripMenuItem.Text = "Yearly"
        '
        'DToolStripMenuItem
        '
        Me.DToolStripMenuItem.Name = "DToolStripMenuItem"
        Me.DToolStripMenuItem.Size = New System.Drawing.Size(241, 26)
        Me.DToolStripMenuItem.Text = "MLA wise"
        '
        'HeadWiseToolStripMenuItem
        '
        Me.HeadWiseToolStripMenuItem.Name = "HeadWiseToolStripMenuItem"
        Me.HeadWiseToolStripMenuItem.Size = New System.Drawing.Size(241, 26)
        Me.HeadWiseToolStripMenuItem.Text = "Head and Division wise"
        '
        'PaidYearlyToolStripMenuItem
        '
        Me.PaidYearlyToolStripMenuItem.Name = "PaidYearlyToolStripMenuItem"
        Me.PaidYearlyToolStripMenuItem.Size = New System.Drawing.Size(241, 26)
        Me.PaidYearlyToolStripMenuItem.Text = "Yearly Paid "
        '
        'UnpaidYearlyToolStripMenuItem
        '
        Me.UnpaidYearlyToolStripMenuItem.Name = "UnpaidYearlyToolStripMenuItem"
        Me.UnpaidYearlyToolStripMenuItem.Size = New System.Drawing.Size(241, 26)
        Me.UnpaidYearlyToolStripMenuItem.Text = "Yearly Unpaid "
        '
        'OrderwiseToolStripMenuItem
        '
        Me.OrderwiseToolStripMenuItem.Name = "OrderwiseToolStripMenuItem"
        Me.OrderwiseToolStripMenuItem.Size = New System.Drawing.Size(241, 26)
        Me.OrderwiseToolStripMenuItem.Text = "Orderwise"
        '
        'PaidExpenditureToolStripMenuItem
        '
        Me.PaidExpenditureToolStripMenuItem.Name = "PaidExpenditureToolStripMenuItem"
        Me.PaidExpenditureToolStripMenuItem.Size = New System.Drawing.Size(241, 26)
        Me.PaidExpenditureToolStripMenuItem.Text = "Order wise Paid Exp. "
        '
        'PurchaseToolStripMenuItem1
        '
        Me.PurchaseToolStripMenuItem1.Name = "PurchaseToolStripMenuItem1"
        Me.PurchaseToolStripMenuItem1.Size = New System.Drawing.Size(241, 26)
        Me.PurchaseToolStripMenuItem1.Text = "Order wise Unpaid Exp. "
        '
        'EXITToolStripMenuItem
        '
        Me.EXITToolStripMenuItem.Name = "EXITToolStripMenuItem"
        Me.EXITToolStripMenuItem.Size = New System.Drawing.Size(51, 25)
        Me.EXITToolStripMenuItem.Text = "EXIT"
        '
        'Application
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(1207, 598)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Font = New System.Drawing.Font("Arial Rounded MT Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.MaximizeBox = False
        Me.Name = "Application"
        Me.Padding = New System.Windows.Forms.Padding(0, 0, 0, 50)
        Me.Text = "MHADA Office - Mumbai"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MasterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EXITToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PurchaseToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HeadWiseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PaidExpenditureToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FirstToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SecondToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ADMEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AccEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExecutiveEngToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeputyEngToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents JuniorEngToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangeToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangeToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangeToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ADMEntry2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PaymentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OrderwiseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents YearWiseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PaidYearlyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UnpaidYearlyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
