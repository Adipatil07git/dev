﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ADM2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ComboContract = New System.Windows.Forms.ComboBox
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.Label25 = New System.Windows.Forms.Label
        Me.ComboTdQt = New System.Windows.Forms.ComboBox
        Me.txtgst = New System.Windows.Forms.TextBox
        Me.datecomplete = New System.Windows.Forms.DateTimePicker
        Me.datestart = New System.Windows.Forms.DateTimePicker
        Me.txtpan = New System.Windows.Forms.TextBox
        Me.txtagree = New System.Windows.Forms.TextBox
        Me.txtworkkey = New System.Windows.Forms.TextBox
        Me.txttndrdamt = New System.Windows.Forms.TextBox
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.txttndamt = New System.Windows.Forms.TextBox
        Me.txtcon = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.ComboADMno = New System.Windows.Forms.ComboBox
        Me.Textadmdt = New System.Windows.Forms.TextBox
        Me.Textadmamt = New System.Windows.Forms.TextBox
        Me.Textmpmla = New System.Windows.Forms.TextBox
        Me.Textfhg = New System.Windows.Forms.TextBox
        Me.Textdiv = New System.Windows.Forms.TextBox
        Me.Textfnm = New System.Windows.Forms.TextBox
        Me.Textadmyr = New System.Windows.Forms.TextBox
        Me.Textworknm = New System.Windows.Forms.TextBox
        Me.ComboGP = New System.Windows.Forms.ComboBox
        Me.Textfhm = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.TextExcEng = New System.Windows.Forms.TextBox
        Me.TextDepEng = New System.Windows.Forms.TextBox
        Me.TextJrEng = New System.Windows.Forms.TextBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.TextPer = New System.Windows.Forms.TextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'ComboContract
        '
        Me.ComboContract.FormattingEnabled = True
        Me.ComboContract.Location = New System.Drawing.Point(181, 178)
        Me.ComboContract.Name = "ComboContract"
        Me.ComboContract.Size = New System.Drawing.Size(213, 28)
        Me.ComboContract.TabIndex = 12
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Turquoise
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(872, 629)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(80, 52)
        Me.Button2.TabIndex = 270
        Me.Button2.Text = "Close"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.LightGreen
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(392, 629)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 52)
        Me.Button1.TabIndex = 269
        Me.Button1.Text = "Save "
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(20, 20)
        Me.Label25.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(117, 20)
        Me.Label25.TabIndex = 297
        Me.Label25.Text = "ADM Amount  :"
        '
        'ComboTdQt
        '
        Me.ComboTdQt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboTdQt.FormattingEnabled = True
        Me.ComboTdQt.Items.AddRange(New Object() {"BELOW ", "ABOVE", "AT PAR"})
        Me.ComboTdQt.Location = New System.Drawing.Point(584, 99)
        Me.ComboTdQt.Name = "ComboTdQt"
        Me.ComboTdQt.Size = New System.Drawing.Size(122, 28)
        Me.ComboTdQt.TabIndex = 9
        '
        'txtgst
        '
        Me.txtgst.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgst.Location = New System.Drawing.Point(1018, 181)
        Me.txtgst.MaxLength = 15
        Me.txtgst.Name = "txtgst"
        Me.txtgst.ReadOnly = True
        Me.txtgst.Size = New System.Drawing.Size(214, 26)
        Me.txtgst.TabIndex = 268
        '
        'datecomplete
        '
        Me.datecomplete.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.datecomplete.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.datecomplete.Location = New System.Drawing.Point(584, 142)
        Me.datecomplete.Name = "datecomplete"
        Me.datecomplete.Size = New System.Drawing.Size(122, 26)
        Me.datecomplete.TabIndex = 11
        Me.datecomplete.Value = New Date(2023, 10, 6, 0, 0, 0, 0)
        '
        'datestart
        '
        Me.datestart.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.datestart.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.datestart.Location = New System.Drawing.Point(179, 137)
        Me.datestart.Name = "datestart"
        Me.datestart.Size = New System.Drawing.Size(104, 26)
        Me.datestart.TabIndex = 10
        Me.datestart.Value = New Date(2023, 10, 6, 0, 0, 0, 0)
        '
        'txtpan
        '
        Me.txtpan.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpan.Location = New System.Drawing.Point(584, 178)
        Me.txtpan.MaxLength = 10
        Me.txtpan.Name = "txtpan"
        Me.txtpan.ReadOnly = True
        Me.txtpan.Size = New System.Drawing.Size(180, 26)
        Me.txtpan.TabIndex = 267
        '
        'txtagree
        '
        Me.txtagree.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtagree.Location = New System.Drawing.Point(584, 59)
        Me.txtagree.MaxLength = 30
        Me.txtagree.Name = "txtagree"
        Me.txtagree.Size = New System.Drawing.Size(242, 26)
        Me.txtagree.TabIndex = 7
        '
        'txtworkkey
        '
        Me.txtworkkey.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtworkkey.Location = New System.Drawing.Point(179, 62)
        Me.txtworkkey.MaxLength = 30
        Me.txtworkkey.Name = "txtworkkey"
        Me.txtworkkey.Size = New System.Drawing.Size(214, 26)
        Me.txtworkkey.TabIndex = 6
        '
        'txttndrdamt
        '
        Me.txttndrdamt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttndrdamt.Location = New System.Drawing.Point(1018, 101)
        Me.txttndrdamt.MaxLength = 12
        Me.txttndrdamt.Name = "txttndrdamt"
        Me.txttndrdamt.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txttndrdamt.Size = New System.Drawing.Size(214, 26)
        Me.txttndrdamt.TabIndex = 263
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(16, 143)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(109, 20)
        Me.Label27.TabIndex = 296
        Me.Label27.Text = "Date of Start :"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(428, 62)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(120, 20)
        Me.Label20.TabIndex = 295
        Me.Label20.Text = "Agreement No :"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(13, 62)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(108, 20)
        Me.Label19.TabIndex = 294
        Me.Label19.Text = "Work Key No :"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(870, 104)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(145, 20)
        Me.Label18.TabIndex = 293
        Me.Label18.Text = "Tendered Amount :"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(425, 104)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(115, 20)
        Me.Label17.TabIndex = 292
        Me.Label17.Text = "Tender Quote :"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(11, 100)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(127, 20)
        Me.Label16.TabIndex = 291
        Me.Label16.Text = "Tender Amount :"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(20, 165)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(100, 20)
        Me.Label15.TabIndex = 290
        Me.Label15.Text = "Work Name :"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(870, 24)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(128, 20)
        Me.Label14.TabIndex = 289
        Me.Label14.Text = "Junior Engineer :"
        '
        'txttndamt
        '
        Me.txttndamt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttndamt.Location = New System.Drawing.Point(179, 98)
        Me.txttndamt.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txttndamt.MaxLength = 12
        Me.txttndamt.Name = "txttndamt"
        Me.txttndamt.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txttndamt.Size = New System.Drawing.Size(106, 26)
        Me.txttndamt.TabIndex = 8
        '
        'txtcon
        '
        Me.txtcon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtcon.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcon.Location = New System.Drawing.Point(584, 130)
        Me.txtcon.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtcon.Name = "txtcon"
        Me.txtcon.ReadOnly = True
        Me.txtcon.Size = New System.Drawing.Size(304, 26)
        Me.txtcon.TabIndex = 250
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(422, 57)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(139, 20)
        Me.Label13.TabIndex = 288
        Me.Label13.Text = "Fund Head Govt. :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(422, 93)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(160, 20)
        Me.Label5.TabIndex = 287
        Me.Label5.Text = "Fund Head MHADA :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(20, 89)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(138, 20)
        Me.Label4.TabIndex = 286
        Me.Label4.Text = "Fund Name Govt.:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(422, 130)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 20)
        Me.Label3.TabIndex = 285
        Me.Label3.Text = "Constitancy :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(20, 123)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(131, 20)
        Me.Label2.TabIndex = 284
        Me.Label2.Text = "MP / MLA Name :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(19, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 20)
        Me.Label1.TabIndex = 283
        Me.Label1.Text = "Division :"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(870, 185)
        Me.Label29.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(153, 20)
        Me.Label29.TabIndex = 282
        Me.Label29.Text = "Contractor GST No :"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(428, 181)
        Me.Label24.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(148, 20)
        Me.Label24.TabIndex = 281
        Me.Label24.Text = "Contractor PAN No:"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(425, 143)
        Me.Label22.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(154, 20)
        Me.Label22.TabIndex = 279
        Me.Label22.Text = "Date of Completion :"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(971, 465)
        Me.Label21.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(0, 20)
        Me.Label21.TabIndex = 278
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(428, 24)
        Me.Label12.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(136, 20)
        Me.Label12.TabIndex = 277
        Me.Label12.Text = "Deputy Engineer :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(14, 28)
        Me.Label11.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(145, 20)
        Me.Label11.TabIndex = 276
        Me.Label11.Text = "Executive Engineer"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(426, 72)
        Me.Label10.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(165, 20)
        Me.Label10.TabIndex = 275
        Me.Label10.Text = "GP / MLA / Serail  No :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(32, 72)
        Me.Label7.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(77, 20)
        Me.Label7.TabIndex = 272
        Me.Label7.Text = "ADM No :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(690, 22)
        Me.Label6.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(92, 20)
        Me.Label6.TabIndex = 271
        Me.Label6.Text = "Fund Year :"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(422, 20)
        Me.Label8.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(92, 20)
        Me.Label8.TabIndex = 273
        Me.Label8.Text = "ADM Date :"
        '
        'ComboADMno
        '
        Me.ComboADMno.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboADMno.FormattingEnabled = True
        Me.ComboADMno.Location = New System.Drawing.Point(186, 70)
        Me.ComboADMno.Name = "ComboADMno"
        Me.ComboADMno.Size = New System.Drawing.Size(219, 26)
        Me.ComboADMno.Sorted = True
        Me.ComboADMno.TabIndex = 1
        '
        'Textadmdt
        '
        Me.Textadmdt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Textadmdt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Textadmdt.ForeColor = System.Drawing.SystemColors.Highlight
        Me.Textadmdt.Location = New System.Drawing.Point(584, 18)
        Me.Textadmdt.MaxLength = 30
        Me.Textadmdt.Name = "Textadmdt"
        Me.Textadmdt.ReadOnly = True
        Me.Textadmdt.Size = New System.Drawing.Size(78, 26)
        Me.Textadmdt.TabIndex = 299
        '
        'Textadmamt
        '
        Me.Textadmamt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Textadmamt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Textadmamt.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Textadmamt.Location = New System.Drawing.Point(179, 18)
        Me.Textadmamt.MaxLength = 30
        Me.Textadmamt.Name = "Textadmamt"
        Me.Textadmamt.ReadOnly = True
        Me.Textadmamt.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Textadmamt.Size = New System.Drawing.Size(214, 26)
        Me.Textadmamt.TabIndex = 300
        '
        'Textmpmla
        '
        Me.Textmpmla.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Textmpmla.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Textmpmla.Location = New System.Drawing.Point(179, 121)
        Me.Textmpmla.MaxLength = 30
        Me.Textmpmla.Name = "Textmpmla"
        Me.Textmpmla.ReadOnly = True
        Me.Textmpmla.Size = New System.Drawing.Size(214, 26)
        Me.Textmpmla.TabIndex = 301
        '
        'Textfhg
        '
        Me.Textfhg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Textfhg.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Textfhg.Location = New System.Drawing.Point(584, 55)
        Me.Textfhg.MaxLength = 30
        Me.Textfhg.Name = "Textfhg"
        Me.Textfhg.ReadOnly = True
        Me.Textfhg.Size = New System.Drawing.Size(304, 26)
        Me.Textfhg.TabIndex = 302
        '
        'Textdiv
        '
        Me.Textdiv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Textdiv.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Textdiv.Location = New System.Drawing.Point(179, 53)
        Me.Textdiv.MaxLength = 30
        Me.Textdiv.Name = "Textdiv"
        Me.Textdiv.ReadOnly = True
        Me.Textdiv.Size = New System.Drawing.Size(214, 26)
        Me.Textdiv.TabIndex = 303
        '
        'Textfnm
        '
        Me.Textfnm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Textfnm.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Textfnm.Location = New System.Drawing.Point(179, 86)
        Me.Textfnm.MaxLength = 30
        Me.Textfnm.Name = "Textfnm"
        Me.Textfnm.ReadOnly = True
        Me.Textfnm.Size = New System.Drawing.Size(214, 26)
        Me.Textfnm.TabIndex = 304
        '
        'Textadmyr
        '
        Me.Textadmyr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Textadmyr.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Textadmyr.Location = New System.Drawing.Point(790, 18)
        Me.Textadmyr.MaxLength = 30
        Me.Textadmyr.Name = "Textadmyr"
        Me.Textadmyr.ReadOnly = True
        Me.Textadmyr.Size = New System.Drawing.Size(98, 26)
        Me.Textadmyr.TabIndex = 305
        '
        'Textworknm
        '
        Me.Textworknm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Textworknm.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Textworknm.Location = New System.Drawing.Point(179, 163)
        Me.Textworknm.MaxLength = 30
        Me.Textworknm.Name = "Textworknm"
        Me.Textworknm.ReadOnly = True
        Me.Textworknm.Size = New System.Drawing.Size(709, 26)
        Me.Textworknm.TabIndex = 306
        '
        'ComboGP
        '
        Me.ComboGP.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboGP.FormattingEnabled = True
        Me.ComboGP.Location = New System.Drawing.Point(596, 70)
        Me.ComboGP.Name = "ComboGP"
        Me.ComboGP.Size = New System.Drawing.Size(164, 26)
        Me.ComboGP.Sorted = True
        Me.ComboGP.TabIndex = 2
        '
        'Textfhm
        '
        Me.Textfhm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Textfhm.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Textfhm.Location = New System.Drawing.Point(584, 93)
        Me.Textfhm.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Textfhm.Name = "Textfhm"
        Me.Textfhm.ReadOnly = True
        Me.Textfhm.Size = New System.Drawing.Size(304, 26)
        Me.Textfhm.TabIndex = 308
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Monotype Corsiva", 24.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(561, -1)
        Me.Label9.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(249, 39)
        Me.Label9.TabIndex = 309
        Me.Label9.Text = "Work  Entry Form"
        '
        'TextExcEng
        '
        Me.TextExcEng.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextExcEng.Location = New System.Drawing.Point(180, 25)
        Me.TextExcEng.MaxLength = 30
        Me.TextExcEng.Name = "TextExcEng"
        Me.TextExcEng.Size = New System.Drawing.Size(214, 26)
        Me.TextExcEng.TabIndex = 3
        '
        'TextDepEng
        '
        Me.TextDepEng.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextDepEng.Location = New System.Drawing.Point(582, 22)
        Me.TextDepEng.MaxLength = 30
        Me.TextDepEng.Name = "TextDepEng"
        Me.TextDepEng.Size = New System.Drawing.Size(244, 26)
        Me.TextDepEng.TabIndex = 4
        '
        'TextJrEng
        '
        Me.TextJrEng.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextJrEng.Location = New System.Drawing.Point(1018, 22)
        Me.TextJrEng.MaxLength = 30
        Me.TextJrEng.Name = "TextJrEng"
        Me.TextJrEng.Size = New System.Drawing.Size(214, 26)
        Me.TextJrEng.TabIndex = 5
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(16, 181)
        Me.Label26.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(142, 20)
        Me.Label26.TabIndex = 280
        Me.Label26.Text = "Contractor  Name :"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label23)
        Me.GroupBox1.Controls.Add(Me.TextPer)
        Me.GroupBox1.Controls.Add(Me.TextJrEng)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.TextDepEng)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.TextExcEng)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.txtworkkey)
        Me.GroupBox1.Controls.Add(Me.txtagree)
        Me.GroupBox1.Controls.Add(Me.txttndamt)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.ComboTdQt)
        Me.GroupBox1.Controls.Add(Me.ComboContract)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.txttndrdamt)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.Label27)
        Me.GroupBox1.Controls.Add(Me.txtgst)
        Me.GroupBox1.Controls.Add(Me.Label22)
        Me.GroupBox1.Controls.Add(Me.datecomplete)
        Me.GroupBox1.Controls.Add(Me.Label26)
        Me.GroupBox1.Controls.Add(Me.datestart)
        Me.GroupBox1.Controls.Add(Me.Label24)
        Me.GroupBox1.Controls.Add(Me.txtpan)
        Me.GroupBox1.Controls.Add(Me.Label29)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 376)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1241, 229)
        Me.GroupBox1.TabIndex = 310
        Me.GroupBox1.TabStop = False
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(719, 104)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(91, 20)
        Me.Label23.TabIndex = 298
        Me.Label23.Text = "Percentage"
        '
        'TextPer
        '
        Me.TextPer.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextPer.Location = New System.Drawing.Point(816, 102)
        Me.TextPer.MaxLength = 12
        Me.TextPer.Name = "TextPer"
        Me.TextPer.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextPer.Size = New System.Drawing.Size(48, 26)
        Me.TextPer.TabIndex = 297
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Textadmamt)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Textfhm)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.Textadmyr)
        Me.GroupBox2.Controls.Add(Me.Textworknm)
        Me.GroupBox2.Controls.Add(Me.Textfhg)
        Me.GroupBox2.Controls.Add(Me.Label25)
        Me.GroupBox2.Controls.Add(Me.Textadmdt)
        Me.GroupBox2.Controls.Add(Me.Textmpmla)
        Me.GroupBox2.Controls.Add(Me.Textfnm)
        Me.GroupBox2.Controls.Add(Me.Textdiv)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.txtcon)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 148)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(911, 200)
        Me.GroupBox2.TabIndex = 311
        Me.GroupBox2.TabStop = False
        '
        'ADM2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.ComboGP)
        Me.Controls.Add(Me.ComboADMno)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label7)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ADM2"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ADM Details"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ComboContract As System.Windows.Forms.ComboBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents ComboTdQt As System.Windows.Forms.ComboBox
    Friend WithEvents txtgst As System.Windows.Forms.TextBox
    Friend WithEvents datecomplete As System.Windows.Forms.DateTimePicker
    Friend WithEvents datestart As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtpan As System.Windows.Forms.TextBox
    Friend WithEvents txtagree As System.Windows.Forms.TextBox
    Friend WithEvents txtworkkey As System.Windows.Forms.TextBox
    Friend WithEvents txttndrdamt As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txttndamt As System.Windows.Forms.TextBox
    Friend WithEvents txtcon As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents ComboADMno As System.Windows.Forms.ComboBox
    Friend WithEvents Textadmdt As System.Windows.Forms.TextBox
    Friend WithEvents Textadmamt As System.Windows.Forms.TextBox
    Friend WithEvents Textmpmla As System.Windows.Forms.TextBox
    Friend WithEvents Textfhg As System.Windows.Forms.TextBox
    Friend WithEvents Textdiv As System.Windows.Forms.TextBox
    Friend WithEvents Textfnm As System.Windows.Forms.TextBox
    Friend WithEvents Textadmyr As System.Windows.Forms.TextBox
    Friend WithEvents Textworknm As System.Windows.Forms.TextBox
    Friend WithEvents ComboGP As System.Windows.Forms.ComboBox
    Friend WithEvents Textfhm As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TextExcEng As System.Windows.Forms.TextBox
    Friend WithEvents TextDepEng As System.Windows.Forms.TextBox
    Friend WithEvents TextJrEng As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents TextPer As System.Windows.Forms.TextBox
End Class
