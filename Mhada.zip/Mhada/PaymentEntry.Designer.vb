﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PaymentEntry
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker
        Me.Label3 = New System.Windows.Forms.Label
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker
        Me.Labelchqno = New System.Windows.Forms.Label
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.TextAmt = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.ComboGP = New System.Windows.Forms.ComboBox
        Me.ComboADMno = New System.Windows.Forms.ComboBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.TextBillamt = New System.Windows.Forms.TextBox
        Me.TextDed = New System.Windows.Forms.TextBox
        Me.Textcontractor = New System.Windows.Forms.TextBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.chdtord1 = New System.Windows.Forms.TextBox
        Me.dtord1 = New System.Windows.Forms.TextBox
        Me.TotRecAmt = New System.Windows.Forms.TextBox
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.recamtord4 = New System.Windows.Forms.TextBox
        Me.recamtord3 = New System.Windows.Forms.TextBox
        Me.recamtord2 = New System.Windows.Forms.TextBox
        Me.chdtord4 = New System.Windows.Forms.TextBox
        Me.chdtord3 = New System.Windows.Forms.TextBox
        Me.chdtord2 = New System.Windows.Forms.TextBox
        Me.rtgsdt = New System.Windows.Forms.TextBox
        Me.chnoord4 = New System.Windows.Forms.TextBox
        Me.rtgsno = New System.Windows.Forms.TextBox
        Me.chnoord3 = New System.Windows.Forms.TextBox
        Me.Label30 = New System.Windows.Forms.Label
        Me.chnoord2 = New System.Windows.Forms.TextBox
        Me.dtord4 = New System.Windows.Forms.TextBox
        Me.Label29 = New System.Windows.Forms.Label
        Me.dtord3 = New System.Windows.Forms.TextBox
        Me.dtord2 = New System.Windows.Forms.TextBox
        Me.noord4 = New System.Windows.Forms.TextBox
        Me.noord3 = New System.Windows.Forms.TextBox
        Me.noord2 = New System.Windows.Forms.TextBox
        Me.recamtord1 = New System.Windows.Forms.TextBox
        Me.chnoord1 = New System.Windows.Forms.TextBox
        Me.noord1 = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(33, 91)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(138, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Cash Voucher No."
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(190, 88)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(188, 26)
        Me.TextBox1.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Modern No. 20", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(476, -1)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(210, 34)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Voucher Entry"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker1.Location = New System.Drawing.Point(462, 85)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(103, 26)
        Me.DateTimePicker1.TabIndex = 2
        Me.DateTimePicker1.Value = New Date(2023, 10, 6, 16, 14, 6, 0)
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(400, 89)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 20)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Date"
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker2.Location = New System.Drawing.Point(190, 367)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(103, 26)
        Me.DateTimePicker2.TabIndex = 8
        Me.DateTimePicker2.Value = New Date(2023, 10, 6, 16, 14, 6, 0)
        '
        'Labelchqno
        '
        Me.Labelchqno.AutoSize = True
        Me.Labelchqno.Location = New System.Drawing.Point(37, 331)
        Me.Labelchqno.Name = "Labelchqno"
        Me.Labelchqno.Size = New System.Drawing.Size(142, 20)
        Me.Labelchqno.TabIndex = 6
        Me.Labelchqno.Text = "RTGS/Cheque No."
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(190, 328)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(190, 26)
        Me.TextBox2.TabIndex = 7
        '
        'TextAmt
        '
        Me.TextAmt.Location = New System.Drawing.Point(190, 295)
        Me.TextAmt.Name = "TextAmt"
        Me.TextAmt.ReadOnly = True
        Me.TextAmt.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextAmt.Size = New System.Drawing.Size(188, 26)
        Me.TextAmt.TabIndex = 8
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(35, 297)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 20)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Amount"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(40, 367)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 20)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Date"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(34, 196)
        Me.Label26.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(142, 20)
        Me.Label26.TabIndex = 282
        Me.Label26.Text = "Contractor  Name :"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Turquoise
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(402, 447)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 50)
        Me.Button2.TabIndex = 284
        Me.Button2.Text = "Close"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.LightGreen
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(190, 445)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 52)
        Me.Button1.TabIndex = 9
        Me.Button1.Text = "Save "
        Me.Button1.UseVisualStyleBackColor = False
        '
        'ComboGP
        '
        Me.ComboGP.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboGP.FormattingEnabled = True
        Me.ComboGP.Location = New System.Drawing.Point(190, 161)
        Me.ComboGP.Name = "ComboGP"
        Me.ComboGP.Size = New System.Drawing.Size(188, 26)
        Me.ComboGP.Sorted = True
        Me.ComboGP.TabIndex = 4
        '
        'ComboADMno
        '
        Me.ComboADMno.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboADMno.FormattingEnabled = True
        Me.ComboADMno.Location = New System.Drawing.Point(190, 123)
        Me.ComboADMno.Name = "ComboADMno"
        Me.ComboADMno.Size = New System.Drawing.Size(188, 26)
        Me.ComboADMno.Sorted = True
        Me.ComboADMno.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(33, 163)
        Me.Label4.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(149, 20)
        Me.Label4.TabIndex = 294
        Me.Label4.Text = "GP/MLA/Serail  No :"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(35, 125)
        Me.Label15.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(77, 20)
        Me.Label15.TabIndex = 293
        Me.Label15.Text = "ADM No :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(35, 232)
        Me.Label7.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(89, 20)
        Me.Label7.TabIndex = 295
        Me.Label7.Text = "Bill Amount"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(35, 265)
        Me.Label8.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(82, 20)
        Me.Label8.TabIndex = 296
        Me.Label8.Text = "Deduction"
        '
        'TextBillamt
        '
        Me.TextBillamt.Location = New System.Drawing.Point(190, 232)
        Me.TextBillamt.Name = "TextBillamt"
        Me.TextBillamt.ReadOnly = True
        Me.TextBillamt.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextBillamt.Size = New System.Drawing.Size(188, 26)
        Me.TextBillamt.TabIndex = 297
        '
        'TextDed
        '
        Me.TextDed.Location = New System.Drawing.Point(190, 265)
        Me.TextDed.Name = "TextDed"
        Me.TextDed.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextDed.Size = New System.Drawing.Size(188, 26)
        Me.TextDed.TabIndex = 6
        '
        'Textcontractor
        '
        Me.Textcontractor.Location = New System.Drawing.Point(190, 196)
        Me.Textcontractor.Name = "Textcontractor"
        Me.Textcontractor.Size = New System.Drawing.Size(188, 26)
        Me.Textcontractor.TabIndex = 5
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.chdtord1)
        Me.Panel1.Controls.Add(Me.dtord1)
        Me.Panel1.Controls.Add(Me.TotRecAmt)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.recamtord4)
        Me.Panel1.Controls.Add(Me.recamtord3)
        Me.Panel1.Controls.Add(Me.recamtord2)
        Me.Panel1.Controls.Add(Me.chdtord4)
        Me.Panel1.Controls.Add(Me.chdtord3)
        Me.Panel1.Controls.Add(Me.chdtord2)
        Me.Panel1.Controls.Add(Me.rtgsdt)
        Me.Panel1.Controls.Add(Me.chnoord4)
        Me.Panel1.Controls.Add(Me.rtgsno)
        Me.Panel1.Controls.Add(Me.chnoord3)
        Me.Panel1.Controls.Add(Me.Label30)
        Me.Panel1.Controls.Add(Me.chnoord2)
        Me.Panel1.Controls.Add(Me.dtord4)
        Me.Panel1.Controls.Add(Me.Label29)
        Me.Panel1.Controls.Add(Me.dtord3)
        Me.Panel1.Controls.Add(Me.dtord2)
        Me.Panel1.Controls.Add(Me.noord4)
        Me.Panel1.Controls.Add(Me.noord3)
        Me.Panel1.Controls.Add(Me.noord2)
        Me.Panel1.Controls.Add(Me.recamtord1)
        Me.Panel1.Controls.Add(Me.chnoord1)
        Me.Panel1.Controls.Add(Me.noord1)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel1.Location = New System.Drawing.Point(402, 135)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(844, 216)
        Me.Panel1.TabIndex = 300
        '
        'chdtord1
        '
        Me.chdtord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chdtord1.Location = New System.Drawing.Point(591, 43)
        Me.chdtord1.Name = "chdtord1"
        Me.chdtord1.ReadOnly = True
        Me.chdtord1.Size = New System.Drawing.Size(87, 26)
        Me.chdtord1.TabIndex = 315
        '
        'dtord1
        '
        Me.dtord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtord1.Location = New System.Drawing.Point(230, 44)
        Me.dtord1.Name = "dtord1"
        Me.dtord1.ReadOnly = True
        Me.dtord1.Size = New System.Drawing.Size(83, 26)
        Me.dtord1.TabIndex = 314
        '
        'TotRecAmt
        '
        Me.TotRecAmt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TotRecAmt.Location = New System.Drawing.Point(701, 176)
        Me.TotRecAmt.Name = "TotRecAmt"
        Me.TotRecAmt.ReadOnly = True
        Me.TotRecAmt.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TotRecAmt.Size = New System.Drawing.Size(124, 26)
        Me.TotRecAmt.TabIndex = 275
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Location = New System.Drawing.Point(85, 10)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(740, 24)
        Me.Panel2.TabIndex = 251
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(28, 3)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(61, 18)
        Me.Label9.TabIndex = 10000
        Me.Label9.Text = "Number"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(160, 3)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(39, 18)
        Me.Label10.TabIndex = 2000
        Me.Label10.Text = "Date"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(310, 2)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(83, 18)
        Me.Label11.TabIndex = 3000
        Me.Label11.Text = "Cheque No"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(637, 3)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(73, 18)
        Me.Label12.TabIndex = 5000
        Me.Label12.Text = "Rec. Amt."
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(502, 2)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(94, 18)
        Me.Label13.TabIndex = 4000
        Me.Label13.Text = "Cheque Date"
        '
        'recamtord4
        '
        Me.recamtord4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.recamtord4.Location = New System.Drawing.Point(701, 144)
        Me.recamtord4.Name = "recamtord4"
        Me.recamtord4.ReadOnly = True
        Me.recamtord4.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.recamtord4.Size = New System.Drawing.Size(124, 26)
        Me.recamtord4.TabIndex = 274
        '
        'recamtord3
        '
        Me.recamtord3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.recamtord3.Location = New System.Drawing.Point(701, 111)
        Me.recamtord3.Name = "recamtord3"
        Me.recamtord3.ReadOnly = True
        Me.recamtord3.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.recamtord3.Size = New System.Drawing.Size(124, 26)
        Me.recamtord3.TabIndex = 273
        '
        'recamtord2
        '
        Me.recamtord2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.recamtord2.Location = New System.Drawing.Point(701, 78)
        Me.recamtord2.Name = "recamtord2"
        Me.recamtord2.ReadOnly = True
        Me.recamtord2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.recamtord2.Size = New System.Drawing.Size(124, 26)
        Me.recamtord2.TabIndex = 272
        '
        'chdtord4
        '
        Me.chdtord4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chdtord4.Location = New System.Drawing.Point(591, 144)
        Me.chdtord4.Name = "chdtord4"
        Me.chdtord4.ReadOnly = True
        Me.chdtord4.Size = New System.Drawing.Size(87, 26)
        Me.chdtord4.TabIndex = 271
        '
        'chdtord3
        '
        Me.chdtord3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chdtord3.Location = New System.Drawing.Point(591, 111)
        Me.chdtord3.Name = "chdtord3"
        Me.chdtord3.ReadOnly = True
        Me.chdtord3.Size = New System.Drawing.Size(87, 26)
        Me.chdtord3.TabIndex = 270
        '
        'chdtord2
        '
        Me.chdtord2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chdtord2.Location = New System.Drawing.Point(591, 78)
        Me.chdtord2.Name = "chdtord2"
        Me.chdtord2.ReadOnly = True
        Me.chdtord2.Size = New System.Drawing.Size(87, 26)
        Me.chdtord2.TabIndex = 269
        '
        'rtgsdt
        '
        Me.rtgsdt.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtgsdt.Location = New System.Drawing.Point(509, 181)
        Me.rtgsdt.Name = "rtgsdt"
        Me.rtgsdt.ReadOnly = True
        Me.rtgsdt.Size = New System.Drawing.Size(87, 27)
        Me.rtgsdt.TabIndex = 276
        '
        'chnoord4
        '
        Me.chnoord4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chnoord4.Location = New System.Drawing.Point(343, 144)
        Me.chnoord4.Name = "chnoord4"
        Me.chnoord4.ReadOnly = True
        Me.chnoord4.Size = New System.Drawing.Size(225, 26)
        Me.chnoord4.TabIndex = 268
        '
        'rtgsno
        '
        Me.rtgsno.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtgsno.Location = New System.Drawing.Point(289, 181)
        Me.rtgsno.Name = "rtgsno"
        Me.rtgsno.ReadOnly = True
        Me.rtgsno.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.rtgsno.Size = New System.Drawing.Size(87, 27)
        Me.rtgsno.TabIndex = 311
        '
        'chnoord3
        '
        Me.chnoord3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chnoord3.Location = New System.Drawing.Point(343, 111)
        Me.chnoord3.Name = "chnoord3"
        Me.chnoord3.ReadOnly = True
        Me.chnoord3.Size = New System.Drawing.Size(225, 26)
        Me.chnoord3.TabIndex = 267
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(408, 184)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(78, 19)
        Me.Label30.TabIndex = 7000
        Me.Label30.Text = "RTGS Date"
        '
        'chnoord2
        '
        Me.chnoord2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chnoord2.Location = New System.Drawing.Point(343, 78)
        Me.chnoord2.Name = "chnoord2"
        Me.chnoord2.ReadOnly = True
        Me.chnoord2.Size = New System.Drawing.Size(225, 26)
        Me.chnoord2.TabIndex = 266
        '
        'dtord4
        '
        Me.dtord4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtord4.Location = New System.Drawing.Point(230, 145)
        Me.dtord4.Name = "dtord4"
        Me.dtord4.ReadOnly = True
        Me.dtord4.Size = New System.Drawing.Size(83, 26)
        Me.dtord4.TabIndex = 265
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(175, 184)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(65, 19)
        Me.Label29.TabIndex = 6000
        Me.Label29.Text = "RTGS No"
        '
        'dtord3
        '
        Me.dtord3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtord3.Location = New System.Drawing.Point(230, 111)
        Me.dtord3.Name = "dtord3"
        Me.dtord3.ReadOnly = True
        Me.dtord3.Size = New System.Drawing.Size(83, 26)
        Me.dtord3.TabIndex = 264
        '
        'dtord2
        '
        Me.dtord2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtord2.Location = New System.Drawing.Point(230, 78)
        Me.dtord2.Name = "dtord2"
        Me.dtord2.ReadOnly = True
        Me.dtord2.Size = New System.Drawing.Size(83, 26)
        Me.dtord2.TabIndex = 263
        '
        'noord4
        '
        Me.noord4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.noord4.Location = New System.Drawing.Point(85, 146)
        Me.noord4.Name = "noord4"
        Me.noord4.ReadOnly = True
        Me.noord4.Size = New System.Drawing.Size(118, 26)
        Me.noord4.TabIndex = 262
        '
        'noord3
        '
        Me.noord3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.noord3.Location = New System.Drawing.Point(85, 111)
        Me.noord3.Name = "noord3"
        Me.noord3.ReadOnly = True
        Me.noord3.Size = New System.Drawing.Size(118, 26)
        Me.noord3.TabIndex = 261
        '
        'noord2
        '
        Me.noord2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.noord2.Location = New System.Drawing.Point(85, 79)
        Me.noord2.Name = "noord2"
        Me.noord2.ReadOnly = True
        Me.noord2.Size = New System.Drawing.Size(118, 26)
        Me.noord2.TabIndex = 260
        '
        'recamtord1
        '
        Me.recamtord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.recamtord1.Location = New System.Drawing.Point(701, 44)
        Me.recamtord1.Name = "recamtord1"
        Me.recamtord1.ReadOnly = True
        Me.recamtord1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.recamtord1.Size = New System.Drawing.Size(124, 26)
        Me.recamtord1.TabIndex = 256
        '
        'chnoord1
        '
        Me.chnoord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chnoord1.Location = New System.Drawing.Point(343, 44)
        Me.chnoord1.Name = "chnoord1"
        Me.chnoord1.ReadOnly = True
        Me.chnoord1.Size = New System.Drawing.Size(225, 26)
        Me.chnoord1.TabIndex = 254
        '
        'noord1
        '
        Me.noord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.noord1.Location = New System.Drawing.Point(85, 43)
        Me.noord1.Name = "noord1"
        Me.noord1.ReadOnly = True
        Me.noord1.Size = New System.Drawing.Size(118, 26)
        Me.noord1.TabIndex = 252
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(20, 149)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(59, 18)
        Me.Label14.TabIndex = 9
        Me.Label14.Text = "Order-4"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(20, 114)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(59, 18)
        Me.Label16.TabIndex = 8
        Me.Label16.Text = "Order-3"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(20, 82)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(59, 18)
        Me.Label17.TabIndex = 7
        Me.Label17.Text = "Order-2"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(18, 46)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(59, 18)
        Me.Label18.TabIndex = 6
        Me.Label18.Text = "Order-1"
        '
        'PaymentEntry
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1297, 748)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Textcontractor)
        Me.Controls.Add(Me.TextDed)
        Me.Controls.Add(Me.TextBillamt)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.ComboGP)
        Me.Controls.Add(Me.ComboADMno)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TextAmt)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Labelchqno)
        Me.Controls.Add(Me.DateTimePicker2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "PaymentEntry"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Payment Entry"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Labelchqno As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextAmt As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ComboGP As System.Windows.Forms.ComboBox
    Friend WithEvents ComboADMno As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBillamt As System.Windows.Forms.TextBox
    Friend WithEvents TextDed As System.Windows.Forms.TextBox
    Friend WithEvents Textcontractor As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents chdtord1 As System.Windows.Forms.TextBox
    Friend WithEvents dtord1 As System.Windows.Forms.TextBox
    Friend WithEvents TotRecAmt As System.Windows.Forms.TextBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents recamtord4 As System.Windows.Forms.TextBox
    Friend WithEvents recamtord3 As System.Windows.Forms.TextBox
    Friend WithEvents recamtord2 As System.Windows.Forms.TextBox
    Friend WithEvents chdtord4 As System.Windows.Forms.TextBox
    Friend WithEvents chdtord3 As System.Windows.Forms.TextBox
    Friend WithEvents chdtord2 As System.Windows.Forms.TextBox
    Friend WithEvents rtgsdt As System.Windows.Forms.TextBox
    Friend WithEvents chnoord4 As System.Windows.Forms.TextBox
    Friend WithEvents rtgsno As System.Windows.Forms.TextBox
    Friend WithEvents chnoord3 As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents chnoord2 As System.Windows.Forms.TextBox
    Friend WithEvents dtord4 As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents dtord3 As System.Windows.Forms.TextBox
    Friend WithEvents dtord2 As System.Windows.Forms.TextBox
    Friend WithEvents noord4 As System.Windows.Forms.TextBox
    Friend WithEvents noord3 As System.Windows.Forms.TextBox
    Friend WithEvents noord2 As System.Windows.Forms.TextBox
    Friend WithEvents recamtord1 As System.Windows.Forms.TextBox
    Friend WithEvents chnoord1 As System.Windows.Forms.TextBox
    Friend WithEvents noord1 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
End Class
