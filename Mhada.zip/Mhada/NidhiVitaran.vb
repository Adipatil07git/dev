﻿Imports System.Data.OleDb
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Public Class NidhiVitaran
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"
    Dim con, con1, con2, con3, con4 As New OleDbConnection(connectionString)
    Dim adapter As New OleDbDataAdapter()
    Dim str, str1, str2, str3, str4 As String
    Dim com, com1, com2, com3, com4 As OleDbCommand
    Dim oledbda As OleDbDataAdapter
    Dim ds, ds1, ds2, ds3, ds4 As DataSet
    Dim dt, dt1 As New DataTable
    Dim invdt As String
    Dim cmdOLEDB As New OleDbCommand
    Public dr, dr1 As OleDbDataReader
    Dim da As OleDb.OleDbDataAdapter
    Dim totadm, totexp, totbal, totpend, totfdrec, TempFndRec, billpd, tendbal As Int64
    Private Sub NidhiVitaran_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboHdNm.DropDownStyle = ComboBoxStyle.DropDownList
        ComboFdHd.DropDownStyle = ComboBoxStyle.DropDownList
        ComboAdmYr.DropDownStyle = ComboBoxStyle.DropDownList
        'ComboBox4.DropDownStyle = ComboBoxStyle.DropDownList
        'ComboBox5.DropDownStyle = ComboBoxStyle.DropDownList

        ComboADMno.DropDownStyle = ComboBoxStyle.DropDownList
        'ComboGP.DropDownStyle = ComboBoxStyle.DropDownList

        con.Open()

        'con.Open()
        str = "select Distinct Fund_Name from Testing"
        com = New OleDbCommand(str, con)
        oledbda = New OleDbDataAdapter(com)
        ds = New DataSet
        oledbda.Fill(ds, "Testing")
        ComboHdNm.DataSource = ds.Tables("Testing")
        ComboHdNm.ValueMember = "Fund_Name"
        ComboHdNm.DisplayMember = "Fund_Name"

        With Me.DataGridView1
            .Columns.Add("GP No", "GP No")
            .Columns.Add("ADM Amount", "ADM Amount")
            .Columns.Add("Fund Rec.", "Fund Rec.")
            .Columns.Add("Expenditure", "Expenditure")
            .Columns.Add("RTGS No", "RTGS No")
            .Columns.Add("RTGS Date", "RTGS Date")
            .Columns.Add("Status", "Status")

            .AllowUserToAddRows = False
            .EditMode = DataGridViewEditMode.EditProgrammatically
        End With

        DataGridView1.Columns(0).Width = 130
        DataGridView1.Columns(1).Width = 90
        DataGridView1.Columns(2).Width = 90
        DataGridView1.Columns(3).Width = 90
        DataGridView1.Columns(4).Width = 90
        DataGridView1.Columns(5).Width = 100
        DataGridView1.Columns(6).Width = 90

        DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DataGridView1.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        DataGridView1.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        DataGridView1.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

    End Sub
    Private Sub ComboHdNm_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboHdNm.SelectionChangeCommitted
        str1 = "select Distinct Mhada_Fund_Head from Testing where Fund_Name='" & ComboHdNm.SelectedValue & "' "
        com1 = New OleDbCommand(str1, con)
        oledbda = New OleDbDataAdapter(com1)
        ds = New DataSet
        oledbda.Fill(ds, "Testing")
        ComboFdHd.DataSource = ds.Tables("Testing")
        ComboFdHd.ValueMember = "Mhada_Fund_Head"
        ComboFdHd.DisplayMember = "Mhada_Fund_Head"
        'ComboGP.Focus()

    End Sub
    Private Sub ComboFdHd_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboFdHd.SelectionChangeCommitted
        str2 = "select Distinct ADM_Year from Testing where Fund_Name='" & ComboHdNm.SelectedValue & "' AND Mhada_Fund_Head ='" & ComboFdHd.SelectedValue & "'"
        com2 = New OleDbCommand(str2, con)
        oledbda = New OleDbDataAdapter(com2)
        ds = New DataSet
        oledbda.Fill(ds, "Testing")
        ComboAdmYr.DataSource = ds.Tables("Testing")
        ComboAdmYr.ValueMember = "ADM_Year"
        ComboAdmYr.DisplayMember = "ADM_Year"

    End Sub

    Private Sub ComboAdmYr_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboAdmYr.SelectionChangeCommitted
        str3 = "select Distinct ADM_No from Testing where Fund_Name='" & ComboHdNm.SelectedValue & "' AND Mhada_Fund_Head ='" & ComboFdHd.SelectedValue & "' AND ADM_Year ='" & ComboAdmYr.SelectedValue & "' "
        com3 = New OleDbCommand(str3, con)
        oledbda = New OleDbDataAdapter(com3)
        ds = New DataSet
        oledbda.Fill(ds, "Testing")
        ComboADMno.DataSource = ds.Tables("Testing")
        ComboADMno.ValueMember = "ADM_No"
        ComboADMno.DisplayMember = "ADM_No"

    End Sub
    Private Sub ComboADMno_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboADMno.SelectionChangeCommitted
        Dim dt As New DataTable
        DataGridView1.DataMember = Nothing

        Dim totadmamt, totfndrec As Int64
        totadmamt = totfndrec = 0

        'ADMamt.Text = ""
        noord1.Text = ""
        noord2.Text = ""
        noord3.Text = ""
        noord4.Text = ""
        dtord1.Text = ""
        dtord2.Text = ""
        dtord3.Text = ""
        dtord4.Text = ""
        chnoord1.Text = ""
        chnoord2.Text = ""
        chnoord3.Text = ""
        chnoord4.Text = ""
        chdtord1.Text = ""
        chdtord2.Text = ""
        chdtord3.Text = ""
        chdtord4.Text = ""
        recamtord1.Text = ""
        recamtord2.Text = ""
        recamtord2.Text = ""
        recamtord3.Text = ""
        recamtord4.Text = ""
        TotRecAmt.Text = ""
        rtgsdt.Text = ""
        rtgsno.Text = ""
        TextAmtadm.Text = ""
        TextBillPass.Text = ""
        TextFRec.Text = ""
        TextEx.Text = ""
        TextBFund.Text = ""
        TextTend.Text = ""
        TextFDemand.Text = ""

        str1 = "select Distinct GP_No from Testing where ADM_No='" & ComboADMno.SelectedValue & "'"
        com1 = New OleDbCommand(str1, con)
        oledbda = New OleDbDataAdapter(com1)
        ds = New DataSet
        oledbda.Fill(ds, "Testing")
        ComboGP.DataSource = ds.Tables("Testing")
        ComboGP.ValueMember = "GP_No"
        ComboGP.DisplayMember = "GP_No"

        da = New OleDbDataAdapter("SELECT * FROM Testing where ADM_No = '" & ComboADMno.SelectedValue & "' ", con)
        da.Fill(dt)

        totadm = 0
        totexp = 0
        totbal = 0
        totpend = 0
        totfdrec = 0
        billpd = 0
        tendbal = 0

        For Each dr1 As DataRow In dt.Rows
            Me.DataGridView1.Rows.Add()
            With Me.DataGridView1.Rows(Me.DataGridView1.Rows.Count - 1)
                .Cells("GP No").Value = dr1("GP_No")
                .Cells("ADM Amount").Value = dr1("ADM_Amt")
                .Cells("Fund Rec.").Value = dr1("Tot_Fund_Rec")
                .Cells("Expenditure").Value = dr1("Exp_Amt")
                .Cells("RTGS No").Value = dr1("Cheque_Rtgs_No")
                .Cells("RTGS Date").Value = dr1("Cheque_Date")

                totadm = totadm + Val(dr1("ADM_Amt").ToString)
                totexp = totexp + Val(dr1("Exp_Amt").ToString)
                totbal = totbal + Val(dr1("Tender_Bal_Amt").ToString)
                totpend = totpend + Val(dr1("Pending_Work_Amt").ToString)
                totfdrec = totfdrec + Val(dr1("Tot_Fund_Rec").ToString)
                If Len(dr1("Cheque_Rtgs_No").ToString) > 0 Then
                    billpd = billpd + Val(dr1("Exp_Amt").ToString)
                    tendbal = tendbal + Val(dr1("Tender_Bal_Amt").ToString)
                    .Cells("Status").Value = "Paid"
                Else
                    .Cells("Status").Value = "UnPaid"
                End If
            End With
        Next

        TextADM.Text = totadm
        TextExp.Text = totexp
        TextFdRec.Text = totfdrec
        BalFund.Text = totfdrec - billpd
        FundDemand.Text = totexp - totfdrec
        BillPaid.Text = billpd
        TenderBal.Text = tendbal
    End Sub

    Private Sub ComboGP_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboGP.SelectedValueChanged

    End Sub
    Private Sub ComboGP_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboGP.SelectionChangeCommitted
        data1()

    End Sub
    Public Sub data1()
        TextTend.Text = ""
        TextBFund.Text = ""
        TextEx.Text = ""
        TextFRec.Text = ""
        TextBillPass.Text = ""

        str2 = "select * from Testing where ADM_No='" & ComboADMno.SelectedValue & "' AND GP_NO='" & ComboGP.SelectedValue & "' "
        com2 = New OleDbCommand(str2, con)
        dr = com2.ExecuteReader
        While dr.Read()
            rtgsno.Text = dr("Cheque_Rtgs_No").ToString
            rtgsdt.Text = dr("Cheque_Date").ToString
            If Len(rtgsdt.Text) > 10 Then
                rtgsdt.Text = rtgsdt.Text.Substring(0, 10)
            End If

            TextAmtadm.Text = dr("ADM_Amt").ToString
            TextBillPass.Text = dr("Exp_Amt").ToString
            TextFRec.Text = dr("Tot_Fund_Rec").ToString
            If Len(dr("Cheque_Rtgs_No").ToString) > 0 Then
                TextEx.Text = dr("Exp_Amt").ToString
            End If
            TextBFund.Text = Val(TextFRec.Text) - Val(TextEx.Text)
            TextTend.Text = dr("Tender_Bal_Amt").ToString

            noord1.Text = dr("Fund_Rec_Order1").ToString

            dtord1.Text = dr("Order1_Date").ToString
            If Len(dr("Order1_Date").ToString) > 10 Then
                dtord1.Text = dtord1.Text.Substring(0, 10)
                'DateTimePicker1.Text = dr("Order1_Date").ToString
            End If

            chnoord1.Text = dr("Order1_Cheque_No").ToString
            chdtord1.Text = dr("Order1_Cheque_Date").ToString
            If Len(chdtord1.Text) > 10 Then
                chdtord1.Text = chdtord1.Text.Substring(0, 10)
            End If
            recamtord1.Text = dr("Order1_Rec_Amt").ToString

            noord2.Text = dr("Fund_Rec_Order2").ToString
            dtord2.Text = dr("Order2_Date").ToString
            If Len(dtord2.Text) > 10 Then
                dtord2.Text = dtord2.Text.Substring(0, 10)
            End If
            chnoord2.Text = dr("Order2_Cheque_No").ToString
            chdtord2.Text = dr("Order2_Cheque_Date").ToString
            If Len(chdtord2.Text) > 10 Then
                chdtord2.Text = chdtord2.Text.Substring(0, 10)
            End If
            recamtord2.Text = dr("Order2_Rec_Amt").ToString

            noord3.Text = dr("Fund_Rec_Order3").ToString
            dtord3.Text = dr("Order3_Date").ToString
            If Len(dtord3.Text) > 10 Then
                dtord3.Text = dtord3.Text.Substring(0, 10)
            End If
            chnoord3.Text = dr("Order3_Cheque_No").ToString
            chdtord3.Text = dr("Order3_Cheque_Date").ToString
            If Len(chdtord3.Text) > 10 Then
                chdtord3.Text = chdtord3.Text.Substring(0, 10)
            End If
            recamtord3.Text = dr("Order3_Rec_Amt").ToString

            noord4.Text = dr("Fund_Rec_Order4").ToString
            dtord4.Text = dr("Order4_Date").ToString
            If Len(dtord4.Text) > 10 Then
                dtord4.Text = dtord4.Text.Substring(0, 10)
            End If
            chnoord4.Text = dr("Order4_Cheque_No").ToString
            chdtord4.Text = dr("Order4_Cheque_Date").ToString
            If Len(chdtord4.Text) > 10 Then
                chdtord4.Text = chdtord4.Text.Substring(0, 10)
            End If
            recamtord4.Text = dr("Order4_Rec_Amt").ToString

            TotRecAmt.Text = Val(dr("Order1_Rec_Amt").ToString) + Val(dr("Order2_Rec_Amt").ToString) + Val(dr("Order3_Rec_Amt").ToString) + Val(dr("Order4_Rec_Amt").ToString)
        End While

        TempFndRec = totfdrec - Val(TotRecAmt.Text)
        TextFDemand.Text = Val(TextEx.Text) - Val(TextFRec.Text)
        FundDemand.Text = totexp - totfdrec

    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)



        'str = "update Testing set Fund_Rec_Order1 ='" & noord1.Text & "', Order1_Date = '" & dtord1.Text & "', Order1_Cheque_No='" & chnoord1.Text & "', Order1_Cheque_Date='" & chdtord1.Text & "', Order1_Rec_Amt='" & recamtord1.Text & "', Tot_Fund_Rec='" & recamtord1.Text & "', UpdatedAt='" & Now() & "', UpdatedBy='Admin' where ADM_No = '" & ComboADMno.SelectedValue & "' AND GP_No = '" & ComboGP.SelectedValue & "' "


    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        con.Close()
        Me.Close()
    End Sub

    Public Sub List()
    End Sub
    Private Sub recamtord1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles recamtord1.TextChanged
        TotRecAmt.Text = Val(recamtord1.Text) + Val(recamtord2.Text) + Val(recamtord3.Text) + Val(recamtord4.Text)

        totfdrec = TempFndRec + Val(TotRecAmt.Text)

        If Val(TotRecAmt.Text) > Val(TextAmtadm.Text) Then
            MsgBox("Received Amount is invalid.")
            recamtord1.Text = 0
            recamtord1.Focus()
        Else

        End If

        If Val(totfdrec) > Val(totadm) Then
            MsgBox("Received Fund is invalid.")
            'recamtord1.Text = ""
            recamtord1.Focus()
        Else

        End If


    End Sub

    Private Sub recamtord2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles recamtord2.TextChanged
        TotRecAmt.Text = Val(recamtord1.Text) + Val(recamtord2.Text) + Val(recamtord3.Text) + Val(recamtord4.Text)

        If Val(TotRecAmt.Text) > Val(TextAmtadm.Text) Then
            MsgBox("Received Amount is invalid")
            'recamtord2.Text = ""
            recamtord2.Focus()
        Else

        End If

    End Sub

    Private Sub recamtord3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles recamtord3.TextChanged
        TotRecAmt.Text = Val(recamtord1.Text) + Val(recamtord2.Text) + Val(recamtord3.Text) + Val(recamtord4.Text)

        If Val(TotRecAmt.Text) > Val(TextAmtadm.Text) Then
            MsgBox("Received Amount is invalid")
            'recamtord3.Text = ""
            recamtord3.Focus()
        Else

        End If

    End Sub

    Private Sub recamtord4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles recamtord4.TextChanged
        TotRecAmt.Text = Val(recamtord1.Text) + Val(recamtord2.Text) + Val(recamtord3.Text) + Val(recamtord4.Text)

        If Val(TotRecAmt.Text) > Val(TextAmtadm.Text) Then
            MsgBox("Received Amount is invalid")
            'recamtord4.Text = ""
            recamtord4.Focus()
        Else

        End If

    End Sub
    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            ButtonO1.Visible = True

            noord1.ReadOnly = False
            dtord1.ReadOnly = False
            chnoord1.ReadOnly = False
            chdtord1.ReadOnly = False
            recamtord1.ReadOnly = False
        Else
            ButtonO1.Visible = False

            noord1.ReadOnly = True
            dtord1.ReadOnly = True
            chnoord1.ReadOnly = True
            chdtord1.ReadOnly = True
            recamtord1.ReadOnly = True
        End If
    End Sub
    Private Sub ButtonO1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonO1.Click
        If CheckBox1.Checked = True Then
            If noord1.Text = String.Empty Then
                MsgBox("Please Enter Order Number.")
                noord1.Focus()
            ElseIf dtord1.Text = String.Empty Then
                MsgBox("Please Enter Order Date.")
                dtord1.Focus()
            ElseIf chnoord1.Text = String.Empty Then
                MsgBox("Please Enter Order cheque Number.")
                chnoord1.Focus()
            ElseIf chdtord1.Text = String.Empty Then
                MsgBox("Please Enter Order cheque Date.")
                chdtord1.Focus()
            ElseIf recamtord1.Text = String.Empty Or Val(recamtord1.Text) = 0 Then
                MsgBox("Please Enter Received amount.")
                recamtord1.Focus()
            Else

                str = "update Testing set Fund_Rec_Order1 ='" & noord1.Text & "', Order1_Date = '" & dtord1.Text & "', Order1_Cheque_No='" & chnoord1.Text & "', Order1_Cheque_Date='" & chdtord1.Text & "', Order1_Rec_Amt='" & recamtord1.Text & "', Tot_Fund_Rec ='" & (Val(recamtord1.Text) + Val(recamtord2.Text) + Val(recamtord3.Text) + Val(recamtord4.Text)) & "', UpdatedAt='" & Now() & "', UpdatedBy='Admin' where ADM_No = '" & ComboADMno.SelectedValue & "' AND GP_No = '" & ComboGP.SelectedValue & "' "
                Dim cmd As OleDbCommand = New OleDbCommand(str, con)
                Try
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    Dim result = MessageBox.Show("Data successfully Saved.", "MHADA")
                    'con.Close()
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
                CheckBox1.Checked = False
                ButtonO1.Visible = False


            End If
        End If
        data1()

    End Sub
    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        If Len(noord1.Text) > 0 And Len(dtord1.Text) > 0 And Len(chnoord1.Text) > 0 And Val(recamtord1.Text) > 0 And (Val(TextAmtadm.Text) - Val(TotRecAmt.Text) <> 0) Then
            If CheckBox2.Checked = True Then
                ButtonO2.Visible = True

                noord2.ReadOnly = False
                dtord2.ReadOnly = False
                chnoord2.ReadOnly = False
                chdtord2.ReadOnly = False
                recamtord2.ReadOnly = False
            Else
                ButtonO2.Visible = False

                noord2.ReadOnly = True
                dtord2.ReadOnly = True
                chnoord2.ReadOnly = True
                chdtord2.ReadOnly = True
                recamtord2.ReadOnly = True
            End If
        Else
            MsgBox("Order No. 1 entry is not completed / No Balance Fund.")
            CheckBox2.Checked = False

        End If

    End Sub
    Private Sub ButtonO2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonO2.Click
        If CheckBox2.Checked = True Then
            If noord2.Text = String.Empty Then
                MsgBox("Please Enter Order Number.")
                noord2.Focus()
            ElseIf dtord2.Text = String.Empty Then
                MsgBox("Please Enter Order Date.")
                dtord2.Focus()
            ElseIf chnoord2.Text = String.Empty Then
                MsgBox("Please Enter Order cheque Number.")
                chnoord2.Focus()
            ElseIf chdtord2.Text = String.Empty Then
                MsgBox("Please Enter Order cheque Date.")
                chdtord2.Focus()
            ElseIf recamtord2.Text = String.Empty Or Val(recamtord2.Text) = 0 Then
                MsgBox("Please Enter Received amount.")
                recamtord2.Focus()
            Else


                str = "update Testing set Fund_Rec_Order2 ='" & noord2.Text & "', Order2_Date = '" & dtord2.Text & "', Order2_Cheque_No='" & chnoord2.Text & "', Order2_Cheque_Date='" & chdtord2.Text & "', Order2_Rec_Amt='" & recamtord2.Text & "', Tot_Fund_Rec ='" & (Val(recamtord1.Text) + Val(recamtord2.Text) + Val(recamtord3.Text) + Val(recamtord4.Text)) & "', UpdatedAt='" & Now() & "', UpdatedBy='Admin' where ADM_No = '" & ComboADMno.SelectedValue & "' AND GP_No = '" & ComboGP.SelectedValue & "' "
                Dim cmd As OleDbCommand = New OleDbCommand(str, con)
                Try
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    Dim result = MessageBox.Show("Data successfully Saved.", "MHADA")
                    'con.Close()
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
                CheckBox2.Checked = False
                ButtonO2.Visible = False

            End If
        End If
        data1()

    End Sub

    Private Sub CheckBox3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox3.CheckedChanged
        If Len(noord2.Text) > 0 And Len(dtord2.Text) > 0 And Len(chnoord2.Text) > 0 And Val(recamtord2.Text) > 0 And (Val(TextAmtadm.Text) - Val(TotRecAmt.Text) <> 0) Then

            If CheckBox3.Checked = True Then
                ButtonO3.Visible = True

                noord3.ReadOnly = False
                dtord3.ReadOnly = False
                chnoord3.ReadOnly = False
                chdtord3.ReadOnly = False
                recamtord3.ReadOnly = False
            Else
                ButtonO3.Visible = False

                noord3.ReadOnly = True
                dtord3.ReadOnly = True
                chnoord3.ReadOnly = True
                chdtord3.ReadOnly = True
                recamtord3.ReadOnly = True
            End If
        Else
            MsgBox("Order No. 2 entry is not completed / No Balance Fund.")
            CheckBox3.Checked = False

        End If

    End Sub


    Private Sub ButtonO3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonO3.Click
        If CheckBox3.Checked = True Then
            If noord3.Text = String.Empty Then
                MsgBox("Please Enter Order Number.")
                noord3.Focus()
            ElseIf dtord3.Text = String.Empty Then
                MsgBox("Please Enter Order Date.")
                dtord3.Focus()
            ElseIf chnoord3.Text = String.Empty Then
                MsgBox("Please Enter Order cheque Number.")
                chnoord3.Focus()
            ElseIf chdtord3.Text = String.Empty Then
                MsgBox("Please Enter Order cheque Date.")
                chdtord3.Focus()
            ElseIf recamtord3.Text = String.Empty Or Val(recamtord3.Text) = 0 Then
                MsgBox("Please Enter Received amount.")
                recamtord3.Focus()
            Else

                str = "update Testing set Fund_Rec_Order3 ='" & noord3.Text & "', Order3_Date = '" & dtord3.Text & "', Order3_Cheque_No='" & chnoord3.Text & "', Order3_Cheque_Date='" & chdtord3.Text & "', Order3_Rec_Amt='" & recamtord3.Text & "', UpdatedAt='" & Now() & "', Tot_Fund_Rec ='" & (Val(recamtord1.Text) + Val(recamtord2.Text) + Val(recamtord3.Text) + Val(recamtord4.Text)) & "' , UpdatedBy='Admin' where ADM_No = '" & ComboADMno.SelectedValue & "' AND GP_No = '" & ComboGP.SelectedValue & "' "
                Dim cmd As OleDbCommand = New OleDbCommand(str, con)
                Try
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    Dim result = MessageBox.Show("Data successfully Saved.", "MHADA")
                    'con.Close()
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
                CheckBox3.Checked = False
                ButtonO3.Visible = False

            End If
        End If
        data1()

    End Sub
    Private Sub CheckBox4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox4.CheckedChanged

        If Len(noord3.Text) > 0 And Len(dtord3.Text) > 0 And Len(chnoord3.Text) > 0 And Val(recamtord3.Text) > 0 Then
            'recamtord4.ReadOnly = True
            recamtord4.Text = Val(TextAmtadm.Text) - Val(Val(recamtord1.Text) + Val(recamtord2.Text) + Val(recamtord3.Text))

            If CheckBox4.Checked = True Then
                ButtonO4.Visible = True

                noord4.ReadOnly = False
                dtord4.ReadOnly = False
                chnoord4.ReadOnly = False
                chdtord4.ReadOnly = False
                'recamtord4.ReadOnly = False
            Else
                ButtonO4.Visible = False

                noord4.ReadOnly = True
                dtord4.ReadOnly = True
                chnoord4.ReadOnly = True
                chdtord4.ReadOnly = True
                recamtord4.ReadOnly = True
            End If
        Else
            MsgBox("Order No. 3 entry is not completed / No Balance Fund.")
            CheckBox4.Checked = False

        End If

    End Sub

    Private Sub ButtonO4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonO4.Click
        If CheckBox4.Checked = True Then
            If noord4.Text = String.Empty Then
                MsgBox("Please Enter Order Number.")
                noord4.Focus()
            ElseIf dtord4.Text = String.Empty Then
                MsgBox("Please Enter Order Date.")
                dtord4.Focus()
            ElseIf chnoord4.Text = String.Empty Then
                MsgBox("Please Enter Order cheque Number.")
                chnoord4.Focus()
            ElseIf chdtord3.Text = String.Empty Then
                MsgBox("Please Enter Order cheque Date.")
                chdtord4.Focus()
            ElseIf recamtord4.Text = String.Empty Or Val(recamtord4.Text) = 0 Then
                MsgBox("Please Enter Received amount.")
                recamtord4.Focus()
            Else

                str = "update Testing set Fund_Rec_Order4 ='" & noord4.Text & "', Order4_Date = '" & dtord4.Text & "', Order4_Cheque_No='" & chnoord4.Text & "', Order4_Cheque_Date='" & chdtord4.Text & "', Order4_Rec_Amt='" & recamtord4.Text & "' , Tot_Fund_Rec ='" & (Val(recamtord1.Text) + Val(recamtord2.Text) + Val(recamtord3.Text) + Val(recamtord4.Text)) & "', UpdatedAt='" & Now() & "', UpdatedBy='Admin' where ADM_No = '" & ComboADMno.SelectedValue & "' AND GP_No = '" & ComboGP.SelectedValue & "' "
                Dim cmd As OleDbCommand = New OleDbCommand(str, con)
                Try
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    Dim result = MessageBox.Show("Data successfully Saved.", "MHADA")
                    'con.Close()
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
                CheckBox4.Checked = False
                ButtonO4.Visible = False

            End If
        End If
        data1()

    End Sub

    Private Sub ComboGP_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboGP.SelectedIndexChanged

    End Sub
End Class