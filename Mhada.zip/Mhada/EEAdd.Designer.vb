﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EEAdd
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Button_Exit = New System.Windows.Forms.Button
        Me.Button_save = New System.Windows.Forms.Button
        Me.txtEE = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.EENameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.EElistBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MhadaDataSet2 = New Mhada.mhadaDataSet2
        Me.EElistTableAdapter = New Mhada.mhadaDataSet2TableAdapters.EElistTableAdapter
        Me.Label9 = New System.Windows.Forms.Label
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EElistBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MhadaDataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button_Exit
        '
        Me.Button_Exit.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Button_Exit.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Exit.Location = New System.Drawing.Point(347, 161)
        Me.Button_Exit.Margin = New System.Windows.Forms.Padding(7, 9, 7, 9)
        Me.Button_Exit.Name = "Button_Exit"
        Me.Button_Exit.Size = New System.Drawing.Size(76, 44)
        Me.Button_Exit.TabIndex = 92
        Me.Button_Exit.Text = "Close"
        Me.Button_Exit.UseVisualStyleBackColor = False
        '
        'Button_save
        '
        Me.Button_save.BackColor = System.Drawing.Color.PaleGreen
        Me.Button_save.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_save.Location = New System.Drawing.Point(136, 161)
        Me.Button_save.Margin = New System.Windows.Forms.Padding(7, 9, 7, 9)
        Me.Button_save.Name = "Button_save"
        Me.Button_save.Size = New System.Drawing.Size(69, 44)
        Me.Button_save.TabIndex = 91
        Me.Button_save.Text = "Save"
        Me.Button_save.UseVisualStyleBackColor = False
        '
        'txtEE
        '
        Me.txtEE.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtEE.Location = New System.Drawing.Point(136, 100)
        Me.txtEE.Margin = New System.Windows.Forms.Padding(7)
        Me.txtEE.MaxLength = 50
        Me.txtEE.Name = "txtEE"
        Me.txtEE.Size = New System.Drawing.Size(287, 26)
        Me.txtEE.TabIndex = 87
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(59, 103)
        Me.Label2.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 20)
        Me.Label2.TabIndex = 89
        Me.Label2.Text = "Name  :"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Monotype Corsiva", 24.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(79, 9)
        Me.Label8.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(413, 39)
        Me.Label8.TabIndex = 109
        Me.Label8.Text = "Executive Engineer Entry Form"
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.EENameDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.EElistBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(136, 271)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(287, 205)
        Me.DataGridView1.TabIndex = 110
        '
        'EENameDataGridViewTextBoxColumn
        '
        Me.EENameDataGridViewTextBoxColumn.DataPropertyName = "EE_Name"
        Me.EENameDataGridViewTextBoxColumn.HeaderText = "EE_Name"
        Me.EENameDataGridViewTextBoxColumn.Name = "EENameDataGridViewTextBoxColumn"
        '
        'EElistBindingSource
        '
        Me.EElistBindingSource.DataMember = "EElist"
        Me.EElistBindingSource.DataSource = Me.MhadaDataSet2
        '
        'MhadaDataSet2
        '
        Me.MhadaDataSet2.DataSetName = "mhadaDataSet2"
        Me.MhadaDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'EElistTableAdapter
        '
        Me.EElistTableAdapter.ClearBeforeFill = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial Rounded MT Bold", 15.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(205, 244)
        Me.Label9.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(144, 24)
        Me.Label9.TabIndex = 111
        Me.Label9.Text = "Engineer List"
        '
        'AddEE
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(570, 501)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Button_Exit)
        Me.Controls.Add(Me.Button_save)
        Me.Controls.Add(Me.txtEE)
        Me.Controls.Add(Me.Label2)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "AddEE"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Add New Junior Engineer"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EElistBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MhadaDataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button_Exit As System.Windows.Forms.Button
    Friend WithEvents Button_save As System.Windows.Forms.Button
    Friend WithEvents txtEE As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents MhadaDataSet2 As Mhada.mhadaDataSet2
    Friend WithEvents EElistBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents EElistTableAdapter As Mhada.mhadaDataSet2TableAdapters.EElistTableAdapter
    Friend WithEvents EENameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label9 As System.Windows.Forms.Label
End Class
