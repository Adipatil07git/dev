﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ADMentry
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox
        Me.ComboDiv = New System.Windows.Forms.ComboBox
        Me.txtwrknm = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.txtfundhdm = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtgpno = New System.Windows.Forms.TextBox
        Me.txtadmamt = New System.Windows.Forms.TextBox
        Me.txtadmno = New System.Windows.Forms.TextBox
        Me.txtfundhd = New System.Windows.Forms.TextBox
        Me.dateadm = New System.Windows.Forms.DateTimePicker
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Button2 = New System.Windows.Forms.Button
        Me.ButtonSv = New System.Windows.Forms.Button
        Me.ComboMPMLA = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.ComboFdNm = New System.Windows.Forms.ComboBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.TextNoWork = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.TextTotAdmAmt = New System.Windows.Forms.TextBox
        Me.ButtonSubmit = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.AddItem = New System.Windows.Forms.Button
        Me.Label14 = New System.Windows.Forms.Label
        Me.TextB1no = New System.Windows.Forms.TextBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.Textsubtot = New System.Windows.Forms.TextBox
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.ListBox3 = New System.Windows.Forms.ListBox
        Me.ListBox2 = New System.Windows.Forms.ListBox
        Me.ListBox4 = New System.Windows.Forms.ListBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.ListBox5 = New System.Windows.Forms.ListBox
        Me.ListBox6 = New System.Windows.Forms.ListBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.ButtonResetADM = New System.Windows.Forms.Button
        Me.Button5 = New System.Windows.Forms.Button
        Me.ComboAgrYr = New System.Windows.Forms.ComboBox
        Me.GroupBox2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'ComboBox2
        '
        Me.ComboBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"2022-23", "2023-24", "2024-25"})
        Me.ComboBox2.Location = New System.Drawing.Point(998, 21)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(146, 28)
        Me.ComboBox2.TabIndex = 5
        '
        'ComboDiv
        '
        Me.ComboDiv.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboDiv.FormattingEnabled = True
        Me.ComboDiv.ItemHeight = 20
        Me.ComboDiv.Items.AddRange(New Object() {"City", "East", "West"})
        Me.ComboDiv.Location = New System.Drawing.Point(122, 18)
        Me.ComboDiv.Name = "ComboDiv"
        Me.ComboDiv.Size = New System.Drawing.Size(213, 28)
        Me.ComboDiv.TabIndex = 2
        '
        'txtwrknm
        '
        Me.txtwrknm.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtwrknm.Location = New System.Drawing.Point(184, 90)
        Me.txtwrknm.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtwrknm.Name = "txtwrknm"
        Me.txtwrknm.Size = New System.Drawing.Size(554, 26)
        Me.txtwrknm.TabIndex = 17
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(16, 93)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(100, 20)
        Me.Label15.TabIndex = 235
        Me.Label15.Text = "Work Name :"
        '
        'txtfundhdm
        '
        Me.txtfundhdm.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtfundhdm.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtfundhdm.Location = New System.Drawing.Point(998, 64)
        Me.txtfundhdm.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtfundhdm.MaxLength = 30
        Me.txtfundhdm.Name = "txtfundhdm"
        Me.txtfundhdm.ReadOnly = True
        Me.txtfundhdm.Size = New System.Drawing.Size(200, 19)
        Me.txtfundhdm.TabIndex = 10000
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(388, 59)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(135, 20)
        Me.Label13.TabIndex = 233
        Me.Label13.Text = "Fund Head Govt.:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(827, 63)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(160, 20)
        Me.Label5.TabIndex = 232
        Me.Label5.Text = "Fund Head MHADA :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(10, 60)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(92, 20)
        Me.Label4.TabIndex = 231
        Me.Label4.Text = "Fund Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(388, 21)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(131, 20)
        Me.Label2.TabIndex = 229
        Me.Label2.Text = "MP / MLA Name :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 20)
        Me.Label1.TabIndex = 228
        Me.Label1.Text = "Division :"
        '
        'txtgpno
        '
        Me.txtgpno.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgpno.Location = New System.Drawing.Point(184, 18)
        Me.txtgpno.Margin = New System.Windows.Forms.Padding(5)
        Me.txtgpno.MaxLength = 30
        Me.txtgpno.Name = "txtgpno"
        Me.txtgpno.Size = New System.Drawing.Size(213, 26)
        Me.txtgpno.TabIndex = 13
        '
        'txtadmamt
        '
        Me.txtadmamt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtadmamt.Location = New System.Drawing.Point(579, 21)
        Me.txtadmamt.Margin = New System.Windows.Forms.Padding(5)
        Me.txtadmamt.MaxLength = 12
        Me.txtadmamt.Name = "txtadmamt"
        Me.txtadmamt.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txtadmamt.Size = New System.Drawing.Size(159, 26)
        Me.txtadmamt.TabIndex = 14
        '
        'txtadmno
        '
        Me.txtadmno.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtadmno.Location = New System.Drawing.Point(122, 101)
        Me.txtadmno.Margin = New System.Windows.Forms.Padding(5)
        Me.txtadmno.Name = "txtadmno"
        Me.txtadmno.Size = New System.Drawing.Size(107, 26)
        Me.txtadmno.TabIndex = 7
        '
        'txtfundhd
        '
        Me.txtfundhd.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtfundhd.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtfundhd.Location = New System.Drawing.Point(557, 61)
        Me.txtfundhd.Margin = New System.Windows.Forms.Padding(5)
        Me.txtfundhd.MaxLength = 30
        Me.txtfundhd.Name = "txtfundhd"
        Me.txtfundhd.ReadOnly = True
        Me.txtfundhd.Size = New System.Drawing.Size(212, 19)
        Me.txtfundhd.TabIndex = 800
        '
        'dateadm
        '
        Me.dateadm.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dateadm.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dateadm.Location = New System.Drawing.Point(302, 102)
        Me.dateadm.Margin = New System.Windows.Forms.Padding(5)
        Me.dateadm.Name = "dateadm"
        Me.dateadm.Size = New System.Drawing.Size(116, 26)
        Me.dateadm.TabIndex = 8
        Me.dateadm.Value = New Date(2023, 9, 2, 13, 15, 27, 0)
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(15, 21)
        Me.Label10.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(165, 20)
        Me.Label10.TabIndex = 220
        Me.Label10.Text = "GP / MLA / Serail  No :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(437, 21)
        Me.Label9.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(113, 20)
        Me.Label9.TabIndex = 219
        Me.Label9.Text = "ADM Amount :"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(241, 105)
        Me.Label8.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(52, 20)
        Me.Label8.TabIndex = 218
        Me.Label8.Text = "Date :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(14, 104)
        Me.Label7.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(77, 20)
        Me.Label7.TabIndex = 217
        Me.Label7.Text = "ADM No :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(828, 21)
        Me.Label6.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(91, 20)
        Me.Label6.TabIndex = 216
        Me.Label6.Text = "ADM Year :"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Turquoise
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(1090, 537)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(81, 52)
        Me.Button2.TabIndex = 28
        Me.Button2.Text = "Close"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'ButtonSv
        '
        Me.ButtonSv.BackColor = System.Drawing.Color.LightGreen
        Me.ButtonSv.Enabled = False
        Me.ButtonSv.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSv.Location = New System.Drawing.Point(1090, 419)
        Me.ButtonSv.Name = "ButtonSv"
        Me.ButtonSv.Size = New System.Drawing.Size(81, 52)
        Me.ButtonSv.TabIndex = 27
        Me.ButtonSv.Text = "Save "
        Me.ButtonSv.UseVisualStyleBackColor = False
        '
        'ComboMPMLA
        '
        Me.ComboMPMLA.FormattingEnabled = True
        Me.ComboMPMLA.Location = New System.Drawing.Point(568, 18)
        Me.ComboMPMLA.Name = "ComboMPMLA"
        Me.ComboMPMLA.Size = New System.Drawing.Size(212, 28)
        Me.ComboMPMLA.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Cambria", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(558, 2)
        Me.Label3.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(194, 28)
        Me.Label3.TabIndex = 236
        Me.Label3.Text = "ADM Entry Form"
        '
        'ComboFdNm
        '
        Me.ComboFdNm.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboFdNm.FormattingEnabled = True
        Me.ComboFdNm.ItemHeight = 20
        Me.ComboFdNm.Items.AddRange(New Object() {"City", "East", "West"})
        Me.ComboFdNm.Location = New System.Drawing.Point(122, 55)
        Me.ComboFdNm.Name = "ComboFdNm"
        Me.ComboFdNm.Size = New System.Drawing.Size(213, 28)
        Me.ComboFdNm.TabIndex = 3
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(427, 104)
        Me.Label11.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(132, 20)
        Me.Label11.TabIndex = 237
        Me.Label11.Text = "Number of Works"
        '
        'TextNoWork
        '
        Me.TextNoWork.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextNoWork.Location = New System.Drawing.Point(568, 101)
        Me.TextNoWork.Margin = New System.Windows.Forms.Padding(5)
        Me.TextNoWork.MaxLength = 3
        Me.TextNoWork.Name = "TextNoWork"
        Me.TextNoWork.Size = New System.Drawing.Size(112, 26)
        Me.TextNoWork.TabIndex = 9
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(705, 105)
        Me.Label12.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(152, 20)
        Me.Label12.TabIndex = 239
        Me.Label12.Text = "Total ADM Amount :"
        '
        'TextTotAdmAmt
        '
        Me.TextTotAdmAmt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextTotAdmAmt.Location = New System.Drawing.Point(867, 102)
        Me.TextTotAdmAmt.Margin = New System.Windows.Forms.Padding(5)
        Me.TextTotAdmAmt.MaxLength = 12
        Me.TextTotAdmAmt.Name = "TextTotAdmAmt"
        Me.TextTotAdmAmt.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextTotAdmAmt.Size = New System.Drawing.Size(118, 26)
        Me.TextTotAdmAmt.TabIndex = 10
        '
        'ButtonSubmit
        '
        Me.ButtonSubmit.BackColor = System.Drawing.Color.LightGreen
        Me.ButtonSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSubmit.Location = New System.Drawing.Point(1113, 93)
        Me.ButtonSubmit.Name = "ButtonSubmit"
        Me.ButtonSubmit.Size = New System.Drawing.Size(85, 42)
        Me.ButtonSubmit.TabIndex = 11
        Me.ButtonSubmit.Text = "Submit"
        Me.ButtonSubmit.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.TextTotAdmAmt)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.ComboMPMLA)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.TextNoWork)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.ButtonSubmit)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.dateadm)
        Me.GroupBox2.Controls.Add(Me.txtfundhd)
        Me.GroupBox2.Controls.Add(Me.ComboFdNm)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.txtadmno)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.ComboBox2)
        Me.GroupBox2.Controls.Add(Me.txtfundhdm)
        Me.GroupBox2.Controls.Add(Me.ComboDiv)
        Me.GroupBox2.Location = New System.Drawing.Point(27, 33)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(1198, 143)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        '
        'AddItem
        '
        Me.AddItem.Font = New System.Drawing.Font("Arial Rounded MT Bold", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddItem.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.AddItem.Location = New System.Drawing.Point(829, 268)
        Me.AddItem.Margin = New System.Windows.Forms.Padding(5)
        Me.AddItem.Name = "AddItem"
        Me.AddItem.Size = New System.Drawing.Size(65, 38)
        Me.AddItem.TabIndex = 18
        Me.AddItem.Text = "Add"
        Me.AddItem.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(17, 54)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(70, 20)
        Me.Label14.TabIndex = 246
        Me.Label14.Text = "B-1 No. :"
        '
        'TextB1no
        '
        Me.TextB1no.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextB1no.Location = New System.Drawing.Point(184, 54)
        Me.TextB1no.Margin = New System.Windows.Forms.Padding(5)
        Me.TextB1no.MaxLength = 30
        Me.TextB1no.Name = "TextB1no"
        Me.TextB1no.Size = New System.Drawing.Size(213, 26)
        Me.TextB1no.TabIndex = 15
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(437, 58)
        Me.Label16.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(134, 20)
        Me.Label16.TabIndex = 235
        Me.Label16.Text = "Agreement Year :"
        '
        'Textsubtot
        '
        Me.Textsubtot.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Textsubtot.Location = New System.Drawing.Point(894, 639)
        Me.Textsubtot.Margin = New System.Windows.Forms.Padding(5)
        Me.Textsubtot.MaxLength = 12
        Me.Textsubtot.Name = "Textsubtot"
        Me.Textsubtot.ReadOnly = True
        Me.Textsubtot.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Textsubtot.Size = New System.Drawing.Size(96, 26)
        Me.Textsubtot.TabIndex = 248
        '
        'ListBox1
        '
        Me.ListBox1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.ListBox1.BackColor = System.Drawing.SystemColors.Control
        Me.ListBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 16
        Me.ListBox1.Location = New System.Drawing.Point(2, 40)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.ListBox1.Size = New System.Drawing.Size(53, 242)
        Me.ListBox1.TabIndex = 44
        '
        'ListBox3
        '
        Me.ListBox3.BackColor = System.Drawing.SystemColors.Control
        Me.ListBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox3.FormattingEnabled = True
        Me.ListBox3.IntegralHeight = False
        Me.ListBox3.ItemHeight = 16
        Me.ListBox3.Location = New System.Drawing.Point(223, 40)
        Me.ListBox3.Name = "ListBox3"
        Me.ListBox3.Size = New System.Drawing.Size(450, 242)
        Me.ListBox3.TabIndex = 45
        '
        'ListBox2
        '
        Me.ListBox2.BackColor = System.Drawing.SystemColors.Control
        Me.ListBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.ItemHeight = 16
        Me.ListBox2.Location = New System.Drawing.Point(55, 40)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(169, 242)
        Me.ListBox2.TabIndex = 47
        '
        'ListBox4
        '
        Me.ListBox4.BackColor = System.Drawing.SystemColors.Control
        Me.ListBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox4.FormattingEnabled = True
        Me.ListBox4.ItemHeight = 16
        Me.ListBox4.Location = New System.Drawing.Point(670, 39)
        Me.ListBox4.Name = "ListBox4"
        Me.ListBox4.Size = New System.Drawing.Size(96, 242)
        Me.ListBox4.TabIndex = 48
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel1.Controls.Add(Me.Label21)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.Label24)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Location = New System.Drawing.Point(1, 15)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(957, 24)
        Me.Panel1.TabIndex = 99
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(778, 1)
        Me.Label21.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(80, 20)
        Me.Label21.TabIndex = 45
        Me.Label21.Text = "Agree. Yr."
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(682, 3)
        Me.Label17.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(57, 20)
        Me.Label17.TabIndex = 44
        Me.Label17.Text = "B1 No."
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(876, 3)
        Me.Label24.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(65, 20)
        Me.Label24.TabIndex = 43
        Me.Label24.Text = "Amount"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(356, 4)
        Me.Label20.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(92, 20)
        Me.Label20.TabIndex = 37
        Me.Label20.Text = "Wrok Name"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(62, 3)
        Me.Label19.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(149, 20)
        Me.Label19.TabIndex = 36
        Me.Label19.Text = "GP /MLA / Serail No"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(5, 3)
        Me.Label18.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(33, 20)
        Me.Label18.TabIndex = 35
        Me.Label18.Text = "No."
        '
        'ListBox5
        '
        Me.ListBox5.BackColor = System.Drawing.SystemColors.Control
        Me.ListBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox5.FormattingEnabled = True
        Me.ListBox5.ItemHeight = 16
        Me.ListBox5.Location = New System.Drawing.Point(766, 39)
        Me.ListBox5.Name = "ListBox5"
        Me.ListBox5.Size = New System.Drawing.Size(96, 242)
        Me.ListBox5.TabIndex = 100
        '
        'ListBox6
        '
        Me.ListBox6.BackColor = System.Drawing.SystemColors.Control
        Me.ListBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox6.FormattingEnabled = True
        Me.ListBox6.ItemHeight = 16
        Me.ListBox6.Location = New System.Drawing.Point(862, 39)
        Me.ListBox6.Name = "ListBox6"
        Me.ListBox6.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.ListBox6.Size = New System.Drawing.Size(96, 242)
        Me.ListBox6.TabIndex = 101
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.ListBox6)
        Me.GroupBox3.Controls.Add(Me.ListBox5)
        Me.GroupBox3.Controls.Add(Me.Panel1)
        Me.GroupBox3.Controls.Add(Me.ListBox4)
        Me.GroupBox3.Controls.Add(Me.ListBox2)
        Me.GroupBox3.Controls.Add(Me.ListBox3)
        Me.GroupBox3.Controls.Add(Me.ListBox1)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(32, 358)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(981, 283)
        Me.GroupBox3.TabIndex = 244
        Me.GroupBox3.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.ComboAgrYr)
        Me.GroupBox4.Controls.Add(Me.txtadmamt)
        Me.GroupBox4.Controls.Add(Me.Label9)
        Me.GroupBox4.Controls.Add(Me.Label16)
        Me.GroupBox4.Controls.Add(Me.Label10)
        Me.GroupBox4.Controls.Add(Me.TextB1no)
        Me.GroupBox4.Controls.Add(Me.txtgpno)
        Me.GroupBox4.Controls.Add(Me.Label14)
        Me.GroupBox4.Controls.Add(Me.txtwrknm)
        Me.GroupBox4.Controls.Add(Me.Label15)
        Me.GroupBox4.Location = New System.Drawing.Point(27, 181)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(780, 135)
        Me.GroupBox4.TabIndex = 12
        Me.GroupBox4.TabStop = False
        '
        'ButtonResetADM
        '
        Me.ButtonResetADM.BackColor = System.Drawing.Color.Lavender
        Me.ButtonResetADM.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonResetADM.Location = New System.Drawing.Point(32, 660)
        Me.ButtonResetADM.Name = "ButtonResetADM"
        Me.ButtonResetADM.Size = New System.Drawing.Size(111, 42)
        Me.ButtonResetADM.TabIndex = 100
        Me.ButtonResetADM.Text = "Reset ADM"
        Me.ButtonResetADM.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.Lavender
        Me.Button5.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(183, 660)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(94, 42)
        Me.Button5.TabIndex = 101
        Me.Button5.Text = "Reset GP"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'ComboAgrYr
        '
        Me.ComboAgrYr.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboAgrYr.FormattingEnabled = True
        Me.ComboAgrYr.ItemHeight = 20
        Me.ComboAgrYr.Items.AddRange(New Object() {"2022-23", "2023-24", "2024-25"})
        Me.ComboAgrYr.Location = New System.Drawing.Point(579, 55)
        Me.ComboAgrYr.Name = "ComboAgrYr"
        Me.ComboAgrYr.Size = New System.Drawing.Size(159, 28)
        Me.ComboAgrYr.TabIndex = 10001
        '
        'ADMentry
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1248, 749)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.ButtonResetADM)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.Textsubtot)
        Me.Controls.Add(Me.AddItem)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.ButtonSv)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MaximizeBox = False
        Me.Name = "ADMentry"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ADM  Entry"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboDiv As System.Windows.Forms.ComboBox
    Friend WithEvents txtwrknm As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtfundhdm As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtgpno As System.Windows.Forms.TextBox
    Friend WithEvents txtadmamt As System.Windows.Forms.TextBox
    Friend WithEvents txtadmno As System.Windows.Forms.TextBox
    Friend WithEvents txtfundhd As System.Windows.Forms.TextBox
    Friend WithEvents dateadm As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents ButtonSv As System.Windows.Forms.Button
    Friend WithEvents ComboMPMLA As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ComboFdNm As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TextNoWork As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TextTotAdmAmt As System.Windows.Forms.TextBox
    Friend WithEvents ButtonSubmit As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents AddItem As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TextB1no As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Textsubtot As System.Windows.Forms.TextBox
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox3 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox4 As System.Windows.Forms.ListBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents ListBox5 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox6 As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents ButtonResetADM As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents ComboAgrYr As System.Windows.Forms.ComboBox
End Class
