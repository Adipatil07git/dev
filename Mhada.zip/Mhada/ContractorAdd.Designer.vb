﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ContractorAdd
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Button_Exit = New System.Windows.Forms.Button
        Me.Button_save = New System.Windows.Forms.Button
        Me.TextName = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.TextAdd = New System.Windows.Forms.TextBox
        Me.TextMob = New System.Windows.Forms.TextBox
        Me.TextPan = New System.Windows.Forms.TextBox
        Me.TextGst = New System.Windows.Forms.TextBox
        Me.TextEmail = New System.Windows.Forms.TextBox
        Me.TextPhone = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.AgencyNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.AgPANNoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.AgGSTNoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.AgMobileDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.AgEmailDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ContractorListBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MhadaDataSet6 = New Mhada.mhadaDataSet6
        Me.Label9 = New System.Windows.Forms.Label
        Me.Contractor_ListTableAdapter = New Mhada.mhadaDataSet6TableAdapters.Contractor_ListTableAdapter
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.TextBanknm = New System.Windows.Forms.TextBox
        Me.TextBankacc = New System.Windows.Forms.TextBox
        Me.TextBankifsc = New System.Windows.Forms.TextBox
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ContractorListBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MhadaDataSet6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button_Exit
        '
        Me.Button_Exit.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Button_Exit.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Exit.Location = New System.Drawing.Point(254, 518)
        Me.Button_Exit.Margin = New System.Windows.Forms.Padding(7, 9, 7, 9)
        Me.Button_Exit.Name = "Button_Exit"
        Me.Button_Exit.Size = New System.Drawing.Size(90, 54)
        Me.Button_Exit.TabIndex = 12
        Me.Button_Exit.Text = "Close"
        Me.Button_Exit.UseVisualStyleBackColor = False
        '
        'Button_save
        '
        Me.Button_save.BackColor = System.Drawing.Color.PaleGreen
        Me.Button_save.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_save.Location = New System.Drawing.Point(58, 518)
        Me.Button_save.Margin = New System.Windows.Forms.Padding(7, 9, 7, 9)
        Me.Button_save.Name = "Button_save"
        Me.Button_save.Size = New System.Drawing.Size(97, 54)
        Me.Button_save.TabIndex = 11
        Me.Button_save.Text = "Save"
        Me.Button_save.UseVisualStyleBackColor = False
        '
        'TextName
        '
        Me.TextName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextName.Location = New System.Drawing.Point(156, 56)
        Me.TextName.Margin = New System.Windows.Forms.Padding(7)
        Me.TextName.MaxLength = 30
        Me.TextName.Name = "TextName"
        Me.TextName.Size = New System.Drawing.Size(287, 26)
        Me.TextName.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(35, 62)
        Me.Label2.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(108, 20)
        Me.Label2.TabIndex = 98
        Me.Label2.Text = "Agency Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(35, 108)
        Me.Label1.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(79, 20)
        Me.Label1.TabIndex = 101
        Me.Label1.Text = "Mobile No"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(35, 153)
        Me.Label3.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 20)
        Me.Label3.TabIndex = 102
        Me.Label3.Text = "PAN No"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(35, 196)
        Me.Label4.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(66, 20)
        Me.Label4.TabIndex = 103
        Me.Label4.Text = "GST No"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(491, 150)
        Me.Label5.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(68, 20)
        Me.Label5.TabIndex = 104
        Me.Label5.Text = "Address"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(35, 239)
        Me.Label6.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(74, 20)
        Me.Label6.TabIndex = 105
        Me.Label6.Text = "E-Mail ID"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(491, 102)
        Me.Label7.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(55, 20)
        Me.Label7.TabIndex = 106
        Me.Label7.Text = "Phone"
        '
        'TextAdd
        '
        Me.TextAdd.Location = New System.Drawing.Point(639, 147)
        Me.TextAdd.MaxLength = 250
        Me.TextAdd.Multiline = True
        Me.TextAdd.Name = "TextAdd"
        Me.TextAdd.Size = New System.Drawing.Size(332, 112)
        Me.TextAdd.TabIndex = 10
        '
        'TextMob
        '
        Me.TextMob.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextMob.Location = New System.Drawing.Point(157, 105)
        Me.TextMob.Margin = New System.Windows.Forms.Padding(7)
        Me.TextMob.MaxLength = 10
        Me.TextMob.Name = "TextMob"
        Me.TextMob.Size = New System.Drawing.Size(160, 26)
        Me.TextMob.TabIndex = 2
        '
        'TextPan
        '
        Me.TextPan.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextPan.Location = New System.Drawing.Point(157, 150)
        Me.TextPan.Margin = New System.Windows.Forms.Padding(7)
        Me.TextPan.MaxLength = 10
        Me.TextPan.Name = "TextPan"
        Me.TextPan.Size = New System.Drawing.Size(160, 26)
        Me.TextPan.TabIndex = 3
        '
        'TextGst
        '
        Me.TextGst.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextGst.Location = New System.Drawing.Point(156, 193)
        Me.TextGst.Margin = New System.Windows.Forms.Padding(7)
        Me.TextGst.MaxLength = 15
        Me.TextGst.Name = "TextGst"
        Me.TextGst.Size = New System.Drawing.Size(161, 26)
        Me.TextGst.TabIndex = 4
        '
        'TextEmail
        '
        Me.TextEmail.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextEmail.Location = New System.Drawing.Point(157, 236)
        Me.TextEmail.Margin = New System.Windows.Forms.Padding(7)
        Me.TextEmail.MaxLength = 25
        Me.TextEmail.Name = "TextEmail"
        Me.TextEmail.Size = New System.Drawing.Size(287, 26)
        Me.TextEmail.TabIndex = 5
        '
        'TextPhone
        '
        Me.TextPhone.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextPhone.Location = New System.Drawing.Point(642, 99)
        Me.TextPhone.Margin = New System.Windows.Forms.Padding(7)
        Me.TextPhone.MaxLength = 15
        Me.TextPhone.Name = "TextPhone"
        Me.TextPhone.Size = New System.Drawing.Size(193, 26)
        Me.TextPhone.TabIndex = 9
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Monotype Corsiva", 24.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(390, -1)
        Me.Label8.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(304, 39)
        Me.Label8.TabIndex = 107
        Me.Label8.Text = "Contractor Entry Form"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.AgencyNameDataGridViewTextBoxColumn, Me.AgPANNoDataGridViewTextBoxColumn, Me.AgGSTNoDataGridViewTextBoxColumn, Me.AgMobileDataGridViewTextBoxColumn, Me.AgEmailDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.ContractorListBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(500, 468)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(473, 164)
        Me.DataGridView1.TabIndex = 108
        '
        'AgencyNameDataGridViewTextBoxColumn
        '
        Me.AgencyNameDataGridViewTextBoxColumn.DataPropertyName = "Agency_Name"
        Me.AgencyNameDataGridViewTextBoxColumn.HeaderText = "Agency_Name"
        Me.AgencyNameDataGridViewTextBoxColumn.Name = "AgencyNameDataGridViewTextBoxColumn"
        Me.AgencyNameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'AgPANNoDataGridViewTextBoxColumn
        '
        Me.AgPANNoDataGridViewTextBoxColumn.DataPropertyName = "Ag_PAN_No"
        Me.AgPANNoDataGridViewTextBoxColumn.HeaderText = "Ag_PAN_No"
        Me.AgPANNoDataGridViewTextBoxColumn.Name = "AgPANNoDataGridViewTextBoxColumn"
        Me.AgPANNoDataGridViewTextBoxColumn.ReadOnly = True
        '
        'AgGSTNoDataGridViewTextBoxColumn
        '
        Me.AgGSTNoDataGridViewTextBoxColumn.DataPropertyName = "Ag_GST_No"
        Me.AgGSTNoDataGridViewTextBoxColumn.HeaderText = "Ag_GST_No"
        Me.AgGSTNoDataGridViewTextBoxColumn.Name = "AgGSTNoDataGridViewTextBoxColumn"
        Me.AgGSTNoDataGridViewTextBoxColumn.ReadOnly = True
        '
        'AgMobileDataGridViewTextBoxColumn
        '
        Me.AgMobileDataGridViewTextBoxColumn.DataPropertyName = "Ag_Mobile"
        Me.AgMobileDataGridViewTextBoxColumn.HeaderText = "Ag_Mobile"
        Me.AgMobileDataGridViewTextBoxColumn.Name = "AgMobileDataGridViewTextBoxColumn"
        Me.AgMobileDataGridViewTextBoxColumn.ReadOnly = True
        '
        'AgEmailDataGridViewTextBoxColumn
        '
        Me.AgEmailDataGridViewTextBoxColumn.DataPropertyName = "Ag_Email"
        Me.AgEmailDataGridViewTextBoxColumn.HeaderText = "Ag_Email"
        Me.AgEmailDataGridViewTextBoxColumn.Name = "AgEmailDataGridViewTextBoxColumn"
        Me.AgEmailDataGridViewTextBoxColumn.ReadOnly = True
        '
        'ContractorListBindingSource
        '
        Me.ContractorListBindingSource.DataMember = "Contractor_List"
        Me.ContractorListBindingSource.DataSource = Me.MhadaDataSet6
        '
        'MhadaDataSet6
        '
        Me.MhadaDataSet6.DataSetName = "mhadaDataSet6"
        Me.MhadaDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial Rounded MT Bold", 15.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(637, 441)
        Me.Label9.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(163, 24)
        Me.Label9.TabIndex = 109
        Me.Label9.Text = "Contractor List"
        '
        'Contractor_ListTableAdapter
        '
        Me.Contractor_ListTableAdapter.ClearBeforeFill = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(35, 286)
        Me.Label10.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(92, 20)
        Me.Label10.TabIndex = 110
        Me.Label10.Text = "Bank Name"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(35, 335)
        Me.Label11.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(101, 20)
        Me.Label11.TabIndex = 111
        Me.Label11.Text = "Bank Acc No"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(35, 375)
        Me.Label12.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(118, 20)
        Me.Label12.TabIndex = 112
        Me.Label12.Text = "Bank IFS Code"
        '
        'TextBanknm
        '
        Me.TextBanknm.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextBanknm.Location = New System.Drawing.Point(156, 284)
        Me.TextBanknm.Margin = New System.Windows.Forms.Padding(7)
        Me.TextBanknm.MaxLength = 30
        Me.TextBanknm.Name = "TextBanknm"
        Me.TextBanknm.Size = New System.Drawing.Size(287, 26)
        Me.TextBanknm.TabIndex = 6
        '
        'TextBankacc
        '
        Me.TextBankacc.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextBankacc.Location = New System.Drawing.Point(157, 330)
        Me.TextBankacc.Margin = New System.Windows.Forms.Padding(7)
        Me.TextBankacc.MaxLength = 15
        Me.TextBankacc.Name = "TextBankacc"
        Me.TextBankacc.Size = New System.Drawing.Size(287, 26)
        Me.TextBankacc.TabIndex = 7
        '
        'TextBankifsc
        '
        Me.TextBankifsc.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextBankifsc.Location = New System.Drawing.Point(157, 373)
        Me.TextBankifsc.Margin = New System.Windows.Forms.Padding(7)
        Me.TextBankifsc.MaxLength = 10
        Me.TextBankifsc.Name = "TextBankifsc"
        Me.TextBankifsc.Size = New System.Drawing.Size(287, 26)
        Me.TextBankifsc.TabIndex = 8
        '
        'ContractorAdd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1024, 687)
        Me.Controls.Add(Me.TextBankifsc)
        Me.Controls.Add(Me.TextBankacc)
        Me.Controls.Add(Me.TextBanknm)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TextPhone)
        Me.Controls.Add(Me.TextEmail)
        Me.Controls.Add(Me.TextGst)
        Me.Controls.Add(Me.TextPan)
        Me.Controls.Add(Me.TextMob)
        Me.Controls.Add(Me.TextAdd)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button_Exit)
        Me.Controls.Add(Me.Button_save)
        Me.Controls.Add(Me.TextName)
        Me.Controls.Add(Me.Label2)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ContractorAdd"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AddContractor"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ContractorListBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MhadaDataSet6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button_Exit As System.Windows.Forms.Button
    Friend WithEvents Button_save As System.Windows.Forms.Button
    Friend WithEvents TextName As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextAdd As System.Windows.Forms.TextBox
    Friend WithEvents TextMob As System.Windows.Forms.TextBox
    Friend WithEvents TextPan As System.Windows.Forms.TextBox
    Friend WithEvents TextGst As System.Windows.Forms.TextBox
    Friend WithEvents TextEmail As System.Windows.Forms.TextBox
    Friend WithEvents TextPhone As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents MhadaDataSet6 As Mhada.mhadaDataSet6
    Friend WithEvents ContractorListBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Contractor_ListTableAdapter As Mhada.mhadaDataSet6TableAdapters.Contractor_ListTableAdapter
    Friend WithEvents AgencyNameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AgPANNoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AgGSTNoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AgMobileDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AgEmailDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TextBanknm As System.Windows.Forms.TextBox
    Friend WithEvents TextBankacc As System.Windows.Forms.TextBox
    Friend WithEvents TextBankifsc As System.Windows.Forms.TextBox
End Class
