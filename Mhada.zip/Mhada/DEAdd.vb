﻿Imports System.Data.OleDb
Public Class DEAdd
    Dim con As New OleDbConnection
    Dim cmdOLEDB As New OleDbCommand

    Private Sub AddDepE_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'MhadaDataSet1.DElist' table. You can move, or remove it, as needed.
        Me.DElistTableAdapter.Fill(Me.MhadaDataSet1.DElist)

    End Sub

    Private Sub Button_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_save.Click
        If txtDE.Text = String.Empty Then
            MsgBox("Please Enter Executive Engineer Name.")
            txtDE.Focus()
        Else
            Dim dt As New DataTable
            Dim ds As New DataSet
            con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"

            con.Open()

            cmdOLEDB.CommandText = "Select DE_Name from DElist where DE_Name= '" & txtDE.Text & "'"
            cmdOLEDB.Connection = con
            Dim rdrOLEDB As OleDbDataReader = cmdOLEDB.ExecuteReader

            If rdrOLEDB.Read = True Then
                MsgBox("Deputy Engineer already Exit.")
                rdrOLEDB.Close()
                txtDE.Focus()
                txtDE.Text = ""
            Else
                ds.Tables.Add(dt)
                Dim da, da1 As New OleDbDataAdapter
                da = New OleDbDataAdapter("SELECT * FROM DElist", con)
                da.Fill(dt)
                Dim newRow As DataRow = dt.NewRow
                newRow.Item("DE_Name") = txtDE.Text
                newRow.Item("created") = Now()
                newRow.Item("Entry_By") = "Admin"
                dt.Rows.Add(newRow)
                Dim cb As New OleDbCommandBuilder(da)
                da.Update(dt)
                MsgBox("Deputy Engineer successfully saved.", vbInformation)
                DElistTableAdapter.Fill(MhadaDataSet1.DElist)
                con.Close()

                txtDE.Text = ""
            End If
        End If

    End Sub

    Private Sub Button_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Exit.Click
        con.Close()
        Me.Close()

    End Sub
End Class