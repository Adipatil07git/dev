﻿Imports System.Data.OleDb
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Public Class ADM2
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"
    Dim con, con1, con2, con3, con4 As New OleDbConnection(connectionString)
    Dim adapter As New OleDbDataAdapter()
    Dim str, str0, str1, str2, str3, str4 As String
    Dim com, com0, com1, com2, com3, com4 As OleDbCommand
    Dim oledbda As OleDbDataAdapter
    Dim ds, ds1, ds2, ds3, ds4 As DataSet
    Dim dt As New DataTable
    Dim invdt As String
    Dim cmdOLEDB As New OleDbCommand
    Public dr As OleDbDataReader
    Dim da As OleDb.OleDbDataAdapter
    Dim totadm, totexp, totbal, totpend, admamt1 As Int64
    Private Sub ADM2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboADMno.DropDownStyle = ComboBoxStyle.DropDownList
        ComboGP.DropDownStyle = ComboBoxStyle.DropDownList
        ComboContract.DropDownStyle = ComboBoxStyle.DropDownList
        ComboTdQt.DropDownStyle = ComboBoxStyle.DropDownList

        con.Open()

        str = "select Distinct ADM_No from Testing"
        com = New OleDbCommand(str, con)
        oledbda = New OleDbDataAdapter(com)
        ds = New DataSet
        oledbda.Fill(ds, "Testing")
        ComboADMno.DataSource = ds.Tables("Testing")
        ComboADMno.ValueMember = "ADM_No"
        ComboADMno.DisplayMember = "ADM_No"

        str0 = "select Distinct Agency_Name from Contractor_List"
        com0 = New OleDbCommand(str0, con)
        oledbda = New OleDbDataAdapter(com0)
        ds1 = New DataSet
        oledbda.Fill(ds1, "Contractor_List")
        ComboContract.DataSource = ds1.Tables("Contractor_List")
        ComboContract.ValueMember = "Agency_Name"
        ComboContract.DisplayMember = "Agency_Name"

        ComboADMno.Focus()

    End Sub
    Private Sub ComboADMno_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboADMno.SelectionChangeCommitted

        Textadmdt.Text = ""
        Textadmamt.Text = ""
        Textdiv.Text = ""
        Textmpmla.Text = ""
        Textfnm.Text = ""
        Textfhg.Text = ""
        Textfhm.Text = ""
        Textadmyr.Text = ""
        Textworknm.Text = ""
        admamt1 = 0

        str1 = "select Distinct GP_No from Testing where ADM_No='" & ComboADMno.SelectedValue & "'"
        com1 = New OleDbCommand(str1, con)
        oledbda = New OleDbDataAdapter(com1)
        ds = New DataSet
        oledbda.Fill(ds, "Testing")
        ComboGP.DataSource = ds.Tables("Testing")
        ComboGP.ValueMember = "GP_No"
        ComboGP.DisplayMember = "GP_No"


    End Sub
    Private Sub ComboGP_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboGP.SelectionChangeCommitted
        Textadmdt.Text = ""
        Textadmamt.Text = ""
        Textdiv.Text = ""
        Textmpmla.Text = ""
        Textfnm.Text = ""
        Textfhg.Text = ""
        Textfhm.Text = ""
        Textadmyr.Text = ""
        Textworknm.Text = ""
        admamt1 = 0

        str2 = "SELECT * FROM Testing WHERE ADM_No=? AND GP_No=?"
        Using com2 As New OleDbCommand(str2, con)
            com2.Parameters.AddWithValue("@ADM_No", ComboADMno.SelectedValue)
            com2.Parameters.AddWithValue("@GP_No", ComboGP.SelectedValue)

            Using dr As OleDbDataReader = com2.ExecuteReader()
                If dr.Read() Then
                    Textadmdt.Text = dr("ADM_Date").ToString
                    Textadmamt.Text = dr("ADM_Amt").ToString
                    Textdiv.Text = dr("Div_Name").ToString
                    Textmpmla.Text = dr("MP_MLA_MLC").ToString
                    Textfnm.Text = dr("Fund_Name").ToString
                    Textfhg.Text = dr("Govt_Fund_Head").ToString
                    Textfhm.Text = dr("Mhada_Fund_Head").ToString
                    Textadmyr.Text = dr("ADM_Year").ToString
                    Textworknm.Text = dr("Work_Name").ToString
                    admamt1 = Val(dr("ADM_Amt").ToString)
                End If
            End Using
        End Using
        cmdOLEDB.CommandText = "Select * from Testing where ADM_No='" & ComboADMno.SelectedValue & "' AND GP_No ='" & ComboGP.SelectedValue & "' "
        cmdOLEDB.Connection = con
        
        TextExcEng.Text = ""
        TextDepEng.Text = ""
        TextJrEng.Text = ""
        txtworkkey.Text = ""
        txtagree.Text = ""
        txttndamt.Text = ""
        ComboTdQt.Text = ""
        txttndrdamt.Text = ""
        ComboContract.Text = ""
        txtpan.Text = ""
        datestart.Value = Today()
        datecomplete.Value = Today()

        GroupBox1.Enabled = True
        'rdrOLEDB.Close()

    End Sub
    Public Sub datacap1()
        str4 = "select * from Testing where ADM_No='" & ComboADMno.SelectedValue & "' AND GP_No ='" & ComboGP.SelectedValue & "' "
        com4 = New OleDbCommand(str4, con)
        dr = com4.ExecuteReader
        While dr.Read()
            TextExcEng.Text = dr("Exec_Eng").ToString
            TextDepEng.Text = dr("Dep_eng").ToString
            TextJrEng.Text = dr("Jr_Eng").ToString
            txtworkkey.Text = dr("Work_No").ToString
            'txtagree.Text = dr("Agreement_No").ToString
            txttndamt.Text = dr("Tend_Amt").ToString
            ComboTdQt.Text = dr("Tend_Quot").ToString
            txttndrdamt.Text = dr("Tend_Quot").ToString
            datestart.Text = dr("Start_Date").ToString
            datecomplete.Text = dr("Complete_Date").ToString
            ComboContract.Text = dr("Contractor_Name").ToString
            txtpan.Text = Val(dr("Cont_PAN").ToString)

        End While
    End Sub
    Private Sub ComboContract_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboContract.SelectionChangeCommitted
        str3 = "select * from Contractor_List where Agency_Name='" & ComboContract.SelectedValue & "' "
        com3 = New OleDbCommand(str3, con)
        dr = com3.ExecuteReader
        While dr.Read()
            txtpan.Text = dr("Ag_PAN_No").ToString
            txtgst.Text = dr("Ag_GST_No").ToString
        End While

    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        con.Close()
        Me.Close()

    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            con.Open()

            Dim cmd As New OleDbCommand
            cmd.Connection = con
            cmd.CommandText = "SELECT COUNT(*) FROM Testing WHERE ADM_No=? AND GP_No=?"
            cmd.Parameters.AddWithValue("@ADM_No", ComboADMno.SelectedValue)
            cmd.Parameters.AddWithValue("@GP_No", ComboGP.SelectedValue)

            Dim recordCount As Integer = Convert.ToInt32(cmd.ExecuteScalar())

            If recordCount > 0 Then
                cmd.CommandText = "UPDATE Testing SET ADM_Date=?, ADM_Amt=?, Div_Name=?, MP_MLA_MLC=?, Fund_Name=?, " & _
                                  "Govt_Fund_Head=?, Mhada_Fund_Head=?, ADM_Year=?, Work_Name=?, Exec_Eng=?, " & _
                                  "Dep_eng=?, Jr_Eng=?, Work_No=?, Tend_Amt=?, Tend_Quot=?, Tended_Amt=?, Start_Date=?, " & _
                                  "Complete_Date=?, Contractor_Name=?, Cont_PAN=?, Cont_GST=?, updatedby=? " & _
                                  "WHERE ADM_No=? AND GP_No=?"
            Else
                cmd.CommandText = "INSERT INTO Testing (ADM_No, GP_No, ADM_Date, ADM_Amt, Div_Name, MP_MLA_MLC, Fund_Name, " & _
                                  "Govt_Fund_Head, Mhada_Fund_Head, ADM_Year, Work_Name, Exec_Eng, " & _
                                  "Dep_eng, Jr_Eng, Work_No, Tend_Amt, Tend_Quot, Tended_Amt, Start_Date, " & _
                                  "Complete_Date, Contractor_Name, Cont_PAN, Cont_GST, updatedby, updatedt) " & _
                                  "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            End If
            cmd.Parameters.AddWithValue("@ADM_Date", Textadmdt.Text)
            cmd.Parameters.AddWithValue("@ADM_Amt", Val(Textadmamt.Text))
            cmd.Parameters.AddWithValue("@Div_Name", Textdiv.Text)
            cmd.Parameters.AddWithValue("@MP_MLA_MLC", Textmpmla.Text)
            cmd.Parameters.AddWithValue("@Fund_Name", Textfnm.Text)
            cmd.Parameters.AddWithValue("@Govt_Fund_Head", Textfhg.Text)
            cmd.Parameters.AddWithValue("@Mhada_Fund_Head", Textfhm.Text)
            cmd.Parameters.AddWithValue("@ADM_Year", Textadmyr.Text)
            cmd.Parameters.AddWithValue("@Work_Name", Textworknm.Text)
            cmd.Parameters.AddWithValue("@Exec_Eng", TextExcEng.Text)
            cmd.Parameters.AddWithValue("@Dep_eng", TextDepEng.Text)
            cmd.Parameters.AddWithValue("@Jr_Eng", TextJrEng.Text)
            cmd.Parameters.AddWithValue("@Work_No", txtworkkey.Text)
            cmd.Parameters.AddWithValue("@Tend_Amt", Val(txttndamt.Text))
            cmd.Parameters.AddWithValue("@Tend_Quot", ComboTdQt.Text)
            cmd.Parameters.AddWithValue("@Tended_Amt", Val(txttndrdamt.Text))
            cmd.Parameters.AddWithValue("@Start_Date", datestart.Value)
            cmd.Parameters.AddWithValue("@Complete_Date", datecomplete.Value)
            cmd.Parameters.AddWithValue("@Contractor_Name", ComboContract.SelectedValue)
            cmd.Parameters.AddWithValue("@Cont_PAN", txtpan.Text)
            cmd.Parameters.AddWithValue("@Cont_GST", txtgst.Text)
            cmd.Parameters.AddWithValue("@updatedby", "Admin")

            cmd.Parameters.AddWithValue("@ADM_No", ComboADMno.SelectedValue)
            cmd.Parameters.AddWithValue("@GP_No", ComboGP.SelectedValue)

            cmd.ExecuteNonQuery()

            Dim result = MessageBox.Show("Data successfully Saved.", "MHADA")
            Me.Close()
            con.Close()
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub txttndamt_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txttndamt.LostFocus

    End Sub
    Private Sub txttndamt_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttndamt.TextChanged
        If IsNumeric(txttndamt.Text) Then
            If Val(txttndamt.Text) <= admamt1 Then
                Exit Sub
            Else
                Dim result = MessageBox.Show("Tender Amount should be less than ADM Amount.", "MHADA")
                txttndamt.Text = ""
                txttndamt.Focus()
            End If
        Else
            txttndamt.Text = ""
            txttndamt.Focus()
        End If
    End Sub
    Private Sub txttndrdamt_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttndrdamt.TextChanged
        If IsNumeric(txttndrdamt.Text) Then
            If Val(txttndrdamt.Text) <= admamt1 Then
                Exit Sub
            Else
                Dim result = MessageBox.Show("Tendered Amount should be less than ADM Amount.", "MHADA")
                txttndrdamt.Text = ""

                txttndrdamt.Focus()
            End If
        Else
            txttndrdamt.Text = ""
            txttndrdamt.Focus()
        End If

    End Sub
    Private Sub ComboTdQt_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboTdQt.SelectedIndexChanged

    End Sub

    Private Sub ComboTdQt_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboTdQt.SelectionChangeCommitted
        If ComboTdQt.SelectedValue = "BELOW" Then
            TextPer.Text = "1"
        ElseIf ComboTdQt.SelectedValue = "ABOVE" Then
            TextPer.Text = "2"
        ElseIf ComboTdQt.SelectedValue = "AT PAR" Then
            TextPer.Text = "0"
            TextPer.Enabled = False
        End If
    End Sub

    Private Sub ComboGP_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboGP.SelectedIndexChanged

    End Sub
End Class