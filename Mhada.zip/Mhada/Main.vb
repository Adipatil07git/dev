﻿Imports System.Data.OleDb
Imports System.IO
Public Class Main
    Dim usrnm As String
    Dim date1 As Date = #9/1/2023#
    Dim date2 As Date = Now()
    Dim date3 As Date = #8/30/2024#
    Private Sub Main_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
    Private Sub txt_Username_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_Username.LostFocus
        txt_Password.Focus()
    End Sub
    Private Sub txt_Password_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_Password.LostFocus
        btn_Login.Focus()
    End Sub

    Private Sub txt_Password_PreviewKeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.PreviewKeyDownEventArgs) Handles txt_Password.PreviewKeyDown
        If e.KeyCode = Keys.Enter Then
            Call btn_Login_Click(sender, e)
        End If

    End Sub

    Private Sub btn_Login_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Login.Click
        If txt_Username.Text = String.Empty Then
            MsgBox("Enter User Name.")
            txt_Username.Focus()
        ElseIf txt_Password.Text = String.Empty Then
            MsgBox("Enter Password.")
            txt_Password.Focus()
        Else
            Dim conn As New System.Data.OleDb.OleDbConnection()
            'conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"

            'conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= https://trifrnd.com/App_data/mhada.accdb;Jet OLEDB:Database Password=apms;"
            'conn.ConnectionString = "Provider=MS Remote;Remote Server= https://trifrnd.com/App_Data/; Remote Provider=Microsoft.ACE.OLEDB.12.0;Data Source=mhada.accdb;Jet OLEDB:Database Password=apms;"

            'conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=https://www.trifrnd.com/App_Data/mhada.accdb;Jet OLEDB:Database Password=apms;"

            'conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=\\vps.trifrnd.in\data\mhada.accdb;Jet OLEDB:Database Password=apms;"
            'conn.ConnectionString = "Provider=MS Remote; Remote Server=https://www.trifrnd.com/App_Data; Remote Provider=Microsoft.ACE.OLEDB.12.0;Data Source=`Server.MapPath(mhada.accdb);"

            conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=\\vps.trifrnd.in\data\Mhada.accdb;Driver={Microsoft Access Driver (*.mdb, *.accdb};Persist Security Info=False;Jet OLEDB:Database Password=apms;"

            Dim sql As String = "SELECT * FROM UserInfo WHERE UserName ='" & txt_Username.Text & "' AND UserPassword = '" & txt_Password.Text & "'"
            Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql)
            Dim txtFname, urole As String

            sqlCom.Connection = conn
            conn.Open()

            Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()

            If sqlRead.Read() Then
                txtFname = txt_Username.Text
                Me.Visible = False
                urole = sqlRead("User_Role").ToString
                usrnm = txt_Username.Text
                If (date1 < date2) And (date2 < date3) Then
                    If urole = "Admin" Then

                        conn.Close()
                        Dim dbe As New Microsoft.Office.Interop.Access.Dao.DBEngine
                        Dim sDBFile As String = "D:\Data\mhada.accdb"
                        Dim sBackUpFile As String = "D:\Data\BCK\" & Format(Now, "ddMMyyyy") & "st.Bck"
                        If File.Exists(sBackUpFile) Then
                            Kill(sBackUpFile)
                        End If
                        dbe.CompactDatabase(sDBFile, sBackUpFile, , , ";pwd=apms")
                        conn.Open()

                        Application.Show()
                    Else
                        'Appuser.Show()
                    End If
                Else
                    MessageBox.Show("Your software is not valid.", "Date Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Close()
                End If
            Else
                MessageBox.Show("Username OR Password does not match.", "Database Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txt_Password.Text = ""
                txt_Username.Text = ""
                txt_Username.Focus()
            End If
        End If

    End Sub
End Class