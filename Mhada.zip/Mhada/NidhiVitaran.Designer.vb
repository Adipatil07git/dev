﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NidhiVitaran
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.ComboGP = New System.Windows.Forms.ComboBox
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.TextADM = New System.Windows.Forms.TextBox
        Me.TextExp = New System.Windows.Forms.TextBox
        Me.TextFdRec = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.Button2 = New System.Windows.Forms.Button
        Me.ComboADMno = New System.Windows.Forms.ComboBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.ButtonO4 = New System.Windows.Forms.Button
        Me.ButtonO3 = New System.Windows.Forms.Button
        Me.ButtonO2 = New System.Windows.Forms.Button
        Me.ButtonO1 = New System.Windows.Forms.Button
        Me.CheckBox4 = New System.Windows.Forms.CheckBox
        Me.Label32 = New System.Windows.Forms.Label
        Me.CheckBox3 = New System.Windows.Forms.CheckBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.CheckBox2 = New System.Windows.Forms.CheckBox
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.dtord1 = New System.Windows.Forms.TextBox
        Me.chdtord1 = New System.Windows.Forms.TextBox
        Me.TotRecAmt = New System.Windows.Forms.TextBox
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.recamtord4 = New System.Windows.Forms.TextBox
        Me.recamtord3 = New System.Windows.Forms.TextBox
        Me.recamtord2 = New System.Windows.Forms.TextBox
        Me.chdtord4 = New System.Windows.Forms.TextBox
        Me.chdtord3 = New System.Windows.Forms.TextBox
        Me.chdtord2 = New System.Windows.Forms.TextBox
        Me.chnoord4 = New System.Windows.Forms.TextBox
        Me.chnoord3 = New System.Windows.Forms.TextBox
        Me.chnoord2 = New System.Windows.Forms.TextBox
        Me.dtord4 = New System.Windows.Forms.TextBox
        Me.dtord3 = New System.Windows.Forms.TextBox
        Me.dtord2 = New System.Windows.Forms.TextBox
        Me.noord4 = New System.Windows.Forms.TextBox
        Me.noord3 = New System.Windows.Forms.TextBox
        Me.noord2 = New System.Windows.Forms.TextBox
        Me.recamtord1 = New System.Windows.Forms.TextBox
        Me.chnoord1 = New System.Windows.Forms.TextBox
        Me.noord1 = New System.Windows.Forms.TextBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.BalFund = New System.Windows.Forms.TextBox
        Me.TextAmtadm = New System.Windows.Forms.TextBox
        Me.ComboHdNm = New System.Windows.Forms.ComboBox
        Me.LabelH3 = New System.Windows.Forms.Label
        Me.ComboAdmYr = New System.Windows.Forms.ComboBox
        Me.Label30 = New System.Windows.Forms.Label
        Me.BillPaid = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.TextTend = New System.Windows.Forms.TextBox
        Me.TextEx = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.ComboFdHd = New System.Windows.Forms.ComboBox
        Me.TextBillPass = New System.Windows.Forms.TextBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.FundDemand = New System.Windows.Forms.TextBox
        Me.Label27 = New System.Windows.Forms.Label
        Me.TextFRec = New System.Windows.Forms.TextBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.TextBFund = New System.Windows.Forms.TextBox
        Me.TextFDemand = New System.Windows.Forms.TextBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.rtgsno = New System.Windows.Forms.TextBox
        Me.TenderBal = New System.Windows.Forms.TextBox
        Me.rtgsdt = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'ComboGP
        '
        Me.ComboGP.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.ComboGP.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.ComboGP.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboGP.FormattingEnabled = True
        Me.ComboGP.Location = New System.Drawing.Point(199, 369)
        Me.ComboGP.Name = "ComboGP"
        Me.ComboGP.Size = New System.Drawing.Size(242, 26)
        Me.ComboGP.TabIndex = 5
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        Me.DataGridView1.CausesValidation = False
        Me.DataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridView1.Location = New System.Drawing.Point(452, 66)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(747, 283)
        Me.DataGridView1.TabIndex = 331
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(70, 164)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(60, 23)
        Me.Label19.TabIndex = 332
        Me.Label19.Text = "Total  -"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(141, 164)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(115, 23)
        Me.Label18.TabIndex = 333
        Me.Label18.Text = "ADM Amount"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(141, 192)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(137, 23)
        Me.Label16.TabIndex = 334
        Me.Label16.Text = "Bill Pass Amount"
        '
        'TextADM
        '
        Me.TextADM.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextADM.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextADM.Location = New System.Drawing.Point(319, 167)
        Me.TextADM.Name = "TextADM"
        Me.TextADM.ReadOnly = True
        Me.TextADM.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextADM.Size = New System.Drawing.Size(100, 24)
        Me.TextADM.TabIndex = 335
        '
        'TextExp
        '
        Me.TextExp.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextExp.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextExp.Location = New System.Drawing.Point(319, 195)
        Me.TextExp.Name = "TextExp"
        Me.TextExp.ReadOnly = True
        Me.TextExp.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextExp.Size = New System.Drawing.Size(100, 24)
        Me.TextExp.TabIndex = 336
        '
        'TextFdRec
        '
        Me.TextFdRec.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextFdRec.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextFdRec.Location = New System.Drawing.Point(319, 223)
        Me.TextFdRec.Name = "TextFdRec"
        Me.TextFdRec.ReadOnly = True
        Me.TextFdRec.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextFdRec.Size = New System.Drawing.Size(100, 24)
        Me.TextFdRec.TabIndex = 337
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(140, 221)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(121, 23)
        Me.Label14.TabIndex = 338
        Me.Label14.Text = "Fund Received"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(141, 248)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(172, 23)
        Me.Label12.TabIndex = 339
        Me.Label12.Text = "Expenditure /Bill Paid"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(46, 371)
        Me.Label31.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(149, 20)
        Me.Label31.TabIndex = 367
        Me.Label31.Text = "GP/MLA Serail  No :"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Turquoise
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(135, 648)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(76, 43)
        Me.Button2.TabIndex = 30
        Me.Button2.Text = "Close"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'ComboADMno
        '
        Me.ComboADMno.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboADMno.FormattingEnabled = True
        Me.ComboADMno.Location = New System.Drawing.Point(144, 127)
        Me.ComboADMno.Name = "ComboADMno"
        Me.ComboADMno.Size = New System.Drawing.Size(157, 26)
        Me.ComboADMno.Sorted = True
        Me.ComboADMno.TabIndex = 4
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(46, 135)
        Me.Label7.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 18)
        Me.Label7.TabIndex = 328
        Me.Label7.Text = "ADM No :"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.ButtonO4)
        Me.Panel1.Controls.Add(Me.ButtonO3)
        Me.Panel1.Controls.Add(Me.ButtonO2)
        Me.Panel1.Controls.Add(Me.ButtonO1)
        Me.Panel1.Controls.Add(Me.CheckBox4)
        Me.Panel1.Controls.Add(Me.Label32)
        Me.Panel1.Controls.Add(Me.CheckBox3)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.CheckBox2)
        Me.Panel1.Controls.Add(Me.CheckBox1)
        Me.Panel1.Controls.Add(Me.dtord1)
        Me.Panel1.Controls.Add(Me.chdtord1)
        Me.Panel1.Controls.Add(Me.TotRecAmt)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.recamtord4)
        Me.Panel1.Controls.Add(Me.recamtord3)
        Me.Panel1.Controls.Add(Me.recamtord2)
        Me.Panel1.Controls.Add(Me.chdtord4)
        Me.Panel1.Controls.Add(Me.chdtord3)
        Me.Panel1.Controls.Add(Me.chdtord2)
        Me.Panel1.Controls.Add(Me.chnoord4)
        Me.Panel1.Controls.Add(Me.chnoord3)
        Me.Panel1.Controls.Add(Me.chnoord2)
        Me.Panel1.Controls.Add(Me.dtord4)
        Me.Panel1.Controls.Add(Me.dtord3)
        Me.Panel1.Controls.Add(Me.dtord2)
        Me.Panel1.Controls.Add(Me.noord4)
        Me.Panel1.Controls.Add(Me.noord3)
        Me.Panel1.Controls.Add(Me.noord2)
        Me.Panel1.Controls.Add(Me.recamtord1)
        Me.Panel1.Controls.Add(Me.chnoord1)
        Me.Panel1.Controls.Add(Me.noord1)
        Me.Panel1.Location = New System.Drawing.Point(50, 401)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(843, 208)
        Me.Panel1.TabIndex = 329
        '
        'ButtonO4
        '
        Me.ButtonO4.BackColor = System.Drawing.Color.LightGreen
        Me.ButtonO4.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonO4.Location = New System.Drawing.Point(768, 143)
        Me.ButtonO4.Name = "ButtonO4"
        Me.ButtonO4.Size = New System.Drawing.Size(67, 27)
        Me.ButtonO4.TabIndex = 374
        Me.ButtonO4.Text = "Update"
        Me.ButtonO4.UseVisualStyleBackColor = False
        Me.ButtonO4.Visible = False
        '
        'ButtonO3
        '
        Me.ButtonO3.BackColor = System.Drawing.Color.LightGreen
        Me.ButtonO3.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonO3.Location = New System.Drawing.Point(768, 110)
        Me.ButtonO3.Name = "ButtonO3"
        Me.ButtonO3.Size = New System.Drawing.Size(67, 27)
        Me.ButtonO3.TabIndex = 373
        Me.ButtonO3.Text = "Update"
        Me.ButtonO3.UseVisualStyleBackColor = False
        Me.ButtonO3.Visible = False
        '
        'ButtonO2
        '
        Me.ButtonO2.BackColor = System.Drawing.Color.LightGreen
        Me.ButtonO2.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonO2.Location = New System.Drawing.Point(768, 77)
        Me.ButtonO2.Name = "ButtonO2"
        Me.ButtonO2.Size = New System.Drawing.Size(67, 27)
        Me.ButtonO2.TabIndex = 372
        Me.ButtonO2.Text = "Update"
        Me.ButtonO2.UseVisualStyleBackColor = False
        Me.ButtonO2.Visible = False
        '
        'ButtonO1
        '
        Me.ButtonO1.BackColor = System.Drawing.Color.LightGreen
        Me.ButtonO1.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonO1.Location = New System.Drawing.Point(768, 42)
        Me.ButtonO1.Name = "ButtonO1"
        Me.ButtonO1.Size = New System.Drawing.Size(67, 27)
        Me.ButtonO1.TabIndex = 368
        Me.ButtonO1.Text = "Update"
        Me.ButtonO1.UseVisualStyleBackColor = False
        Me.ButtonO1.Visible = False
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox4.Location = New System.Drawing.Point(7, 145)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(77, 24)
        Me.CheckBox4.TabIndex = 24
        Me.CheckBox4.Text = "Order4"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.ForeColor = System.Drawing.Color.Red
        Me.Label32.Location = New System.Drawing.Point(546, 174)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(61, 13)
        Me.Label32.TabIndex = 318
        Me.Label32.Text = "DD-MM-YY"
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox3.Location = New System.Drawing.Point(7, 110)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(77, 24)
        Me.CheckBox3.TabIndex = 18
        Me.CheckBox3.Text = "Order3"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.Red
        Me.Label1.Location = New System.Drawing.Point(218, 173)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 13)
        Me.Label1.TabIndex = 317
        Me.Label1.Text = "DD-MM-YY"
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox2.Location = New System.Drawing.Point(7, 78)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(77, 24)
        Me.CheckBox2.TabIndex = 12
        Me.CheckBox2.Text = "Order2"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox1.Location = New System.Drawing.Point(7, 45)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(77, 24)
        Me.CheckBox1.TabIndex = 6
        Me.CheckBox1.Text = "Order1"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'dtord1
        '
        Me.dtord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtord1.Location = New System.Drawing.Point(209, 43)
        Me.dtord1.MaxLength = 10
        Me.dtord1.Name = "dtord1"
        Me.dtord1.ReadOnly = True
        Me.dtord1.Size = New System.Drawing.Size(83, 26)
        Me.dtord1.TabIndex = 8
        '
        'chdtord1
        '
        Me.chdtord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chdtord1.Location = New System.Drawing.Point(538, 45)
        Me.chdtord1.MaxLength = 10
        Me.chdtord1.Name = "chdtord1"
        Me.chdtord1.ReadOnly = True
        Me.chdtord1.Size = New System.Drawing.Size(87, 26)
        Me.chdtord1.TabIndex = 10
        '
        'TotRecAmt
        '
        Me.TotRecAmt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TotRecAmt.Location = New System.Drawing.Point(633, 174)
        Me.TotRecAmt.Name = "TotRecAmt"
        Me.TotRecAmt.ReadOnly = True
        Me.TotRecAmt.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TotRecAmt.Size = New System.Drawing.Size(124, 26)
        Me.TotRecAmt.TabIndex = 275
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Location = New System.Drawing.Point(85, 10)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(672, 24)
        Me.Panel2.TabIndex = 251
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(28, 3)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Number"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(144, 4)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Date"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(269, 2)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 20)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Cheque No"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(571, 5)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(79, 20)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Rec. Amt."
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(444, 3)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(104, 20)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Cheque Date"
        '
        'recamtord4
        '
        Me.recamtord4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.recamtord4.Location = New System.Drawing.Point(633, 143)
        Me.recamtord4.Name = "recamtord4"
        Me.recamtord4.ReadOnly = True
        Me.recamtord4.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.recamtord4.Size = New System.Drawing.Size(124, 26)
        Me.recamtord4.TabIndex = 29
        '
        'recamtord3
        '
        Me.recamtord3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.recamtord3.Location = New System.Drawing.Point(633, 110)
        Me.recamtord3.Name = "recamtord3"
        Me.recamtord3.ReadOnly = True
        Me.recamtord3.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.recamtord3.Size = New System.Drawing.Size(124, 26)
        Me.recamtord3.TabIndex = 23
        '
        'recamtord2
        '
        Me.recamtord2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.recamtord2.Location = New System.Drawing.Point(633, 77)
        Me.recamtord2.Name = "recamtord2"
        Me.recamtord2.ReadOnly = True
        Me.recamtord2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.recamtord2.Size = New System.Drawing.Size(124, 26)
        Me.recamtord2.TabIndex = 17
        '
        'chdtord4
        '
        Me.chdtord4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chdtord4.Location = New System.Drawing.Point(538, 143)
        Me.chdtord4.Name = "chdtord4"
        Me.chdtord4.ReadOnly = True
        Me.chdtord4.Size = New System.Drawing.Size(87, 26)
        Me.chdtord4.TabIndex = 28
        '
        'chdtord3
        '
        Me.chdtord3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chdtord3.Location = New System.Drawing.Point(538, 110)
        Me.chdtord3.Name = "chdtord3"
        Me.chdtord3.ReadOnly = True
        Me.chdtord3.Size = New System.Drawing.Size(87, 26)
        Me.chdtord3.TabIndex = 22
        '
        'chdtord2
        '
        Me.chdtord2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chdtord2.Location = New System.Drawing.Point(538, 77)
        Me.chdtord2.Name = "chdtord2"
        Me.chdtord2.ReadOnly = True
        Me.chdtord2.Size = New System.Drawing.Size(87, 26)
        Me.chdtord2.TabIndex = 16
        '
        'chnoord4
        '
        Me.chnoord4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chnoord4.Location = New System.Drawing.Point(298, 142)
        Me.chnoord4.Name = "chnoord4"
        Me.chnoord4.ReadOnly = True
        Me.chnoord4.Size = New System.Drawing.Size(225, 26)
        Me.chnoord4.TabIndex = 27
        '
        'chnoord3
        '
        Me.chnoord3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chnoord3.Location = New System.Drawing.Point(298, 109)
        Me.chnoord3.Name = "chnoord3"
        Me.chnoord3.ReadOnly = True
        Me.chnoord3.Size = New System.Drawing.Size(225, 26)
        Me.chnoord3.TabIndex = 21
        '
        'chnoord2
        '
        Me.chnoord2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chnoord2.Location = New System.Drawing.Point(298, 76)
        Me.chnoord2.Name = "chnoord2"
        Me.chnoord2.ReadOnly = True
        Me.chnoord2.Size = New System.Drawing.Size(225, 26)
        Me.chnoord2.TabIndex = 15
        '
        'dtord4
        '
        Me.dtord4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtord4.Location = New System.Drawing.Point(209, 143)
        Me.dtord4.Name = "dtord4"
        Me.dtord4.ReadOnly = True
        Me.dtord4.Size = New System.Drawing.Size(83, 26)
        Me.dtord4.TabIndex = 26
        '
        'dtord3
        '
        Me.dtord3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtord3.Location = New System.Drawing.Point(209, 109)
        Me.dtord3.Name = "dtord3"
        Me.dtord3.ReadOnly = True
        Me.dtord3.Size = New System.Drawing.Size(83, 26)
        Me.dtord3.TabIndex = 20
        '
        'dtord2
        '
        Me.dtord2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtord2.Location = New System.Drawing.Point(209, 76)
        Me.dtord2.Name = "dtord2"
        Me.dtord2.ReadOnly = True
        Me.dtord2.Size = New System.Drawing.Size(83, 26)
        Me.dtord2.TabIndex = 14
        '
        'noord4
        '
        Me.noord4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.noord4.Location = New System.Drawing.Point(85, 143)
        Me.noord4.Name = "noord4"
        Me.noord4.ReadOnly = True
        Me.noord4.Size = New System.Drawing.Size(118, 26)
        Me.noord4.TabIndex = 25
        '
        'noord3
        '
        Me.noord3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.noord3.Location = New System.Drawing.Point(85, 108)
        Me.noord3.Name = "noord3"
        Me.noord3.ReadOnly = True
        Me.noord3.Size = New System.Drawing.Size(118, 26)
        Me.noord3.TabIndex = 19
        '
        'noord2
        '
        Me.noord2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.noord2.Location = New System.Drawing.Point(85, 76)
        Me.noord2.Name = "noord2"
        Me.noord2.ReadOnly = True
        Me.noord2.Size = New System.Drawing.Size(118, 26)
        Me.noord2.TabIndex = 13
        '
        'recamtord1
        '
        Me.recamtord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.recamtord1.Location = New System.Drawing.Point(633, 45)
        Me.recamtord1.Name = "recamtord1"
        Me.recamtord1.ReadOnly = True
        Me.recamtord1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.recamtord1.Size = New System.Drawing.Size(124, 26)
        Me.recamtord1.TabIndex = 11
        '
        'chnoord1
        '
        Me.chnoord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chnoord1.Location = New System.Drawing.Point(298, 45)
        Me.chnoord1.Name = "chnoord1"
        Me.chnoord1.ReadOnly = True
        Me.chnoord1.Size = New System.Drawing.Size(225, 26)
        Me.chnoord1.TabIndex = 9
        '
        'noord1
        '
        Me.noord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.noord1.Location = New System.Drawing.Point(85, 43)
        Me.noord1.Name = "noord1"
        Me.noord1.ReadOnly = True
        Me.noord1.Size = New System.Drawing.Size(118, 26)
        Me.noord1.TabIndex = 7
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(141, 276)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(112, 23)
        Me.Label20.TabIndex = 340
        Me.Label20.Text = "Balance Fund"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(141, 303)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(125, 23)
        Me.Label21.TabIndex = 341
        Me.Label21.Text = "Tender Balance"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(584, 652)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(65, 19)
        Me.Label29.TabIndex = 6
        Me.Label29.Text = "RTGS No"
        '
        'BalFund
        '
        Me.BalFund.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.BalFund.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BalFund.Location = New System.Drawing.Point(319, 278)
        Me.BalFund.Name = "BalFund"
        Me.BalFund.ReadOnly = True
        Me.BalFund.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.BalFund.Size = New System.Drawing.Size(100, 24)
        Me.BalFund.TabIndex = 342
        '
        'TextAmtadm
        '
        Me.TextAmtadm.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextAmtadm.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextAmtadm.Location = New System.Drawing.Point(1098, 401)
        Me.TextAmtadm.Name = "TextAmtadm"
        Me.TextAmtadm.ReadOnly = True
        Me.TextAmtadm.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextAmtadm.Size = New System.Drawing.Size(100, 24)
        Me.TextAmtadm.TabIndex = 360
        '
        'ComboHdNm
        '
        Me.ComboHdNm.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboHdNm.FormattingEnabled = True
        Me.ComboHdNm.Location = New System.Drawing.Point(147, 25)
        Me.ComboHdNm.Name = "ComboHdNm"
        Me.ComboHdNm.Size = New System.Drawing.Size(156, 26)
        Me.ComboHdNm.TabIndex = 1
        '
        'LabelH3
        '
        Me.LabelH3.AutoSize = True
        Me.LabelH3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelH3.Location = New System.Drawing.Point(47, 98)
        Me.LabelH3.Name = "LabelH3"
        Me.LabelH3.Size = New System.Drawing.Size(38, 18)
        Me.LabelH3.TabIndex = 363
        Me.LabelH3.Text = "Year"
        '
        'ComboAdmYr
        '
        Me.ComboAdmYr.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboAdmYr.FormattingEnabled = True
        Me.ComboAdmYr.Location = New System.Drawing.Point(144, 95)
        Me.ComboAdmYr.Name = "ComboAdmYr"
        Me.ComboAdmYr.Size = New System.Drawing.Size(111, 26)
        Me.ComboAdmYr.TabIndex = 3
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(742, 651)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(78, 19)
        Me.Label30.TabIndex = 7
        Me.Label30.Text = "RTGS Date"
        '
        'BillPaid
        '
        Me.BillPaid.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.BillPaid.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BillPaid.Location = New System.Drawing.Point(319, 250)
        Me.BillPaid.Name = "BillPaid"
        Me.BillPaid.ReadOnly = True
        Me.BillPaid.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.BillPaid.Size = New System.Drawing.Size(100, 24)
        Me.BillPaid.TabIndex = 356
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(911, 557)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(125, 23)
        Me.Label15.TabIndex = 357
        Me.Label15.Text = "Tender Balance"
        '
        'TextTend
        '
        Me.TextTend.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextTend.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextTend.Location = New System.Drawing.Point(1098, 557)
        Me.TextTend.Name = "TextTend"
        Me.TextTend.ReadOnly = True
        Me.TextTend.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextTend.Size = New System.Drawing.Size(100, 24)
        Me.TextTend.TabIndex = 358
        Me.TextTend.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextEx
        '
        Me.TextEx.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextEx.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextEx.Location = New System.Drawing.Point(1098, 489)
        Me.TextEx.Name = "TextEx"
        Me.TextEx.ReadOnly = True
        Me.TextEx.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextEx.Size = New System.Drawing.Size(100, 24)
        Me.TextEx.TabIndex = 359
        Me.TextEx.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(46, 66)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(84, 18)
        Me.Label17.TabIndex = 365
        Me.Label17.Text = "Fund Head "
        '
        'ComboFdHd
        '
        Me.ComboFdHd.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboFdHd.FormattingEnabled = True
        Me.ComboFdHd.Location = New System.Drawing.Point(146, 63)
        Me.ComboFdHd.Name = "ComboFdHd"
        Me.ComboFdHd.Size = New System.Drawing.Size(155, 26)
        Me.ComboFdHd.TabIndex = 2
        '
        'TextBillPass
        '
        Me.TextBillPass.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBillPass.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBillPass.Location = New System.Drawing.Point(1098, 432)
        Me.TextBillPass.Name = "TextBillPass"
        Me.TextBillPass.ReadOnly = True
        Me.TextBillPass.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextBillPass.Size = New System.Drawing.Size(100, 24)
        Me.TextBillPass.TabIndex = 346
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(912, 431)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(137, 23)
        Me.Label26.TabIndex = 345
        Me.Label26.Text = "Bill Pass Amount"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(911, 461)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(121, 23)
        Me.Label25.TabIndex = 348
        Me.Label25.Text = "Fund Received"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(912, 491)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(172, 23)
        Me.Label24.TabIndex = 349
        Me.Label24.Text = "Expenditure /Bill Paid"
        '
        'FundDemand
        '
        Me.FundDemand.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.FundDemand.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FundDemand.Location = New System.Drawing.Point(320, 333)
        Me.FundDemand.Name = "FundDemand"
        Me.FundDemand.ReadOnly = True
        Me.FundDemand.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.FundDemand.Size = New System.Drawing.Size(100, 24)
        Me.FundDemand.TabIndex = 343
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(912, 401)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(115, 23)
        Me.Label27.TabIndex = 344
        Me.Label27.Text = "ADM Amount"
        '
        'TextFRec
        '
        Me.TextFRec.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextFRec.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextFRec.Location = New System.Drawing.Point(1098, 461)
        Me.TextFRec.Name = "TextFRec"
        Me.TextFRec.ReadOnly = True
        Me.TextFRec.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextFRec.Size = New System.Drawing.Size(100, 24)
        Me.TextFRec.TabIndex = 347
        Me.TextFRec.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(912, 524)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(112, 23)
        Me.Label23.TabIndex = 350
        Me.Label23.Text = "Balance Fund"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(912, 586)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(118, 23)
        Me.Label22.TabIndex = 351
        Me.Label22.Text = "Fund Demand"
        '
        'TextBFund
        '
        Me.TextBFund.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBFund.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBFund.Location = New System.Drawing.Point(1098, 524)
        Me.TextBFund.Name = "TextBFund"
        Me.TextBFund.ReadOnly = True
        Me.TextBFund.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextBFund.Size = New System.Drawing.Size(100, 24)
        Me.TextBFund.TabIndex = 352
        Me.TextBFund.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextFDemand
        '
        Me.TextFDemand.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextFDemand.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextFDemand.Location = New System.Drawing.Point(1098, 591)
        Me.TextFDemand.Name = "TextFDemand"
        Me.TextFDemand.ReadOnly = True
        Me.TextFDemand.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextFDemand.Size = New System.Drawing.Size(100, 24)
        Me.TextFDemand.TabIndex = 353
        Me.TextFDemand.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(141, 328)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(118, 23)
        Me.Label28.TabIndex = 354
        Me.Label28.Text = "Fund Demand"
        '
        'rtgsno
        '
        Me.rtgsno.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtgsno.Location = New System.Drawing.Point(650, 648)
        Me.rtgsno.Name = "rtgsno"
        Me.rtgsno.ReadOnly = True
        Me.rtgsno.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.rtgsno.Size = New System.Drawing.Size(87, 27)
        Me.rtgsno.TabIndex = 311
        '
        'TenderBal
        '
        Me.TenderBal.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TenderBal.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TenderBal.Location = New System.Drawing.Point(319, 304)
        Me.TenderBal.Name = "TenderBal"
        Me.TenderBal.ReadOnly = True
        Me.TenderBal.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TenderBal.Size = New System.Drawing.Size(100, 24)
        Me.TenderBal.TabIndex = 355
        '
        'rtgsdt
        '
        Me.rtgsdt.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtgsdt.Location = New System.Drawing.Point(822, 648)
        Me.rtgsdt.Name = "rtgsdt"
        Me.rtgsdt.ReadOnly = True
        Me.rtgsdt.Size = New System.Drawing.Size(70, 27)
        Me.rtgsdt.TabIndex = 276
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(47, 28)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(87, 18)
        Me.Label13.TabIndex = 361
        Me.Label13.Text = "Head Name"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Monotype Corsiva", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label8.Location = New System.Drawing.Point(448, -3)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(227, 36)
        Me.Label8.TabIndex = 368
        Me.Label8.Text = "NIDHIVITARAN"
        '
        'NidhiVitaran
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1243, 749)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.TenderBal)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.TextFDemand)
        Me.Controls.Add(Me.TextBFund)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.TextFRec)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.FundDemand)
        Me.Controls.Add(Me.rtgsdt)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.rtgsno)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.TextBillPass)
        Me.Controls.Add(Me.ComboFdHd)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.TextEx)
        Me.Controls.Add(Me.TextTend)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.BillPaid)
        Me.Controls.Add(Me.ComboAdmYr)
        Me.Controls.Add(Me.LabelH3)
        Me.Controls.Add(Me.ComboHdNm)
        Me.Controls.Add(Me.TextAmtadm)
        Me.Controls.Add(Me.BalFund)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.ComboADMno)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.TextFdRec)
        Me.Controls.Add(Me.TextExp)
        Me.Controls.Add(Me.TextADM)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.ComboGP)
        Me.MaximizeBox = False
        Me.Name = "NidhiVitaran"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "NidhiVitaran"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ComboGP As System.Windows.Forms.ComboBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents TextADM As System.Windows.Forms.TextBox
    Friend WithEvents TextExp As System.Windows.Forms.TextBox
    Friend WithEvents TextFdRec As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents ComboADMno As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents chdtord1 As System.Windows.Forms.TextBox
    Friend WithEvents TotRecAmt As System.Windows.Forms.TextBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents recamtord4 As System.Windows.Forms.TextBox
    Friend WithEvents recamtord3 As System.Windows.Forms.TextBox
    Friend WithEvents recamtord2 As System.Windows.Forms.TextBox
    Friend WithEvents chdtord4 As System.Windows.Forms.TextBox
    Friend WithEvents chdtord3 As System.Windows.Forms.TextBox
    Friend WithEvents chdtord2 As System.Windows.Forms.TextBox
    Friend WithEvents chnoord4 As System.Windows.Forms.TextBox
    Friend WithEvents chnoord3 As System.Windows.Forms.TextBox
    Friend WithEvents chnoord2 As System.Windows.Forms.TextBox
    Friend WithEvents dtord4 As System.Windows.Forms.TextBox
    Friend WithEvents dtord3 As System.Windows.Forms.TextBox
    Friend WithEvents dtord2 As System.Windows.Forms.TextBox
    Friend WithEvents noord4 As System.Windows.Forms.TextBox
    Friend WithEvents noord3 As System.Windows.Forms.TextBox
    Friend WithEvents noord2 As System.Windows.Forms.TextBox
    Friend WithEvents recamtord1 As System.Windows.Forms.TextBox
    Friend WithEvents chnoord1 As System.Windows.Forms.TextBox
    Friend WithEvents noord1 As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents BalFund As System.Windows.Forms.TextBox
    Friend WithEvents TextAmtadm As System.Windows.Forms.TextBox
    Friend WithEvents ComboHdNm As System.Windows.Forms.ComboBox
    Friend WithEvents LabelH3 As System.Windows.Forms.Label
    Friend WithEvents ComboAdmYr As System.Windows.Forms.ComboBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents BillPaid As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TextTend As System.Windows.Forms.TextBox
    Friend WithEvents TextEx As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents ComboFdHd As System.Windows.Forms.ComboBox
    Friend WithEvents TextBillPass As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents FundDemand As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents TextFRec As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents TextBFund As System.Windows.Forms.TextBox
    Friend WithEvents TextFDemand As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents rtgsno As System.Windows.Forms.TextBox
    Friend WithEvents TenderBal As System.Windows.Forms.TextBox
    Friend WithEvents rtgsdt As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents dtord1 As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents ButtonO1 As System.Windows.Forms.Button
    Friend WithEvents ButtonO4 As System.Windows.Forms.Button
    Friend WithEvents ButtonO3 As System.Windows.Forms.Button
    Friend WithEvents ButtonO2 As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
End Class
