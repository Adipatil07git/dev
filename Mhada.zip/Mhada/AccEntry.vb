﻿Imports System.Data.OleDb
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Public Class AccEntry
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"
    Dim con, con1, con2, con3, con4 As New OleDbConnection(connectionString)
    Dim adapter As New OleDbDataAdapter()
    Dim str, str1, str2, str3, str4 As String
    Dim com, com1, com2, com3, com4 As OleDbCommand
    Dim oledbda As OleDbDataAdapter
    Dim ds, ds1, ds2, ds3, ds4 As DataSet
    Dim dt, dt1 As New DataTable
    Dim invdt As String
    Dim cmdOLEDB As New OleDbCommand
    Public dr, dr1 As OleDbDataReader
    Dim da As OleDb.OleDbDataAdapter
    Dim totadm, totexp, totbal, totpend, totfdrec, TempFndRec, billpd, tendbal, totPWorkamt, billpd1 As Int64
    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ComboHdNm.DropDownStyle = ComboBoxStyle.DropDownList
        ComboDiv.DropDownStyle = ComboBoxStyle.DropDownList
        ComboAdmYr.DropDownStyle = ComboBoxStyle.DropDownList
        ComboADMno.DropDownStyle = ComboBoxStyle.DropDownList
        ComboGP.DropDownStyle = ComboBoxStyle.DropDownList


        con.Open()

        str = "select Distinct Fund_Name from Testing"
        com = New OleDbCommand(str, con)
        oledbda = New OleDbDataAdapter(com)
        ds = New DataSet
        oledbda.Fill(ds, "Testing")
        ComboHdNm.DataSource = ds.Tables("Testing")
        ComboHdNm.ValueMember = "Fund_Name"
        ComboHdNm.DisplayMember = "Fund_Name"

        With Me.DataGridView1
            .Columns.Add("GP No", "GP No")
            .Columns.Add("ADM Amount", "ADM Amount")
            .Columns.Add("Fund Rec.", "Fund Rec.")
            .Columns.Add("Expenditure", "Expenditure")
            .Columns.Add("RTGS No", "RTGS No")
            .Columns.Add("RTGS Date", "RTGS Date")
            .Columns.Add("Status", "Status")

            .AllowUserToAddRows = False
            .EditMode = DataGridViewEditMode.EditProgrammatically
        End With

        DataGridView1.Columns(0).Width = 130
        DataGridView1.Columns(1).Width = 90
        DataGridView1.Columns(2).Width = 90
        DataGridView1.Columns(3).Width = 90
        DataGridView1.Columns(4).Width = 90
        DataGridView1.Columns(5).Width = 100
        DataGridView1.Columns(6).Width = 90

        DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DataGridView1.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        DataGridView1.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        DataGridView1.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        totPWorkamt = 0

    End Sub
    Private Sub ComboHdNm_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboHdNm.SelectionChangeCommitted
        str1 = "select Distinct Div_Name from Testing where Fund_Name='" & ComboHdNm.SelectedValue & "' "
        com1 = New OleDbCommand(str1, con)
        oledbda = New OleDbDataAdapter(com1)
        ds = New DataSet
        oledbda.Fill(ds, "Testing")
        ComboDiv.DataSource = ds.Tables("Testing")
        ComboDiv.ValueMember = "Div_Name"
        ComboDiv.DisplayMember = "Div_Name"
        'ComboGP.Focus()

    End Sub
    Private Sub ComboDiv_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboDiv.SelectionChangeCommitted
        str2 = "select Distinct ADM_Year from Testing where Fund_Name='" & ComboHdNm.SelectedValue & "' AND Div_Name ='" & ComboDiv.SelectedValue & "'"
        com2 = New OleDbCommand(str2, con)
        oledbda = New OleDbDataAdapter(com2)
        ds = New DataSet
        oledbda.Fill(ds, "Testing")
        ComboAdmYr.DataSource = ds.Tables("Testing")
        ComboAdmYr.ValueMember = "ADM_Year"
        ComboAdmYr.DisplayMember = "ADM_Year"
    End Sub
    Private Sub ComboAdmYr_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboAdmYr.SelectionChangeCommitted
        str3 = "select Distinct ADM_No from Testing where Fund_Name='" & ComboHdNm.SelectedValue & "' AND Div_Name ='" & ComboDiv.SelectedValue & "' AND ADM_Year ='" & ComboAdmYr.SelectedValue & "' "
        com3 = New OleDbCommand(str3, con)
        oledbda = New OleDbDataAdapter(com3)
        ds = New DataSet
        oledbda.Fill(ds, "Testing")
        ComboADMno.DataSource = ds.Tables("Testing")
        ComboADMno.ValueMember = "ADM_No"
        ComboADMno.DisplayMember = "ADM_No"

    End Sub
    Private Sub ComboADMno_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboADMno.SelectionChangeCommitted
        Dim dt As New DataTable
        DataGridView1.DataMember = Nothing

        Dim totadmamt, totfndrec As Int64
        totadmamt = totfndrec = 0

        'ADMamt.Text = ""
        noord1.Text = ""
        noord2.Text = ""
        noord3.Text = ""
        noord4.Text = ""
        dtord1.Text = ""
        dtord2.Text = ""
        dtord3.Text = ""
        dtord4.Text = ""
        chnoord1.Text = ""
        chnoord2.Text = ""
        chnoord3.Text = ""
        chnoord4.Text = ""
        chdtord1.Text = ""
        chdtord2.Text = ""
        chdtord3.Text = ""
        chdtord4.Text = ""
        recamtord1.Text = ""
        recamtord2.Text = ""
        recamtord2.Text = ""
        recamtord3.Text = ""
        recamtord4.Text = ""
        TotRecAmt.Text = ""
        rtgsdt.Text = ""
        rtgsno.Text = ""
        TextAmtadm.Text = ""
        TextBillPass.Text = ""
        TextFRec.Text = ""
        TextEx.Text = ""
        TextBFund.Text = ""
        TextTend.Text = ""
        TextFDemand.Text = ""

        str1 = "select Distinct GP_No from Testing where ADM_No='" & ComboADMno.SelectedValue & "'"
        com1 = New OleDbCommand(str1, con)
        oledbda = New OleDbDataAdapter(com1)
        ds = New DataSet
        oledbda.Fill(ds, "Testing")
        ComboGP.DataSource = ds.Tables("Testing")
        ComboGP.ValueMember = "GP_No"
        ComboGP.DisplayMember = "GP_No"

        da = New OleDbDataAdapter("SELECT * FROM Testing where ADM_No = '" & ComboADMno.SelectedValue & "' ", con)
        da.Fill(dt)

        totadm = 0
        totexp = 0
        totbal = 0
        totpend = 0
        totfdrec = 0
        billpd = 0
        tendbal = 0
        totPWorkamt = 0

        For Each dr1 As DataRow In dt.Rows
            Me.DataGridView1.Rows.Add()
            With Me.DataGridView1.Rows(Me.DataGridView1.Rows.Count - 1)
                .Cells("GP No").Value = dr1("GP_No")
                .Cells("ADM Amount").Value = dr1("ADM_Amt")
                .Cells("Fund Rec.").Value = dr1("Tot_Fund_Rec")
                .Cells("Expenditure").Value = dr1("Exp_Amt")
                .Cells("RTGS No").Value = dr1("Cheque_Rtgs_No")
                .Cells("RTGS Date").Value = dr1("Cheque_Date")

                totadm = totadm + Val(dr1("ADM_Amt").ToString)
                totexp = totexp + Val(dr1("Exp_Amt").ToString)
                totbal = totbal + Val(dr1("Tender_Bal_Amt").ToString)
                'totpend = totpend + Val(dr1("Pending_Work_Amt").ToString)
                totPWorkamt = totPWorkamt + Val(dr1("Pending_Work_Amt").ToString)
                totfdrec = totfdrec + Val(dr1("Tot_Fund_Rec").ToString)
                tendbal = tendbal + Val(dr1("Tender_Bal_Amt").ToString)

                If Len(dr1("Cheque_Rtgs_No").ToString) > 0 Then
                    billpd = billpd + Val(dr1("Exp_Amt").ToString)
                    .Cells("Status").Value = "Paid"
                Else
                    .Cells("Status").Value = "UnPaid"
                End If
                
            End With
        Next

        TextADM.Text = totadm
        TextExp.Text = totexp
        TextFdRec.Text = totfdrec
        BalFund.Text = Val(totPWorkamt)
        FundDemand.Text = totadm - totfdrec
        BillPaid.Text = billpd
        TenderBal.Text = tendbal
    End Sub
    Private Sub ComboGP_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboGP.SelectionChangeCommitted
        TextTend.Text = ""
        TextBFund.Text = ""
        TextEx.Text = ""
        TextFRec.Text = ""
        TextBillPass.Text = ""
        billpd1 = 0

        noord1.Text = ""
        dtord1.Text = ""
        chnoord1.Text = ""
        chdtord1.Text = ""
        recamtord1.Text = ""

        noord2.Text = ""
        dtord2.Text = ""
        chnoord2.Text = ""
        chdtord2.Text = ""
        recamtord2.Text = ""

        noord3.Text = ""
        dtord3.Text = ""
        chnoord3.Text = ""
        chdtord3.Text = ""
        recamtord3.Text = ""

        noord4.Text = ""
        dtord4.Text = ""
        chnoord4.Text = ""
        chdtord4.Text = ""
        recamtord4.Text = ""

        str2 = "select * from Testing where ADM_No='" & ComboADMno.SelectedValue & "' AND GP_NO='" & ComboGP.SelectedValue & "' "
        com2 = New OleDbCommand(str2, con)
        dr = com2.ExecuteReader
        While dr.Read()
            rtgsno.Text = dr("Cheque_Rtgs_No").ToString
            rtgsdt.Text = dr("Cheque_Date").ToString
            TextAmtadm.Text = dr("ADM_Amt").ToString
            TextBillPass.Text = dr("Exp_Amt").ToString
            TextFRec.Text = dr("Tot_Fund_Rec").ToString
            If Len(dr("Cheque_Rtgs_No").ToString) > 0 Then
                TextEx.Text = dr("Exp_Amt").ToString
            End If
            TextBFund.Text = Val(TextFRec.Text) - Val(TextEx.Text)
            TextTend.Text = dr("Tender_Bal_Amt").ToString

            noord1.Text = dr("Fund_Rec_Order1").ToString

            'dtord1.Text = dr("Order1_Date").ToString
            If Len(dr("Order1_Date").ToString) > 10 Then
                dtord1.Text = dr("Order1_Date").ToString.Substring(0, 10)
            End If
            chnoord1.Text = dr("Order1_Cheque_No").ToString

            'chdtord1.Text = dr("Order1_Cheque_Date").ToString
            If Len(dr("Order1_Cheque_Date").ToString) > 10 Then
                chdtord1.Text = dr("Order1_Cheque_Date").ToString.Substring(0, 10)
            End If

            recamtord1.Text = dr("Order1_Rec_Amt").ToString
            noord2.Text = dr("Fund_Rec_Order2").ToString
            'dtord2.Text = dr("Order2_Date").ToString
            If Len(dr("Order2_Date").ToString) > 10 Then
                dtord2.Text = dr("Order2_Date").ToString.Substring(0, 10)
            End If

            chnoord2.Text = dr("Order2_Cheque_No").ToString
            'chdtord2.Text = dr("Order2_Cheque_Date").ToString
            If Len(dr("Order2_Date").ToString) > 10 Then
                chdtord2.Text = dr("Order2_Cheque_Date").ToString.Substring(0, 10)
            End If

            recamtord2.Text = dr("Order2_Rec_Amt").ToString

            noord3.Text = dr("Fund_Rec_Order3").ToString
            dtord3.Text = dr("Order3_Date").ToString
            chnoord3.Text = dr("Order3_Cheque_No").ToString
            chdtord3.Text = dr("Order3_Cheque_Date").ToString
            recamtord3.Text = dr("Order3_Rec_Amt").ToString

            noord4.Text = dr("Fund_Rec_Order4").ToString
            dtord4.Text = dr("Order4_Date").ToString
            chnoord4.Text = dr("Order4_Cheque_No").ToString
            chdtord4.Text = dr("Order4_Cheque_Date").ToString
            recamtord4.Text = dr("Order4_Rec_Amt").ToString

            TotRecAmt.Text = Val(dr("Order1_Rec_Amt").ToString) + Val(dr("Order2_Rec_Amt").ToString) + Val(dr("Order3_Rec_Amt").ToString) + Val(dr("Order4_Rec_Amt").ToString)

            If Len(dr("Cheque_Rtgs_No").ToString) > 0 Then
                billpd1 = billpd1 + Val(dr("Exp_Amt").ToString)
            Else
            End If

        End While

        TextEx.Text = Val(billpd1)
        TempFndRec = totfdrec - Val(TotRecAmt.Text)
        TextFDemand.Text = Val(TextEx.Text) - Val(TextFRec.Text)
        'FundDemand.Text = totexp - totfdrec

    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        'str = "update Testing set Fund_Rec_Order1 ='" & noord1.Text & "', Order1_Date = '" & dtord1.Text & "', Order1_Cheque_No='" & chnoord1.Text & "', Order1_Cheque_Date='" & chdtord1.Text & "', Order1_Rec_Amt='" & recamtord1.Text & "', Tot_Fund_Rec='" & recamtord1.Text & "', UpdatedAt='" & Now() & "', UpdatedBy='Admin' where ADM_No = '" & ComboADMno.SelectedValue & "' AND GP_No = '" & ComboGP.SelectedValue & "' "
        'str = "update Testing set Fund_Rec_Order1 ='" & noord1.Text & "', Order1_Date = '" & dtord1.Text & "', Order1_Cheque_No='" & chnoord1.Text & "', Order1_Cheque_Date='" & chdtord1.Text & "', Order1_Rec_Amt='" & recamtord1.Text & "', Fund_Rec_Order2 ='" & noord2.Text & "', Order2_Date = '" & dtord2.Text & "', Order2_Cheque_No='" & chnoord2.Text & "', Order2_Cheque_Date='" & chdtord2.Text & "', Order2_Rec_Amt='" & recamtord2.Text & "', Fund_Rec_Order3 ='" & noord3.Text & "', Order3_Date = '" & dtord3.Text & "', Order3_Cheque_No='" & chnoord3.Text & "', Order3_Cheque_Date='" & chdtord3.Text & "', Order3_Rec_Amt='" & recamtord3.Text & "', Tot_Fund_Rec='" & Val(recamtord1.Text) + Val(recamtord2.Text) + Val(recamtord3.Text) & "', UpdatedAt='" & Now() & "', UpdatedBy='Admin' where ADM_No = '" & ComboADMno.SelectedValue & "' AND GP_No = '" & ComboGP.SelectedValue & "' "
        'str = "update Testing set Fund_Rec_Order1 ='" & noord1.Text & "', Order1_Date = '" & dtord1.Text & "', Order1_Cheque_No='" & chnoord1.Text & "', Order1_Cheque_Date='" & chdtord1.Text & "', Order1_Rec_Amt='" & recamtord1.Text & "', Fund_Rec_Order2 ='" & noord2.Text & "', Order2_Date = '" & dtord2.Text & "', Order2_Cheque_No='" & chnoord2.Text & "', Order2_Cheque_Date='" & chdtord2.Text & "', Order2_Rec_Amt='" & recamtord2.Text & "', Tot_Fund_Rec='" & Val(recamtord1.Text) + Val(recamtord2.Text) + Val(recamtord3.Text) & "', UpdatedAt='" & Now() & "', UpdatedBy='Admin' where ADM_No = '" & ComboADMno.SelectedValue & "' AND GP_No = '" & ComboGP.SelectedValue & "' "

        If Len(chnoord2.Text) > 0 Then
            str = "update Testing set Fund_Rec_Order1 ='" & noord1.Text & "', Order1_Date = '" & dtord1.Text & "', Order1_Cheque_No='" & chnoord1.Text & "', Order1_Cheque_Date='" & chdtord1.Text & "', Order1_Rec_Amt='" & recamtord1.Text & "', Fund_Rec_Order2 ='" & noord2.Text & "', Order2_Date = '" & dtord2.Text & "', Order2_Cheque_No='" & chnoord2.Text & "', Order2_Cheque_Date='" & chdtord2.Text & "', Order2_Rec_Amt='" & recamtord2.Text & "', Tot_Fund_Rec='" & Val(TotRecAmt.Text) & "', UpdatedAt='" & Now() & "', UpdatedBy='Admin' where ADM_No = '" & ComboADMno.SelectedValue & "' AND GP_No = '" & ComboGP.SelectedValue & "' "
        ElseIf Len(chnoord1.Text) > 0 And Len(chnoord2.Text) = 0 Then
            str = "update Testing set Fund_Rec_Order1 ='" & noord1.Text & "', Order1_Date = '" & dtord1.Text & "', Order1_Cheque_No='" & chnoord1.Text & "', Order1_Cheque_Date='" & chdtord1.Text & "', Order1_Rec_Amt='" & recamtord1.Text & "', Tot_Fund_Rec='" & Val(TotRecAmt.Text) & "', UpdatedAt='" & Now() & "', UpdatedBy='Admin' where ADM_No = '" & ComboADMno.SelectedValue & "' AND GP_No = '" & ComboGP.SelectedValue & "' "
        End If

        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            Dim result = MessageBox.Show("Data successfully Saved.", "MHADA")

            noord1.Text = ""
            dtord1.Text = ""
            chnoord1.Text = ""
            chdtord1.Text = ""
            recamtord1.Text = ""

            noord2.Text = ""
            dtord2.Text = ""
            chnoord2.Text = ""
            chdtord2.Text = ""
            recamtord2.Text = ""

            noord3.Text = ""
            dtord3.Text = ""
            chnoord3.Text = ""
            chdtord3.Text = ""
            recamtord3.Text = ""

            noord4.Text = ""
            dtord4.Text = ""
            chnoord4.Text = ""
            chdtord4.Text = ""
            recamtord4.Text = ""


            ComboGP.Focus()
            'con.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        'con.Close()

        'Me.Close()
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        con.Close()
        Me.Close()
    End Sub
    Public Sub List()
    End Sub
    Private Sub recamtord1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles recamtord1.TextChanged
        TotRecAmt.Text = Val(recamtord1.Text) + Val(recamtord2.Text) + Val(recamtord3.Text) + Val(recamtord4.Text)

        totfdrec = TempFndRec + Val(TotRecAmt.Text)

        If Val(TotRecAmt.Text) > Val(TextAmtadm.Text) Then
            MsgBox("Received Amount is invalid.")
            recamtord1.Text = 0
            recamtord1.Focus()
        Else
        End If
        If Val(totfdrec) > Val(totadm) Then
            MsgBox("Received Fund is invalid.")
            'recamtord1.Text = ""
            recamtord1.Focus()
        Else
        End If
    End Sub
    Private Sub recamtord2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles recamtord2.TextChanged
        TotRecAmt.Text = Val(recamtord1.Text) + Val(recamtord2.Text) + Val(recamtord3.Text) + Val(recamtord4.Text)

        If Val(TotRecAmt.Text) > Val(TextAmtadm.Text) Then
            MsgBox("Received Amount is invalid")
            'recamtord2.Text = ""
            recamtord2.Focus()
        Else

        End If

    End Sub
    Private Sub recamtord3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles recamtord3.TextChanged
        TotRecAmt.Text = Val(recamtord1.Text) + Val(recamtord2.Text) + Val(recamtord3.Text) + Val(recamtord4.Text)

        If Val(TotRecAmt.Text) > Val(TextAmtadm.Text) Then
            MsgBox("Received Amount is invalid")
            'recamtord3.Text = ""
            recamtord3.Focus()
        Else
        End If
    End Sub
    Private Sub recamtord4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles recamtord4.TextChanged
        TotRecAmt.Text = Val(recamtord1.Text) + Val(recamtord2.Text) + Val(recamtord3.Text) + Val(recamtord4.Text)

        If Val(TotRecAmt.Text) > Val(TextAmtadm.Text) Then
            MsgBox("Received Amount is invalid")
            'recamtord4.Text = ""
            recamtord4.Focus()
        Else

        End If

    End Sub

    Private Sub ComboHdNm_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboHdNm.SelectedIndexChanged

    End Sub

    Private Sub ComboFdHd_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboDiv.SelectedIndexChanged

    End Sub

    Private Sub ComboAdmYr_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboAdmYr.SelectedIndexChanged

    End Sub

    Private Sub ComboGP_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboGP.SelectedIndexChanged

    End Sub

    Private Sub Label32_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label32.Click

    End Sub

    Private Sub chnoord1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chnoord1.TextChanged
  
    End Sub

    Private Sub chnoord1_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles chnoord1.Validating
        
    End Sub

    Private Sub chnoord2_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles chnoord2.LostFocus
        If chnoord2.Text = chnoord1.Text Then
            MsgBox("Duplicate Checque No.")
            chnoord2.Text = ""
            chnoord2.Focus()

        End If
    End Sub
    Private Sub chnoord3_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles chnoord3.LostFocus
        If (chnoord3.Text = chnoord2.Text) Or (chnoord3.Text = chnoord1.Text) Then
            MsgBox("Duplicate Checque No.")
            chnoord3.Text = ""
            chnoord3.Focus()
        End If
    End Sub
    Private Sub chnoord4_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles chnoord4.LostFocus
        If (chnoord4.Text = chnoord3.Text) Or (chnoord4.Text = chnoord2.Text) Or (chnoord4.Text = chnoord1.Text) Then
            MsgBox("Duplicate Checque No.")
            chnoord4.Text = ""
            chnoord4.Focus()

        End If

    End Sub

    Private Sub chnoord4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chnoord4.TextChanged

    End Sub

    Private Sub chdtord3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chdtord3.TextChanged

    End Sub
End Class