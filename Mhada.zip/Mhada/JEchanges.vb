﻿Imports System.Data.OleDb
Public Class JEchanges
    Public dr As OleDbDataReader
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"
    Dim con As New OleDbConnection(connectionString)
    Dim adapter As New OleDbDataAdapter()
    Dim str As String
    Dim com As OleDbCommand
    Dim oledbda As OleDbDataAdapter
    Dim ds As DataSet
    Dim dt As New DataTable

    Private Sub JEchanges_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboName.DropDownStyle = ComboBoxStyle.DropDownList
        con.Open()
        str = "select Distinct JE_Name from JElist"
        com = New OleDbCommand(str, con)
        oledbda = New OleDbDataAdapter(com)
        ds = New DataSet
        oledbda.Fill(ds, "JElist")
        ComboName.DataSource = ds.Tables("JElist")
        ComboName.ValueMember = "JE_Name"
        ComboName.DisplayMember = "JE_Name"

    End Sub
    Private Sub ComboName_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboName.SelectionChangeCommitted
        str = "SELECT * from JElist where JE_Name = '" & ComboName.SelectedValue & "' "
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        dr = cmd.ExecuteReader
        While dr.Read()
            TextJE.Text = dr("JE_Name").ToString
        End While
        'con.Close()

    End Sub

    Private Sub Button_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_save.Click
        str = "update JElist set JE_Name ='" & TextJE.Text & "', Entry_By = 'New',  created = ' " & Now() & "' where JE_Name = '" & ComboName.SelectedValue & "' "
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            MsgBox("Executive Engineer Name Updated.")
            'con.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        TextJE.Text = ""
        con.Close()

    End Sub

    Private Sub Button_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Exit.Click
        con.Close()
        Me.Close()

    End Sub
End Class