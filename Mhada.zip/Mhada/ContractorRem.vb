﻿Imports System.Data.OleDb
Public Class ContractorRem
    Public dr As OleDbDataReader
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"
    Dim con As New OleDbConnection(connectionString)
    Dim adapter As New OleDbDataAdapter()
    Dim str As String
    Dim com As OleDbCommand
    Dim oledbda As OleDbDataAdapter
    Dim ds As DataSet
    Dim dt As New DataTable

    Private Sub ContractorRem_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboName.DropDownStyle = ComboBoxStyle.DropDownList
        con.Open()
        str = "select Distinct Agency_Name from Contractor_List"
        com = New OleDbCommand(str, con)
        oledbda = New OleDbDataAdapter(com)
        ds = New DataSet
        oledbda.Fill(ds, "Contractor_List")
        ComboName.DataSource = ds.Tables("Contractor_List")
        ComboName.ValueMember = "Agency_Name"
        ComboName.DisplayMember = "Agency_Name"

    End Sub
    Private Sub ComboName_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboName.SelectionChangeCommitted
        str = "SELECT * from Contractor_List where Agency_Name = '" & ComboName.SelectedValue & "' "
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        dr = cmd.ExecuteReader
        While dr.Read()
            TextName.Text = dr("Agency_Name").ToString
            TextPan.Text = dr("Ag_PAN_No").ToString
            TextGst.Text = dr("Ag_GST_No").ToString
            TextAdd.Text = dr("Ag_Branch_Address").ToString
            TextMob.Text = dr("Ag_Mobile").ToString
            TextPhone.Text = dr("Ag_Phone").ToString
            TextEmail.Text = dr("Ag_Email").ToString
        End While

    End Sub

    Private Sub Button_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_save.Click
        com = New OleDbCommand("delete from Contractor_List where Agency_Name = ComboName.selectedvalue ", con)
        com.Parameters.AddWithValue("Agency_Name", ComboName.SelectedValue)
        com.ExecuteNonQuery()
        MsgBox("Agency record Successfuly Removed.")
        con.Close()
        Me.Close()

    End Sub

    Private Sub Button_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Exit.Click
        con.Close()
        Me.Close()

    End Sub
End Class