﻿Imports System.Data.OleDb
Public Class MPChange
    Public dr As OleDbDataReader
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"
    Dim con As New OleDbConnection(connectionString)
    Dim adapter As New OleDbDataAdapter()
    Dim str As String
    Dim com As OleDbCommand
    Dim oledbda As OleDbDataAdapter
    Dim ds As DataSet
    Dim dt As New DataTable

    Private Sub MPChange_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboMpname.DropDownStyle = ComboBoxStyle.DropDownList
        con.Open()
        str = "select Distinct MPMLA_Name from MP_MLA"
        com = New OleDbCommand(str, con)
        oledbda = New OleDbDataAdapter(com)
        ds = New DataSet
        oledbda.Fill(ds, "MP_MLA")
        ComboMpname.DataSource = ds.Tables("MP_MLA")
        ComboMpname.ValueMember = "MPMLA_Name"
        ComboMpname.DisplayMember = "MPMLA_Name"

    End Sub

    Private Sub ComboMpname_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboMpname.SelectionChangeCommitted
        str = "SELECT * from MP_MLA where MPMLA_Name = '" & ComboMpname.SelectedValue & "' "
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        dr = cmd.ExecuteReader
        While dr.Read()
            TextMP.Text = dr("MPMLA_Name").ToString
        End While

    End Sub

    Private Sub Button_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_save.Click
        str = "update MP_MLA set MPMLA_Name='" & textMP.Text & "', CONSTITUENCY='" & ComboType.SelectedValue & "', Entry_By = 'New',  created = ' " & Now() & "' where MPMLA_Name = '" & ComboMpname.SelectedValue & "' "
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            MsgBox("Executive Engineer Name Updated.")
            'con.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        textMP.Text = ""
 
    End Sub

    Private Sub Button_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Exit.Click
        con.Close()
        Me.Close()

    End Sub
End Class