﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MPAdd
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtcons = New System.Windows.Forms.TextBox
        Me.txtmp = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Button_Exit = New System.Windows.Forms.Button
        Me.Button_save = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.ComboType = New System.Windows.Forms.ComboBox
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.TYPEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.MPMLANameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.CONSTITUENCYDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.MPMLABindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MhadaDataSet5 = New Mhada.mhadaDataSet5
        Me.MP_MLATableAdapter = New Mhada.mhadaDataSet5TableAdapters.MP_MLATableAdapter
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MPMLABindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MhadaDataSet5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 107)
        Me.Label1.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(101, 20)
        Me.Label1.TabIndex = 82
        Me.Label1.Text = "Constituency"
        '
        'txtcons
        '
        Me.txtcons.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtcons.Location = New System.Drawing.Point(153, 104)
        Me.txtcons.Margin = New System.Windows.Forms.Padding(7)
        Me.txtcons.MaxLength = 25
        Me.txtcons.Name = "txtcons"
        Me.txtcons.Size = New System.Drawing.Size(234, 26)
        Me.txtcons.TabIndex = 77
        '
        'txtmp
        '
        Me.txtmp.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtmp.Location = New System.Drawing.Point(153, 71)
        Me.txtmp.Margin = New System.Windows.Forms.Padding(7)
        Me.txtmp.MaxLength = 50
        Me.txtmp.Name = "txtmp"
        Me.txtmp.Size = New System.Drawing.Size(234, 26)
        Me.txtmp.TabIndex = 76
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 74)
        Me.Label2.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(123, 20)
        Me.Label2.TabIndex = 80
        Me.Label2.Text = "MP / MLA Name"
        '
        'Button_Exit
        '
        Me.Button_Exit.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Button_Exit.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Exit.Location = New System.Drawing.Point(297, 244)
        Me.Button_Exit.Margin = New System.Windows.Forms.Padding(7, 9, 7, 9)
        Me.Button_Exit.Name = "Button_Exit"
        Me.Button_Exit.Size = New System.Drawing.Size(90, 54)
        Me.Button_Exit.TabIndex = 84
        Me.Button_Exit.Text = "Close"
        Me.Button_Exit.UseVisualStyleBackColor = False
        '
        'Button_save
        '
        Me.Button_save.BackColor = System.Drawing.Color.PaleGreen
        Me.Button_save.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_save.Location = New System.Drawing.Point(31, 244)
        Me.Button_save.Margin = New System.Windows.Forms.Padding(7, 9, 7, 9)
        Me.Button_save.Name = "Button_save"
        Me.Button_save.Size = New System.Drawing.Size(97, 54)
        Me.Button_save.TabIndex = 83
        Me.Button_save.Text = "Save"
        Me.Button_save.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(16, 148)
        Me.Label3.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 20)
        Me.Label3.TabIndex = 85
        Me.Label3.Text = "Type"
        '
        'ComboType
        '
        Me.ComboType.FormattingEnabled = True
        Me.ComboType.Items.AddRange(New Object() {"MP", "MLA", "MLC"})
        Me.ComboType.Location = New System.Drawing.Point(153, 145)
        Me.ComboType.Name = "ComboType"
        Me.ComboType.Size = New System.Drawing.Size(129, 28)
        Me.ComboType.TabIndex = 86
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.TYPEDataGridViewTextBoxColumn, Me.MPMLANameDataGridViewTextBoxColumn, Me.CONSTITUENCYDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.MPMLABindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(443, 77)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(470, 381)
        Me.DataGridView1.TabIndex = 87
        '
        'TYPEDataGridViewTextBoxColumn
        '
        Me.TYPEDataGridViewTextBoxColumn.DataPropertyName = "TYPE"
        Me.TYPEDataGridViewTextBoxColumn.HeaderText = "TYPE"
        Me.TYPEDataGridViewTextBoxColumn.Name = "TYPEDataGridViewTextBoxColumn"
        Me.TYPEDataGridViewTextBoxColumn.ReadOnly = True
        '
        'MPMLANameDataGridViewTextBoxColumn
        '
        Me.MPMLANameDataGridViewTextBoxColumn.DataPropertyName = "MPMLA_Name"
        Me.MPMLANameDataGridViewTextBoxColumn.HeaderText = "MPMLA_Name"
        Me.MPMLANameDataGridViewTextBoxColumn.Name = "MPMLANameDataGridViewTextBoxColumn"
        Me.MPMLANameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'CONSTITUENCYDataGridViewTextBoxColumn
        '
        Me.CONSTITUENCYDataGridViewTextBoxColumn.DataPropertyName = "CONSTITUENCY"
        Me.CONSTITUENCYDataGridViewTextBoxColumn.HeaderText = "CONSTITUENCY"
        Me.CONSTITUENCYDataGridViewTextBoxColumn.Name = "CONSTITUENCYDataGridViewTextBoxColumn"
        Me.CONSTITUENCYDataGridViewTextBoxColumn.ReadOnly = True
        '
        'MPMLABindingSource
        '
        Me.MPMLABindingSource.DataMember = "MP_MLA"
        Me.MPMLABindingSource.DataSource = Me.MhadaDataSet5
        '
        'MhadaDataSet5
        '
        Me.MhadaDataSet5.DataSetName = "mhadaDataSet5"
        Me.MhadaDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'MP_MLATableAdapter
        '
        Me.MP_MLATableAdapter.ClearBeforeFill = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.DarkRed
        Me.Label4.Location = New System.Drawing.Point(624, 55)
        Me.Label4.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(106, 20)
        Me.Label4.TabIndex = 88
        Me.Label4.Text = "MP / MLA List"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Monotype Corsiva", 24.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(366, 4)
        Me.Label8.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(315, 39)
        Me.Label8.TabIndex = 108
        Me.Label8.Text = "MP / MLA Entry Form"
        '
        'MPAdd
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(958, 519)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.ComboType)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Button_Exit)
        Me.Controls.Add(Me.Button_save)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtcons)
        Me.Controls.Add(Me.txtmp)
        Me.Controls.Add(Me.Label2)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "MPAdd"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Add New MP / MLA"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MPMLABindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MhadaDataSet5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtcons As System.Windows.Forms.TextBox
    Friend WithEvents txtmp As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button_Exit As System.Windows.Forms.Button
    Friend WithEvents Button_save As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ComboType As System.Windows.Forms.ComboBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents MhadaDataSet5 As Mhada.mhadaDataSet5
    Friend WithEvents MPMLABindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents MP_MLATableAdapter As Mhada.mhadaDataSet5TableAdapters.MP_MLATableAdapter
    Friend WithEvents TYPEDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MPMLANameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CONSTITUENCYDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
End Class
