﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Third
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.datepaycheque = New System.Windows.Forms.DateTimePicker
        Me.datefundrecorder = New System.Windows.Forms.DateTimePicker
        Me.datefundcoll = New System.Windows.Forms.DateTimePicker
        Me.txtvoucher = New System.Windows.Forms.TextBox
        Me.txtpaycq = New System.Windows.Forms.TextBox
        Me.txtvidecoll = New System.Windows.Forms.TextBox
        Me.txtcollfund = New System.Windows.Forms.TextBox
        Me.txtrcfund = New System.Windows.Forms.TextBox
        Me.Label35 = New System.Windows.Forms.Label
        Me.Label34 = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'datepaycheque
        '
        Me.datepaycheque.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.datepaycheque.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.datepaycheque.Location = New System.Drawing.Point(352, 269)
        Me.datepaycheque.Name = "datepaycheque"
        Me.datepaycheque.Size = New System.Drawing.Size(105, 26)
        Me.datepaycheque.TabIndex = 212
        Me.datepaycheque.Value = New Date(2023, 8, 16, 11, 25, 31, 0)
        '
        'datefundrecorder
        '
        Me.datefundrecorder.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.datefundrecorder.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.datefundrecorder.Location = New System.Drawing.Point(352, 125)
        Me.datefundrecorder.Name = "datefundrecorder"
        Me.datefundrecorder.Size = New System.Drawing.Size(141, 26)
        Me.datefundrecorder.TabIndex = 208
        Me.datefundrecorder.Value = New Date(2023, 8, 16, 11, 25, 31, 0)
        '
        'datefundcoll
        '
        Me.datefundcoll.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.datefundcoll.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.datefundcoll.Location = New System.Drawing.Point(352, 197)
        Me.datefundcoll.Name = "datefundcoll"
        Me.datefundcoll.Size = New System.Drawing.Size(118, 26)
        Me.datefundcoll.TabIndex = 210
        Me.datefundcoll.Value = New Date(2023, 8, 16, 11, 25, 31, 0)
        '
        'txtvoucher
        '
        Me.txtvoucher.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtvoucher.Location = New System.Drawing.Point(352, 314)
        Me.txtvoucher.Name = "txtvoucher"
        Me.txtvoucher.Size = New System.Drawing.Size(175, 26)
        Me.txtvoucher.TabIndex = 213
        '
        'txtpaycq
        '
        Me.txtpaycq.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpaycq.Location = New System.Drawing.Point(352, 233)
        Me.txtpaycq.Name = "txtpaycq"
        Me.txtpaycq.Size = New System.Drawing.Size(175, 26)
        Me.txtpaycq.TabIndex = 211
        '
        'txtvidecoll
        '
        Me.txtvidecoll.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtvidecoll.Location = New System.Drawing.Point(352, 160)
        Me.txtvidecoll.Name = "txtvidecoll"
        Me.txtvidecoll.Size = New System.Drawing.Size(175, 26)
        Me.txtvidecoll.TabIndex = 209
        '
        'txtcollfund
        '
        Me.txtcollfund.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcollfund.Location = New System.Drawing.Point(352, 85)
        Me.txtcollfund.Name = "txtcollfund"
        Me.txtcollfund.Size = New System.Drawing.Size(175, 26)
        Me.txtcollfund.TabIndex = 207
        '
        'txtrcfund
        '
        Me.txtrcfund.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtrcfund.Location = New System.Drawing.Point(352, 44)
        Me.txtrcfund.Name = "txtrcfund"
        Me.txtrcfund.Size = New System.Drawing.Size(175, 26)
        Me.txtrcfund.TabIndex = 206
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(30, 304)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(142, 20)
        Me.Label35.TabIndex = 222
        Me.Label35.Text = "Cash Voucher No :"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(30, 273)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(312, 20)
        Me.Label34.TabIndex = 221
        Me.Label34.Text = "MHADA Contrator Payment Cheque Date :"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(30, 236)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(297, 20)
        Me.Label33.TabIndex = 220
        Me.Label33.Text = "MHADA Contrator Payment Cheque No :"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(30, 197)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(325, 20)
        Me.Label32.TabIndex = 219
        Me.Label32.Text = "Fund Received Vide Collector Cheque Date :"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(288, 233)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(0, 20)
        Me.Label31.TabIndex = 218
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(33, 163)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(310, 20)
        Me.Label30.TabIndex = 217
        Me.Label30.Text = "Fund Received Vide Collector Cheque No :"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(33, 125)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(262, 20)
        Me.Label28.TabIndex = 216
        Me.Label28.Text = "Collector Fund Receipt Order Date :"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(33, 88)
        Me.Label26.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(247, 20)
        Me.Label26.TabIndex = 215
        Me.Label26.Text = "Collector Fund Receipt Order No :"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(33, 50)
        Me.Label25.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(184, 20)
        Me.Label25.TabIndex = 214
        Me.Label25.Text = "Fund Recieved Amount :"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Turquoise
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(414, 397)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(93, 52)
        Me.Button2.TabIndex = 224
        Me.Button2.Text = "Close"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.LightGreen
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(142, 397)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 52)
        Me.Button1.TabIndex = 223
        Me.Button1.Text = "Save "
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Third
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(761, 519)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.datepaycheque)
        Me.Controls.Add(Me.datefundrecorder)
        Me.Controls.Add(Me.datefundcoll)
        Me.Controls.Add(Me.txtvoucher)
        Me.Controls.Add(Me.txtpaycq)
        Me.Controls.Add(Me.txtvidecoll)
        Me.Controls.Add(Me.txtcollfund)
        Me.Controls.Add(Me.txtrcfund)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label25)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "Third"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Third"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents datepaycheque As System.Windows.Forms.DateTimePicker
    Friend WithEvents datefundrecorder As System.Windows.Forms.DateTimePicker
    Friend WithEvents datefundcoll As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtvoucher As System.Windows.Forms.TextBox
    Friend WithEvents txtpaycq As System.Windows.Forms.TextBox
    Friend WithEvents txtvidecoll As System.Windows.Forms.TextBox
    Friend WithEvents txtcollfund As System.Windows.Forms.TextBox
    Friend WithEvents txtrcfund As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
