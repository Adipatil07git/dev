﻿Imports System.Data.OleDb
Imports System.IO
Public Class Application
    Dim mainStatusBar As New StatusBar()
    Dim statusPanel As New StatusBarPanel()
    Dim datetimePanel As New StatusBarPanel()
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"
    Dim con As New OleDbConnection(connectionString)
    Dim da As OleDb.OleDbDataAdapter
    Dim dt As New DataTable
    Dim com As OleDbCommand
    Private Sub Application_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CreateDynamicStatusBar()
        con.Open()
    End Sub
    Private Sub CreateDynamicStatusBar()
        statusPanel.BorderStyle = StatusBarPanelBorderStyle.Sunken
        statusPanel.Text = "Contact : TRIFRND-9511874373."
        statusPanel.ToolTipText = "Last Activity"
        statusPanel.AutoSize = StatusBarPanelAutoSize.Spring
        mainStatusBar.Panels.Add(statusPanel)
        datetimePanel.BorderStyle = StatusBarPanelBorderStyle.Raised
        datetimePanel.ToolTipText = "DateTime: " + System.DateTime.Today.ToString()
        datetimePanel.Text = System.DateTime.Today.ToLongDateString()
        datetimePanel.AutoSize = StatusBarPanelAutoSize.Contents
        mainStatusBar.Panels.Add(datetimePanel)
        mainStatusBar.ShowPanels = True
        Controls.Add(mainStatusBar)
    End Sub
    Private Sub EXITToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EXITToolStripMenuItem.Click
        con.Close()
        'Main.Close()
        Me.Close()
    End Sub
    Private Sub DToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DToolStripMenuItem.Click
        'MLAReport.Show()
    End Sub
    Private Sub HeadWiseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HeadWiseToolStripMenuItem.Click
        HeadRep.Show()
    End Sub
    Private Sub GPWiseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'GPnumber.Show()
    End Sub
    Private Sub EntryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Entry.Show()
    End Sub
    Private Sub FirstToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FirstToolStripMenuItem.Click
    End Sub
    Private Sub ThirdToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Third.Show()
    End Sub
    Private Sub ADMEntryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ADMEntryToolStripMenuItem.Click
        ADMentry.Show()
    End Sub
    Private Sub AccEntryToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AccEntryToolStripMenuItem.Click
        AccEntry.Show()
    End Sub
    Private Sub AddToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddToolStripMenuItem.Click
        MPAdd.Show()
    End Sub
    Private Sub AddToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddToolStripMenuItem1.Click
        EEAdd.Show()
    End Sub
    Private Sub AddToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddToolStripMenuItem2.Click
        DEAdd.Show()
    End Sub
    Private Sub AddToolStripMenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddToolStripMenuItem3.Click
        JrEadd.Show()
    End Sub
    Private Sub AddToolStripMenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddToolStripMenuItem4.Click
        ContractorAdd.Show()
    End Sub

    Private Sub ChangeToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChangeToolStripMenuItem1.Click
        EEChange.Show()
    End Sub

    Private Sub RemoveToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveToolStripMenuItem1.Click
        EERemove.Show()
    End Sub

    Private Sub RemoveToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveToolStripMenuItem2.Click
        DEremove.Show()
    End Sub

    Private Sub RemoveToolStripMenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveToolStripMenuItem3.Click
        JEremove.Show()
    End Sub

    Private Sub ChangeToolStripMenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChangeToolStripMenuItem3.Click
        JEchanges.Show()
    End Sub

    Private Sub ChangeToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChangeToolStripMenuItem2.Click
        DEchange.Show()
    End Sub

    Private Sub ChangeToolStripMenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChangeToolStripMenuItem4.Click
        ContractorChange.Show()
    End Sub

    Private Sub RemoveToolStripMenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveToolStripMenuItem4.Click
        ContractorRem.Show()
    End Sub

    Private Sub ChangeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChangeToolStripMenuItem.Click
        MPChange.Show()

    End Sub

    Private Sub AbstractToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Abstract.Show()

    End Sub

    Private Sub PaidExpenditureToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PaidExpenditureToolStripMenuItem.Click
        'OrderPaid.Show()

        'PaidRep.Show()
    End Sub

    Private Sub ADMEntry2ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ADMEntry2ToolStripMenuItem.Click
        ADM2.Show()
    End Sub

    Private Sub PaymentToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PaymentToolStripMenuItem.Click
        PaymentEntry.Show()
    End Sub

    Private Sub PurchaseToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PurchaseToolStripMenuItem1.Click

        'OrderUnPaid.Show()
    End Sub

    Private Sub AbstractToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Abstract.Show()
    End Sub

    Private Sub OrderwiseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OrderwiseToolStripMenuItem.Click
        'OrderwsieRep.Show()
    End Sub
    Private Sub NidhiVitaranToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        NidhiVitaran.Show()
    End Sub

    Private Sub TenderBalanceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub YearWiseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles YearWiseToolStripMenuItem.Click
        'YearRep.Show()

    End Sub

    Private Sub PaidYearlyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PaidYearlyToolStripMenuItem.Click
        'PaidRep.Show()
    End Sub

    Private Sub UnpaidYearlyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UnpaidYearlyToolStripMenuItem.Click
        'UnpdRep.Show()

    End Sub
End Class