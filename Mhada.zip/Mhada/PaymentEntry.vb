﻿Imports System.Data.OleDb
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Public Class PaymentEntry
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"
    Dim con, con1, con2, con3, con4 As New OleDbConnection(connectionString)
    Dim adapter As New OleDbDataAdapter()
    Dim str, str0, str1, str2, str3, str4 As String
    Dim com, com0, com1, com2, com3, com4 As OleDbCommand
    Dim oledbda As OleDbDataAdapter
    Dim ds, ds1, ds2, ds3, ds4 As DataSet
    Dim dt As New DataTable
    Dim invdt As String
    Dim cmdOLEDB As New OleDbCommand
    Public dr, dr1 As OleDbDataReader
    Dim da As OleDb.OleDbDataAdapter
    Dim totadm, totexp, totbal, totpend, admamt1 As Int64
    Private Sub PaymentEntry_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'ComboPaymode.DropDownStyle = ComboBoxStyle.DropDownList
        'ComboContract.DropDownStyle = ComboBoxStyle.DropDownList
        con.Open()

        str = "select Distinct ADM_No from Testing"
        com = New OleDbCommand(str, con)
        oledbda = New OleDbDataAdapter(com)
        ds = New DataSet
        oledbda.Fill(ds, "Testing")
        ComboADMno.DataSource = ds.Tables("Testing")
        ComboADMno.ValueMember = "ADM_No"
        ComboADMno.DisplayMember = "ADM_No"


    End Sub
    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextAmt.TextChanged
        If IsNumeric(TextAmt.Text) Then
            If Val(TextAmt.Text) <= admamt1 Then
                Exit Sub
            Else
                Dim result = MessageBox.Show("Amount should be less than ADM Amount.", "MHADA")
                TextAmt.Text = ""
                TextAmt.Focus()
            End If
        Else
            TextAmt.Text = ""
            TextAmt.Focus()
        End If
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        str = "update Testing set Cheque_Rtgs_No ='" & TextBox2.Text & "', Cheque_Date = '" & DateTimePicker2.Value & "', Exp_Amt='" & TextAmt.Text & "' where ADM_No = '" & ComboADMno.SelectedValue & "' AND GP_No = '" & ComboGP.SelectedValue & "' "
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            Dim result = MessageBox.Show("Data successfully Saved.", "MHADA")
            'con.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        con.Close()

        Me.Close()

    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        con.Close()
        Me.Close()

    End Sub

    Private Sub ComboADMno_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboADMno.SelectionChangeCommitted
        Dim totadmamt, totfndrec As Int64
        totadmamt = totfndrec = 0

        'ADMamt.Text = ""
        noord1.Text = ""
        noord2.Text = ""
        noord3.Text = ""
        noord4.Text = ""
        dtord1.Text = ""
        dtord2.Text = ""
        dtord3.Text = ""
        dtord4.Text = ""
        chnoord1.Text = ""
        chnoord2.Text = ""
        chnoord3.Text = ""
        chnoord4.Text = ""
        chdtord1.Text = ""
        chdtord2.Text = ""
        chdtord3.Text = ""
        chdtord4.Text = ""
        recamtord1.Text = ""
        recamtord2.Text = ""
        recamtord2.Text = ""
        recamtord3.Text = ""
        recamtord4.Text = ""
        TotRecAmt.Text = ""
        rtgsdt.Text = ""
        rtgsno.Text = ""

        str1 = "select Distinct GP_No from Testing where ADM_No='" & ComboADMno.SelectedValue & "'"
        com1 = New OleDbCommand(str1, con)
        oledbda = New OleDbDataAdapter(com1)
        ds = New DataSet
        oledbda.Fill(ds, "Testing")
        ComboGP.DataSource = ds.Tables("Testing")
        ComboGP.ValueMember = "GP_No"
        ComboGP.DisplayMember = "GP_No"

        
    End Sub

    Private Sub ComboGP_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboGP.SelectedIndexChanged

    End Sub

    Private Sub ComboGP_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboGP.SelectionChangeCommitted
        str2 = "select * from Testing where ADM_No='" & ComboADMno.SelectedValue & "' AND GP_NO='" & ComboGP.SelectedValue & "' "
        com2 = New OleDbCommand(str2, con)
        dr = com2.ExecuteReader
        While dr.Read()

            admamt1 = dr("Adm_Amt").ToString
            rtgsno.Text = dr("Cheque_Rtgs_No").ToString
            rtgsdt.Text = dr("Cheque_Date").ToString
            If Len(rtgsdt.Text) > 10 Then
                rtgsdt.Text = rtgsdt.Text.Substring(0, 10)
            End If

            noord1.Text = dr("Fund_Rec_Order1").ToString
            dtord1.Text = dr("Order1_Date").ToString
            If Len(dtord1.Text) > 10 Then
                dtord1.Text = dtord1.Text.Substring(0, 10)
            End If
            chnoord1.Text = dr("Order1_Cheque_No").ToString
            chdtord1.Text = dr("Order1_Cheque_Date").ToString
            If Len(chdtord1.Text) > 10 Then
                chdtord1.Text = chdtord1.Text.Substring(0, 10)
            End If
            recamtord1.Text = dr("Order1_Rec_Amt").ToString

            noord2.Text = dr("Fund_Rec_Order2").ToString
            dtord2.Text = dr("Order2_Date").ToString
            If Len(dtord2.Text) > 10 Then
                dtord2.Text = dtord2.Text.Substring(0, 10)
            End If
            chnoord2.Text = dr("Order2_Cheque_No").ToString
            chdtord2.Text = dr("Order2_Cheque_Date").ToString
            If Len(chdtord2.Text) > 10 Then
                chdtord2.Text = chdtord2.Text.Substring(0, 10)
            End If
            recamtord2.Text = dr("Order2_Rec_Amt").ToString

            noord3.Text = dr("Fund_Rec_Order3").ToString
            dtord3.Text = dr("Order3_Date").ToString
            If Len(dtord3.Text) > 10 Then
                dtord3.Text = dtord3.Text.Substring(0, 10)
            End If
            chnoord3.Text = dr("Order3_Cheque_No").ToString
            chdtord3.Text = dr("Order3_Cheque_Date").ToString
            If Len(chdtord3.Text) > 10 Then
                chdtord3.Text = chdtord3.Text.Substring(0, 10)
            End If
            recamtord3.Text = dr("Order3_Rec_Amt").ToString

            noord4.Text = dr("Fund_Rec_Order4").ToString
            dtord4.Text = dr("Order4_Date").ToString
            If Len(dtord4.Text) > 10 Then
                dtord4.Text = dtord4.Text.Substring(0, 10)
            End If
            chnoord4.Text = dr("Order4_Cheque_No").ToString
            chdtord4.Text = dr("Order4_Cheque_Date").ToString
            If Len(chdtord4.Text) > 10 Then
                chdtord4.Text = chdtord4.Text.Substring(0, 10)
            End If
            recamtord4.Text = dr("Order4_Rec_Amt").ToString

            TotRecAmt.Text = Val(dr("Order1_Rec_Amt").ToString) + Val(dr("Order2_Rec_Amt").ToString) + Val(dr("Order3_Rec_Amt").ToString) + Val(dr("Order4_Rec_Amt").ToString)
        End While

        str3 = "select * from WorkDetails where ADM_No='" & ComboADMno.SelectedValue & "' AND GP_NO='" & ComboGP.SelectedValue & "' "
        com3 = New OleDbCommand(str3, con)
        dr1 = com3.ExecuteReader
        While dr1.Read()
            Textcontractor.Text = dr1("Contractor_Name").ToString
            TextBillamt.Text = dr1("Tended_Amt").ToString
        End While

    End Sub

    Private Sub ComboADMno_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboADMno.SelectedIndexChanged

    End Sub

    Private Sub TextDed_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextDed.LostFocus
        TextAmt.Text = Val(TextBillamt.Text) - Val(TextDed.Text)

    End Sub

    Private Sub TextDed_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextDed.TextChanged
        If IsNumeric(TextDed.Text) Then
            If Val(TextDed.Text) < Val(TextBillamt.Text) Then
                Exit Sub
            Else
                Dim result = MessageBox.Show("Amount should be less than Tender Amount.", "MHADA")
                TextAmt.Text = 0
                TextAmt.Focus()
            End If
        Else
            TextDed.Text = ""
            TextDed.Focus()
        End If

        TextAmt.Text = Val(TextBillamt.Text) - Val(TextDed.Text)
    End Sub
    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class