﻿Imports System.Data.OleDb
Public Class JrEadd
    Dim con As New OleDbConnection
    Dim cmdOLEDB As New OleDbCommand

    Private Sub AddJrE_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'MhadaDataSet3.JElist' table. You can move, or remove it, as needed.
        Me.JElistTableAdapter.Fill(Me.MhadaDataSet3.JElist)

    End Sub

    Private Sub Button_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_save.Click
        If txtJE.Text = String.Empty Then
            MsgBox("Please Enter Junior Engineer Name.")
            txtJE.Focus()
        Else
            Dim dt As New DataTable
            Dim ds As New DataSet
            con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"

            con.Open()

            cmdOLEDB.CommandText = "Select JE_Name from JElist where JE_Name= '" & txtJE.Text & "'"
            cmdOLEDB.Connection = con
            Dim rdrOLEDB As OleDbDataReader = cmdOLEDB.ExecuteReader

            If rdrOLEDB.Read = True Then
                MsgBox("Junior Engineer already Exit.")
                rdrOLEDB.Close()
                txtJE.Focus()
                txtJE.Text = ""
            Else
                ds.Tables.Add(dt)
                Dim da, da1 As New OleDbDataAdapter
                da = New OleDbDataAdapter("SELECT * FROM JElist", con)
                da.Fill(dt)
                Dim newRow As DataRow = dt.NewRow
                newRow.Item("JE_Name") = txtJE.Text
                newRow.Item("created") = Now()
                newRow.Item("Entry_By") = "Admin"
                dt.Rows.Add(newRow)
                Dim cb As New OleDbCommandBuilder(da)
                da.Update(dt)
                MsgBox("Junior successfully saved.", vbInformation)
                JElistTableAdapter.Fill(MhadaDataSet3.JElist)

                con.Close()
                txtJE.Text = ""
            End If
        End If

    End Sub

    Private Sub Button_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Exit.Click
        con.Close()
        Me.Close()

    End Sub
End Class