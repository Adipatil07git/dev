﻿Imports System.Data.OleDb
Public Class JEremove
    Public dr As OleDbDataReader
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"
    Dim con As New OleDbConnection(connectionString)
    Dim adapter As New OleDbDataAdapter()
    Dim str As String
    Dim com As OleDbCommand
    Dim oledbda As OleDbDataAdapter
    Dim ds As DataSet
    Dim dt As New DataTable
    Private Sub JEremove_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboName.DropDownStyle = ComboBoxStyle.DropDownList
        con.Open()
        str = "select Distinct JE_Name from JElist"
        com = New OleDbCommand(str, con)
        oledbda = New OleDbDataAdapter(com)
        ds = New DataSet
        oledbda.Fill(ds, "JElist")
        ComboName.DataSource = ds.Tables("JElist")
        ComboName.ValueMember = "JE_Name"
        ComboName.DisplayMember = "JE_Name"

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        com = New OleDbCommand("delete from JElist where JE_Name = ComboName.selectedvalue ", con)
        com.Parameters.AddWithValue("JE_Name", ComboName.SelectedValue)
        com.ExecuteNonQuery()
        MsgBox("Record Successfuly Deleted.")
        con.Close()
        Me.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        con.Close()
        Me.Close()

    End Sub
End Class