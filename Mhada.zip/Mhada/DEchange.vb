﻿Imports System.Data.OleDb
Public Class DEchange
    Public dr As OleDbDataReader
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"
    Dim con As New OleDbConnection(connectionString)
    Dim adapter As New OleDbDataAdapter()
    Dim str As String
    Dim com As OleDbCommand
    Dim oledbda As OleDbDataAdapter
    Dim ds As DataSet
    Dim dt As New DataTable

    Private Sub DEchange_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboName.DropDownStyle = ComboBoxStyle.DropDownList
        con.Open()
        str = "select Distinct DE_Name from DElist"
        com = New OleDbCommand(str, con)
        oledbda = New OleDbDataAdapter(com)
        ds = New DataSet
        oledbda.Fill(ds, "DElist")
        ComboName.DataSource = ds.Tables("DElist")
        ComboName.ValueMember = "DE_Name"
        ComboName.DisplayMember = "DE_Name"

    End Sub

    Private Sub ComboName_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboName.SelectionChangeCommitted
        str = "SELECT * from DElist where DE_Name = '" & ComboName.SelectedValue & "' "
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        dr = cmd.ExecuteReader
        While dr.Read()
            TextDE.Text = dr("DE_Name").ToString
        End While
    End Sub
    Private Sub Button_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_save.Click
        str = "update DElist set DE_Name ='" & TextDE.Text & "', Entry_By = 'New',  created = ' " & Now() & "' where DE_Name = '" & ComboName.SelectedValue & "' "
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            MsgBox("Executive Engineer Name Updated.")
            'con.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        TextDE.Text = ""
        con.Close()
    End Sub
    Private Sub Button_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Exit.Click
        con.Close()
        Me.Close()

    End Sub
End Class