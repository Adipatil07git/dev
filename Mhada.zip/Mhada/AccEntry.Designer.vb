﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AccEntry
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.ComboADMno = New System.Windows.Forms.ComboBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.chdtord1 = New System.Windows.Forms.TextBox
        Me.TotRecAmt = New System.Windows.Forms.TextBox
        Me.dtord1 = New System.Windows.Forms.TextBox
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.recamtord4 = New System.Windows.Forms.TextBox
        Me.recamtord3 = New System.Windows.Forms.TextBox
        Me.recamtord2 = New System.Windows.Forms.TextBox
        Me.chdtord4 = New System.Windows.Forms.TextBox
        Me.chdtord3 = New System.Windows.Forms.TextBox
        Me.chdtord2 = New System.Windows.Forms.TextBox
        Me.rtgsdt = New System.Windows.Forms.TextBox
        Me.chnoord4 = New System.Windows.Forms.TextBox
        Me.rtgsno = New System.Windows.Forms.TextBox
        Me.chnoord3 = New System.Windows.Forms.TextBox
        Me.Label30 = New System.Windows.Forms.Label
        Me.chnoord2 = New System.Windows.Forms.TextBox
        Me.dtord4 = New System.Windows.Forms.TextBox
        Me.Label29 = New System.Windows.Forms.Label
        Me.dtord3 = New System.Windows.Forms.TextBox
        Me.dtord2 = New System.Windows.Forms.TextBox
        Me.noord4 = New System.Windows.Forms.TextBox
        Me.noord3 = New System.Windows.Forms.TextBox
        Me.noord2 = New System.Windows.Forms.TextBox
        Me.recamtord1 = New System.Windows.Forms.TextBox
        Me.chnoord1 = New System.Windows.Forms.TextBox
        Me.noord1 = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.ComboGP = New System.Windows.Forms.ComboBox
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.Label14 = New System.Windows.Forms.Label
        Me.TextFdRec = New System.Windows.Forms.TextBox
        Me.TextExp = New System.Windows.Forms.TextBox
        Me.TextADM = New System.Windows.Forms.TextBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.BalFund = New System.Windows.Forms.TextBox
        Me.FundDemand = New System.Windows.Forms.TextBox
        Me.TextFDemand = New System.Windows.Forms.TextBox
        Me.TextBFund = New System.Windows.Forms.TextBox
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.TextFRec = New System.Windows.Forms.TextBox
        Me.TextBillPass = New System.Windows.Forms.TextBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.TenderBal = New System.Windows.Forms.TextBox
        Me.BillPaid = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.TextTend = New System.Windows.Forms.TextBox
        Me.TextEx = New System.Windows.Forms.TextBox
        Me.TextAmtadm = New System.Windows.Forms.TextBox
        Me.ComboAdmYr = New System.Windows.Forms.ComboBox
        Me.LabelH3 = New System.Windows.Forms.Label
        Me.ComboHdNm = New System.Windows.Forms.ComboBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.ComboDiv = New System.Windows.Forms.ComboBox
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Turquoise
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(586, 632)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(76, 43)
        Me.Button2.TabIndex = 27
        Me.Button2.Text = "Close"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.LightGreen
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(278, 632)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(80, 43)
        Me.Button1.TabIndex = 26
        Me.Button1.Text = "Submit"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'ComboADMno
        '
        Me.ComboADMno.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboADMno.FormattingEnabled = True
        Me.ComboADMno.Location = New System.Drawing.Point(126, 78)
        Me.ComboADMno.Name = "ComboADMno"
        Me.ComboADMno.Size = New System.Drawing.Size(187, 26)
        Me.ComboADMno.Sorted = True
        Me.ComboADMno.TabIndex = 4
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(27, 78)
        Me.Label7.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 18)
        Me.Label7.TabIndex = 249
        Me.Label7.Text = "ADM No :"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.chdtord1)
        Me.Panel1.Controls.Add(Me.TotRecAmt)
        Me.Panel1.Controls.Add(Me.dtord1)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.recamtord4)
        Me.Panel1.Controls.Add(Me.recamtord3)
        Me.Panel1.Controls.Add(Me.recamtord2)
        Me.Panel1.Controls.Add(Me.chdtord4)
        Me.Panel1.Controls.Add(Me.chdtord3)
        Me.Panel1.Controls.Add(Me.chdtord2)
        Me.Panel1.Controls.Add(Me.rtgsdt)
        Me.Panel1.Controls.Add(Me.chnoord4)
        Me.Panel1.Controls.Add(Me.rtgsno)
        Me.Panel1.Controls.Add(Me.chnoord3)
        Me.Panel1.Controls.Add(Me.Label30)
        Me.Panel1.Controls.Add(Me.chnoord2)
        Me.Panel1.Controls.Add(Me.dtord4)
        Me.Panel1.Controls.Add(Me.Label29)
        Me.Panel1.Controls.Add(Me.dtord3)
        Me.Panel1.Controls.Add(Me.dtord2)
        Me.Panel1.Controls.Add(Me.noord4)
        Me.Panel1.Controls.Add(Me.noord3)
        Me.Panel1.Controls.Add(Me.noord2)
        Me.Panel1.Controls.Add(Me.recamtord1)
        Me.Panel1.Controls.Add(Me.chnoord1)
        Me.Panel1.Controls.Add(Me.noord1)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Location = New System.Drawing.Point(57, 410)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(844, 216)
        Me.Panel1.TabIndex = 250
        '
        'chdtord1
        '
        Me.chdtord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chdtord1.Location = New System.Drawing.Point(591, 43)
        Me.chdtord1.MaxLength = 10
        Me.chdtord1.Name = "chdtord1"
        Me.chdtord1.Size = New System.Drawing.Size(87, 26)
        Me.chdtord1.TabIndex = 9
        '
        'TotRecAmt
        '
        Me.TotRecAmt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TotRecAmt.Location = New System.Drawing.Point(701, 176)
        Me.TotRecAmt.Name = "TotRecAmt"
        Me.TotRecAmt.ReadOnly = True
        Me.TotRecAmt.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TotRecAmt.Size = New System.Drawing.Size(124, 26)
        Me.TotRecAmt.TabIndex = 275
        '
        'dtord1
        '
        Me.dtord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtord1.Location = New System.Drawing.Point(221, 44)
        Me.dtord1.MaxLength = 10
        Me.dtord1.Name = "dtord1"
        Me.dtord1.Size = New System.Drawing.Size(106, 26)
        Me.dtord1.TabIndex = 7
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Location = New System.Drawing.Point(85, 10)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(740, 24)
        Me.Panel2.TabIndex = 251
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(28, 3)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Number"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(160, 3)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Date"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(310, 2)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 20)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Cheque No"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(637, 3)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(79, 20)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Rec. Amt."
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(493, 2)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(104, 20)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Cheque Date"
        '
        'recamtord4
        '
        Me.recamtord4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.recamtord4.Location = New System.Drawing.Point(701, 144)
        Me.recamtord4.Name = "recamtord4"
        Me.recamtord4.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.recamtord4.Size = New System.Drawing.Size(124, 26)
        Me.recamtord4.TabIndex = 25
        '
        'recamtord3
        '
        Me.recamtord3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.recamtord3.Location = New System.Drawing.Point(701, 111)
        Me.recamtord3.Name = "recamtord3"
        Me.recamtord3.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.recamtord3.Size = New System.Drawing.Size(124, 26)
        Me.recamtord3.TabIndex = 20
        '
        'recamtord2
        '
        Me.recamtord2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.recamtord2.Location = New System.Drawing.Point(701, 78)
        Me.recamtord2.Name = "recamtord2"
        Me.recamtord2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.recamtord2.Size = New System.Drawing.Size(124, 26)
        Me.recamtord2.TabIndex = 15
        '
        'chdtord4
        '
        Me.chdtord4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chdtord4.Location = New System.Drawing.Point(591, 144)
        Me.chdtord4.MaxLength = 9
        Me.chdtord4.Name = "chdtord4"
        Me.chdtord4.Size = New System.Drawing.Size(87, 26)
        Me.chdtord4.TabIndex = 24
        '
        'chdtord3
        '
        Me.chdtord3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chdtord3.Location = New System.Drawing.Point(591, 111)
        Me.chdtord3.MaxLength = 9
        Me.chdtord3.Name = "chdtord3"
        Me.chdtord3.Size = New System.Drawing.Size(87, 26)
        Me.chdtord3.TabIndex = 19
        '
        'chdtord2
        '
        Me.chdtord2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chdtord2.Location = New System.Drawing.Point(591, 78)
        Me.chdtord2.MaxLength = 10
        Me.chdtord2.Name = "chdtord2"
        Me.chdtord2.Size = New System.Drawing.Size(87, 26)
        Me.chdtord2.TabIndex = 14
        '
        'rtgsdt
        '
        Me.rtgsdt.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtgsdt.Location = New System.Drawing.Point(509, 181)
        Me.rtgsdt.Name = "rtgsdt"
        Me.rtgsdt.ReadOnly = True
        Me.rtgsdt.Size = New System.Drawing.Size(87, 27)
        Me.rtgsdt.TabIndex = 276
        '
        'chnoord4
        '
        Me.chnoord4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chnoord4.Location = New System.Drawing.Point(343, 144)
        Me.chnoord4.Name = "chnoord4"
        Me.chnoord4.Size = New System.Drawing.Size(225, 26)
        Me.chnoord4.TabIndex = 23
        '
        'rtgsno
        '
        Me.rtgsno.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtgsno.Location = New System.Drawing.Point(289, 181)
        Me.rtgsno.Name = "rtgsno"
        Me.rtgsno.ReadOnly = True
        Me.rtgsno.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.rtgsno.Size = New System.Drawing.Size(87, 27)
        Me.rtgsno.TabIndex = 311
        '
        'chnoord3
        '
        Me.chnoord3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chnoord3.Location = New System.Drawing.Point(343, 111)
        Me.chnoord3.Name = "chnoord3"
        Me.chnoord3.Size = New System.Drawing.Size(225, 26)
        Me.chnoord3.TabIndex = 18
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(408, 184)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(78, 19)
        Me.Label30.TabIndex = 7
        Me.Label30.Text = "RTGS Date"
        '
        'chnoord2
        '
        Me.chnoord2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chnoord2.Location = New System.Drawing.Point(343, 78)
        Me.chnoord2.Name = "chnoord2"
        Me.chnoord2.Size = New System.Drawing.Size(225, 26)
        Me.chnoord2.TabIndex = 13
        '
        'dtord4
        '
        Me.dtord4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtord4.Location = New System.Drawing.Point(221, 145)
        Me.dtord4.MaxLength = 9
        Me.dtord4.Name = "dtord4"
        Me.dtord4.Size = New System.Drawing.Size(104, 26)
        Me.dtord4.TabIndex = 22
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(175, 184)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(65, 19)
        Me.Label29.TabIndex = 6
        Me.Label29.Text = "RTGS No"
        '
        'dtord3
        '
        Me.dtord3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtord3.Location = New System.Drawing.Point(221, 110)
        Me.dtord3.MaxLength = 9
        Me.dtord3.Name = "dtord3"
        Me.dtord3.Size = New System.Drawing.Size(104, 26)
        Me.dtord3.TabIndex = 17
        '
        'dtord2
        '
        Me.dtord2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtord2.Location = New System.Drawing.Point(221, 78)
        Me.dtord2.MaxLength = 10
        Me.dtord2.Name = "dtord2"
        Me.dtord2.Size = New System.Drawing.Size(106, 26)
        Me.dtord2.TabIndex = 12
        '
        'noord4
        '
        Me.noord4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.noord4.Location = New System.Drawing.Point(85, 146)
        Me.noord4.Name = "noord4"
        Me.noord4.Size = New System.Drawing.Size(118, 26)
        Me.noord4.TabIndex = 21
        '
        'noord3
        '
        Me.noord3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.noord3.Location = New System.Drawing.Point(85, 111)
        Me.noord3.Name = "noord3"
        Me.noord3.Size = New System.Drawing.Size(118, 26)
        Me.noord3.TabIndex = 16
        '
        'noord2
        '
        Me.noord2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.noord2.Location = New System.Drawing.Point(85, 79)
        Me.noord2.Name = "noord2"
        Me.noord2.Size = New System.Drawing.Size(118, 26)
        Me.noord2.TabIndex = 11
        '
        'recamtord1
        '
        Me.recamtord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.recamtord1.Location = New System.Drawing.Point(701, 44)
        Me.recamtord1.Name = "recamtord1"
        Me.recamtord1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.recamtord1.Size = New System.Drawing.Size(124, 26)
        Me.recamtord1.TabIndex = 10
        '
        'chnoord1
        '
        Me.chnoord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chnoord1.Location = New System.Drawing.Point(343, 44)
        Me.chnoord1.Name = "chnoord1"
        Me.chnoord1.Size = New System.Drawing.Size(225, 26)
        Me.chnoord1.TabIndex = 8
        '
        'noord1
        '
        Me.noord1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.noord1.Location = New System.Drawing.Point(85, 43)
        Me.noord1.Name = "noord1"
        Me.noord1.Size = New System.Drawing.Size(118, 26)
        Me.noord1.TabIndex = 6
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(20, 149)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(63, 20)
        Me.Label11.TabIndex = 9
        Me.Label11.Text = "Order-4"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(20, 114)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(63, 20)
        Me.Label10.TabIndex = 8
        Me.Label10.Text = "Order-3"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(20, 82)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(63, 20)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "Order-2"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(18, 46)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(63, 20)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "Order-1"
        '
        'ComboGP
        '
        Me.ComboGP.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.ComboGP.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.ComboGP.FormattingEnabled = True
        Me.ComboGP.Location = New System.Drawing.Point(179, 372)
        Me.ComboGP.Name = "ComboGP"
        Me.ComboGP.Size = New System.Drawing.Size(242, 28)
        Me.ComboGP.TabIndex = 5
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        Me.DataGridView1.CausesValidation = False
        Me.DataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(469, 78)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(718, 272)
        Me.DataGridView1.TabIndex = 278
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(122, 187)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(121, 23)
        Me.Label14.TabIndex = 291
        Me.Label14.Text = "Fund Received"
        '
        'TextFdRec
        '
        Me.TextFdRec.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextFdRec.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextFdRec.Location = New System.Drawing.Point(301, 185)
        Me.TextFdRec.Name = "TextFdRec"
        Me.TextFdRec.ReadOnly = True
        Me.TextFdRec.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextFdRec.Size = New System.Drawing.Size(100, 24)
        Me.TextFdRec.TabIndex = 290
        '
        'TextExp
        '
        Me.TextExp.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextExp.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextExp.Location = New System.Drawing.Point(301, 161)
        Me.TextExp.Name = "TextExp"
        Me.TextExp.ReadOnly = True
        Me.TextExp.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextExp.Size = New System.Drawing.Size(100, 24)
        Me.TextExp.TabIndex = 289
        '
        'TextADM
        '
        Me.TextADM.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextADM.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextADM.Location = New System.Drawing.Point(301, 131)
        Me.TextADM.Name = "TextADM"
        Me.TextADM.ReadOnly = True
        Me.TextADM.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextADM.Size = New System.Drawing.Size(100, 24)
        Me.TextADM.TabIndex = 287
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(123, 158)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(137, 23)
        Me.Label16.TabIndex = 284
        Me.Label16.Text = "Bill Pass Amount"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(123, 128)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(115, 23)
        Me.Label18.TabIndex = 282
        Me.Label18.Text = "ADM Amount"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(52, 128)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(60, 23)
        Me.Label19.TabIndex = 281
        Me.Label19.Text = "Total  -"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(123, 216)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(105, 23)
        Me.Label12.TabIndex = 292
        Me.Label12.Text = "Bill Paid Amt"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(123, 276)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(154, 23)
        Me.Label20.TabIndex = 293
        Me.Label20.Text = "Pending Work Amt"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(123, 246)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(125, 23)
        Me.Label21.TabIndex = 294
        Me.Label21.Text = "Tender Balance"
        '
        'BalFund
        '
        Me.BalFund.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.BalFund.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BalFund.Location = New System.Drawing.Point(301, 278)
        Me.BalFund.Name = "BalFund"
        Me.BalFund.ReadOnly = True
        Me.BalFund.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.BalFund.Size = New System.Drawing.Size(100, 24)
        Me.BalFund.TabIndex = 295
        '
        'FundDemand
        '
        Me.FundDemand.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.FundDemand.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FundDemand.Location = New System.Drawing.Point(301, 310)
        Me.FundDemand.Name = "FundDemand"
        Me.FundDemand.ReadOnly = True
        Me.FundDemand.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.FundDemand.Size = New System.Drawing.Size(100, 24)
        Me.FundDemand.TabIndex = 296
        '
        'TextFDemand
        '
        Me.TextFDemand.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextFDemand.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextFDemand.Location = New System.Drawing.Point(1113, 600)
        Me.TextFDemand.Name = "TextFDemand"
        Me.TextFDemand.ReadOnly = True
        Me.TextFDemand.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextFDemand.Size = New System.Drawing.Size(100, 24)
        Me.TextFDemand.TabIndex = 308
        Me.TextFDemand.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextFDemand.Visible = False
        '
        'TextBFund
        '
        Me.TextBFund.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBFund.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBFund.Location = New System.Drawing.Point(1113, 561)
        Me.TextBFund.Name = "TextBFund"
        Me.TextBFund.ReadOnly = True
        Me.TextBFund.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextBFund.Size = New System.Drawing.Size(100, 24)
        Me.TextBFund.TabIndex = 307
        Me.TextBFund.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.TextBFund.Visible = False
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(927, 500)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(135, 23)
        Me.Label24.TabIndex = 304
        Me.Label24.Text = "Bill Paid Amount"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(926, 470)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(121, 23)
        Me.Label25.TabIndex = 303
        Me.Label25.Text = "Fund Received"
        '
        'TextFRec
        '
        Me.TextFRec.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextFRec.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextFRec.Location = New System.Drawing.Point(1113, 470)
        Me.TextFRec.Name = "TextFRec"
        Me.TextFRec.ReadOnly = True
        Me.TextFRec.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextFRec.Size = New System.Drawing.Size(100, 24)
        Me.TextFRec.TabIndex = 302
        Me.TextFRec.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBillPass
        '
        Me.TextBillPass.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBillPass.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBillPass.Location = New System.Drawing.Point(1113, 441)
        Me.TextBillPass.Name = "TextBillPass"
        Me.TextBillPass.ReadOnly = True
        Me.TextBillPass.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextBillPass.Size = New System.Drawing.Size(100, 24)
        Me.TextBillPass.TabIndex = 301
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(927, 440)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(137, 23)
        Me.Label26.TabIndex = 299
        Me.Label26.Text = "Bill Pass Amount"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(927, 410)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(115, 23)
        Me.Label27.TabIndex = 298
        Me.Label27.Text = "ADM Amount"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(122, 308)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(177, 23)
        Me.Label28.TabIndex = 309
        Me.Label28.Text = "Amount to be Receive"
        '
        'TenderBal
        '
        Me.TenderBal.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TenderBal.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TenderBal.Location = New System.Drawing.Point(301, 247)
        Me.TenderBal.Name = "TenderBal"
        Me.TenderBal.ReadOnly = True
        Me.TenderBal.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TenderBal.Size = New System.Drawing.Size(100, 24)
        Me.TenderBal.TabIndex = 310
        '
        'BillPaid
        '
        Me.BillPaid.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.BillPaid.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BillPaid.Location = New System.Drawing.Point(301, 218)
        Me.BillPaid.Name = "BillPaid"
        Me.BillPaid.ReadOnly = True
        Me.BillPaid.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.BillPaid.Size = New System.Drawing.Size(100, 24)
        Me.BillPaid.TabIndex = 313
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(925, 530)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(125, 23)
        Me.Label15.TabIndex = 314
        Me.Label15.Text = "Tender Balance"
        '
        'TextTend
        '
        Me.TextTend.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextTend.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextTend.Location = New System.Drawing.Point(1112, 530)
        Me.TextTend.Name = "TextTend"
        Me.TextTend.ReadOnly = True
        Me.TextTend.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextTend.Size = New System.Drawing.Size(100, 24)
        Me.TextTend.TabIndex = 315
        Me.TextTend.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextEx
        '
        Me.TextEx.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextEx.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextEx.Location = New System.Drawing.Point(1113, 498)
        Me.TextEx.Name = "TextEx"
        Me.TextEx.ReadOnly = True
        Me.TextEx.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.TextEx.Size = New System.Drawing.Size(100, 24)
        Me.TextEx.TabIndex = 316
        Me.TextEx.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextAmtadm
        '
        Me.TextAmtadm.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextAmtadm.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextAmtadm.Location = New System.Drawing.Point(1113, 410)
        Me.TextAmtadm.Name = "TextAmtadm"
        Me.TextAmtadm.ReadOnly = True
        Me.TextAmtadm.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextAmtadm.Size = New System.Drawing.Size(100, 24)
        Me.TextAmtadm.TabIndex = 317
        '
        'ComboAdmYr
        '
        Me.ComboAdmYr.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboAdmYr.FormattingEnabled = True
        Me.ComboAdmYr.Location = New System.Drawing.Point(722, 31)
        Me.ComboAdmYr.Name = "ComboAdmYr"
        Me.ComboAdmYr.Size = New System.Drawing.Size(111, 26)
        Me.ComboAdmYr.TabIndex = 3
        '
        'LabelH3
        '
        Me.LabelH3.AutoSize = True
        Me.LabelH3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelH3.Location = New System.Drawing.Point(660, 34)
        Me.LabelH3.Name = "LabelH3"
        Me.LabelH3.Size = New System.Drawing.Size(38, 18)
        Me.LabelH3.TabIndex = 320
        Me.LabelH3.Text = "Year"
        '
        'ComboHdNm
        '
        Me.ComboHdNm.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboHdNm.FormattingEnabled = True
        Me.ComboHdNm.Location = New System.Drawing.Point(127, 31)
        Me.ComboHdNm.Name = "ComboHdNm"
        Me.ComboHdNm.Size = New System.Drawing.Size(154, 26)
        Me.ComboHdNm.TabIndex = 1
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(27, 34)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(87, 18)
        Me.Label13.TabIndex = 318
        Me.Label13.Text = "Head Name"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(366, 32)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(60, 18)
        Me.Label17.TabIndex = 322
        Me.Label17.Text = "Division"
        '
        'ComboDiv
        '
        Me.ComboDiv.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboDiv.FormattingEnabled = True
        Me.ComboDiv.Location = New System.Drawing.Point(432, 28)
        Me.ComboDiv.Name = "ComboDiv"
        Me.ComboDiv.Size = New System.Drawing.Size(155, 26)
        Me.ComboDiv.TabIndex = 2
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(26, 376)
        Me.Label31.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(149, 20)
        Me.Label31.TabIndex = 324
        Me.Label31.Text = "GP/MLA Serail  No :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(930, 600)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(177, 23)
        Me.Label1.TabIndex = 326
        Me.Label1.Text = "Amount to be Receive"
        Me.Label1.Visible = False
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(927, 565)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(154, 23)
        Me.Label32.TabIndex = 325
        Me.Label32.Text = "Pending Work Amt"
        Me.Label32.Visible = False
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker1.Location = New System.Drawing.Point(171, 702)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(106, 26)
        Me.DateTimePicker1.TabIndex = 312
        Me.DateTimePicker1.Value = New Date(2024, 1, 17, 10, 12, 49, 0)
        '
        'AccEntry
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1248, 749)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.ComboDiv)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.ComboAdmYr)
        Me.Controls.Add(Me.LabelH3)
        Me.Controls.Add(Me.ComboHdNm)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.TextAmtadm)
        Me.Controls.Add(Me.TextEx)
        Me.Controls.Add(Me.TextTend)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.BillPaid)
        Me.Controls.Add(Me.TenderBal)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.TextFDemand)
        Me.Controls.Add(Me.TextBFund)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.TextFRec)
        Me.Controls.Add(Me.TextBillPass)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.FundDemand)
        Me.Controls.Add(Me.BalFund)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.TextFdRec)
        Me.Controls.Add(Me.TextExp)
        Me.Controls.Add(Me.TextADM)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.ComboGP)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.ComboADMno)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "AccEntry"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Details"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ComboADMno As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents chnoord1 As System.Windows.Forms.TextBox
    Friend WithEvents noord1 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents recamtord1 As System.Windows.Forms.TextBox
    Friend WithEvents noord4 As System.Windows.Forms.TextBox
    Friend WithEvents noord3 As System.Windows.Forms.TextBox
    Friend WithEvents noord2 As System.Windows.Forms.TextBox
    Friend WithEvents recamtord4 As System.Windows.Forms.TextBox
    Friend WithEvents recamtord3 As System.Windows.Forms.TextBox
    Friend WithEvents recamtord2 As System.Windows.Forms.TextBox
    Friend WithEvents chdtord4 As System.Windows.Forms.TextBox
    Friend WithEvents chdtord3 As System.Windows.Forms.TextBox
    Friend WithEvents chdtord2 As System.Windows.Forms.TextBox
    Friend WithEvents chnoord4 As System.Windows.Forms.TextBox
    Friend WithEvents chnoord3 As System.Windows.Forms.TextBox
    Friend WithEvents chnoord2 As System.Windows.Forms.TextBox
    Friend WithEvents dtord4 As System.Windows.Forms.TextBox
    Friend WithEvents dtord3 As System.Windows.Forms.TextBox
    Friend WithEvents dtord2 As System.Windows.Forms.TextBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents ComboGP As System.Windows.Forms.ComboBox
    Friend WithEvents TotRecAmt As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TextFdRec As System.Windows.Forms.TextBox
    Friend WithEvents TextExp As System.Windows.Forms.TextBox
    Friend WithEvents TextADM As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents BalFund As System.Windows.Forms.TextBox
    Friend WithEvents FundDemand As System.Windows.Forms.TextBox
    Friend WithEvents TextFDemand As System.Windows.Forms.TextBox
    Friend WithEvents TextBFund As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents TextFRec As System.Windows.Forms.TextBox
    Friend WithEvents TextBillPass As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents TenderBal As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents rtgsno As System.Windows.Forms.TextBox
    Friend WithEvents BillPaid As System.Windows.Forms.TextBox
    Friend WithEvents rtgsdt As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TextTend As System.Windows.Forms.TextBox
    Friend WithEvents TextEx As System.Windows.Forms.TextBox
    Friend WithEvents TextAmtadm As System.Windows.Forms.TextBox
    Friend WithEvents ComboAdmYr As System.Windows.Forms.ComboBox
    Friend WithEvents LabelH3 As System.Windows.Forms.Label
    Friend WithEvents ComboHdNm As System.Windows.Forms.ComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents ComboDiv As System.Windows.Forms.ComboBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents chdtord1 As System.Windows.Forms.TextBox
    Friend WithEvents dtord1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
End Class
