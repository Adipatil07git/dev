﻿Imports System.Data.OleDb
Public Class ContractorAdd
    Dim con As New OleDbConnection
    Dim cmdOLEDB As New OleDbCommand

    Private Sub AddContractor_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'MhadaDataSet6.Contractor_List' table. You can move, or remove it, as needed.
        Me.Contractor_ListTableAdapter.Fill(Me.MhadaDataSet6.Contractor_List)

    End Sub

    Private Sub Button_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_save.Click
        If TextName.Text = String.Empty Then
            MsgBox("Please Enter Contractor Name.")
            TextName.Focus()
        Else
            Dim dt As New DataTable
            Dim ds As New DataSet
            con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"

            con.Open()

            cmdOLEDB.CommandText = "Select Agency_Name from Contractor_List where Agency_Name= '" & TextName.Text & "'"
            cmdOLEDB.Connection = con
            Dim rdrOLEDB As OleDbDataReader = cmdOLEDB.ExecuteReader

            If rdrOLEDB.Read = True Then
                MsgBox("Contractor already Exit.")
                rdrOLEDB.Close()
                TextName.Focus()
                TextName.Text = ""
            Else
                ds.Tables.Add(dt)
                Dim da, da1 As New OleDbDataAdapter
                da = New OleDbDataAdapter("SELECT * FROM Contractor_List", con)
                da.Fill(dt)
                Dim newRow As DataRow = dt.NewRow
                newRow.Item("Agency_Name") = TextName.Text
                newRow.Item("Ag_PAN_No") = TextPan.Text
                newRow.Item("Ag_GST_No") = TextGst.Text
                newRow.Item("Ag_Mobile") = TextMob.Text
                newRow.Item("Ag_Branch_Address") = TextAdd.Text
                newRow.Item("Ag_Phone") = TextPhone.Text
                newRow.Item("Ag_Email") = TextEmail.Text
                newRow.Item("Ag_Bank_Name") = TextBanknm.Text
                newRow.Item("Ag_Acc_No") = TextBankacc.Text
                newRow.Item("Ag_IFSC") = TextBankifsc.Text
                'newRow.Item("  ") = TextBankbranch.Text

                newRow.Item("created") = Now()
                newRow.Item("Entry_By") = "Admin"
                dt.Rows.Add(newRow)
                Dim cb As New OleDbCommandBuilder(da)
                da.Update(dt)
                MsgBox("Contractor successfully saved.", vbInformation)

                Contractor_ListTableAdapter.Fill(MhadaDataSet6.Contractor_List)

                con.Close()
                TextName.Text = ""
                TextAdd.Text = ""
                TextEmail.Text = ""
                TextGst.Text = ""
                TextMob.Text = ""
                TextPan.Text = ""
                TextPhone.Text = ""
                TextBankacc.Text = ""
                TextBanknm.Text = ""
                TextBankifsc.Text = ""


            End If
        End If

    End Sub
    Private Sub TextMob_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextMob.TextChanged
        If IsNumeric(TextMob.Text) Then
            Exit Sub
        Else
            TextMob.Text = ""
            TextMob.Focus()
        End If

    End Sub

    Private Sub TextPhone_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextPhone.TextChanged
        If IsNumeric(TextPhone.Text) Then
            Exit Sub
        Else
            TextPhone.Text = ""
            TextPhone.Focus()
        End If

    End Sub

    Private Sub Button_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Exit.Click
        con.Close()
        Me.Close()

    End Sub
End Class