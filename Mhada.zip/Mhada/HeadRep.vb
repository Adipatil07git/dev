﻿Imports System.Data.OleDb
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Public Class HeadRep
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"
    Dim con As New OleDbConnection(connectionString)
    Dim adapter As New OleDbDataAdapter()
    Dim str, str1, str2, str3, str4 As String
    Dim com, com1, com2, com3, com4 As OleDbCommand
    Dim oledbda As OleDbDataAdapter
    Dim ds, ds1, ds2, ds3, ds4 As DataSet
    Dim dt As New DataTable
    Dim invdt As String
    Public dr As OleDbDataReader
    Dim da As OleDb.OleDbDataAdapter
    Dim paidcount, unpaidcount, cowto, cowfrom, canc, cancamt, cowamt As Integer
    Dim totadm, totexp, totbal, totpend, totfdrec, billpd, billunpd, totPendWorkamt, totTend, cowtoFndamt, cowtoADMamt, cowfromFndamt, cowfromADMamt As Int64
    Private Sub HeadRep_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboHead.DropDownStyle = ComboBoxStyle.DropDownList
        ComboDiv.DropDownStyle = ComboBoxStyle.DropDownList
        ComboYr.DropDownStyle = ComboBoxStyle.DropDownList
        ComboADM.DropDownStyle = ComboBoxStyle.DropDownList
        ComboMP.DropDownStyle = ComboBoxStyle.DropDownList

        con.Open()
        str = "select Distinct Fund_Name from Testing"
        com = New OleDbCommand(str, con)
        oledbda = New OleDbDataAdapter(com)
        ds = New DataSet
        oledbda.Fill(ds, "Testing")
        ComboHead.DataSource = ds.Tables("Testing")
        ComboHead.ValueMember = "Fund_Name"
        ComboHead.DisplayMember = "Fund_Name"

        With Me.DataGridView1
            .Columns.Add("ADM No.", "ADM No.")
            .Columns.Add("ADM Date", "ADM Date")
            .Columns.Add("Name of Work", "Name of Work")
            .Columns.Add("ADM Amount", "ADM Amount")

            .Columns.Add("Order1 Rec No", "Order1 Rec No")
            .Columns.Add("Order2 Rec No", "Order2 Rec No")
            .Columns.Add("Order3 Rec No", "Order3 Rec No")
            .Columns.Add("Order4 Rec No", "Order4 Rec No")

            .Columns.Add("Tot Fund Rec", "Tot Fund Rec")

            .Columns.Add("Work Expend. Amt", "Work Expend. Amt")
            .Columns.Add("Tender Bal. Amt", "Tender Bal. Amt")
            .Columns.Add("Pending Work Amt", "Pending Work Amt")
            .AllowUserToAddRows = False
            .EditMode = DataGridViewEditMode.EditProgrammatically
        End With

        DataGridView1.Columns(0).Width = 90
        DataGridView1.Columns(1).Width = 100
        DataGridView1.Columns(2).Width = 220
        DataGridView1.Columns(3).Width = 100
        DataGridView1.Columns(4).Width = 100
        DataGridView1.Columns(5).Width = 100
        DataGridView1.Columns(6).Width = 90
        DataGridView1.Columns(7).Width = 90
        DataGridView1.Columns(8).Width = 90
        DataGridView1.Columns(9).Width = 90
        DataGridView1.Columns(10).Width = 90
        DataGridView1.Columns(11).Width = 90

        DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DataGridView1.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        DataGridView1.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        DataGridView1.Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        DataGridView1.Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        DataGridView1.Columns(8).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DataGridView1.Columns(9).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

        DataGridView1.Columns(10).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
        DataGridView1.Columns(11).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight

        DataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter

        'totadm = totexp = totbal = totpend = paidcount = unpaidcount = 0
        cowamt = cancamt = cowto = cowfrom = canc = totadm = totexp = totbal = totpend = paidcount = unpaidcount = totPendWorkamt = totTend = 0

    End Sub
    Private Sub ComboHead_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboHead.SelectionChangeCommitted
        str1 = "select Distinct Div_Name from Testing where Fund_Name = '" & ComboHead.SelectedValue & "' "
        com1 = New OleDbCommand(str1, con)
        oledbda = New OleDbDataAdapter(com1)
        ds1 = New DataSet
        oledbda.Fill(ds1, "Testing")
        ComboDiv.DataSource = ds1.Tables("Testing")
        ComboDiv.ValueMember = "Div_Name"
        ComboDiv.DisplayMember = "Div_Name"
        CheckBox1.Visible = True
        ComboDiv.Visible = True
        LabelH2.Visible = True


    End Sub
    Private Sub ComboDiv_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboDiv.SelectionChangeCommitted
        str2 = "select Distinct Fund_Dist_Year from Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' "
        com2 = New OleDbCommand(str2, con)
        oledbda = New OleDbDataAdapter(com2)
        ds2 = New DataSet
        oledbda.Fill(ds2, "Testing")
        ComboYr.DataSource = ds2.Tables("Testing")
        ComboYr.ValueMember = "Fund_Dist_Year"
        ComboYr.DisplayMember = "Fund_Dist_Year"

        CheckBox2.Visible = True
        CheckBox5.Visible = True
        CheckBox2.Checked = False
        CheckBox5.Checked = False

        ComboYr.Visible = True
        LabelH3.Visible = True

    End Sub
    Private Sub ComboYr_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboYr.SelectionChangeCommitted
        str3 = "select Distinct ADM_No from Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' AND Fund_Dist_Year = '" & ComboYr.SelectedValue & "' "
        com3 = New OleDbCommand(str3, con)
        oledbda = New OleDbDataAdapter(com3)
        ds3 = New DataSet
        oledbda.Fill(ds3, "Testing")
        ComboADM.DataSource = ds3.Tables("Testing")
        ComboADM.ValueMember = "ADM_No"
        ComboADM.DisplayMember = "ADM_No"

        CheckBox3.Visible = True
        ComboADM.Visible = True
        LabelH4.Visible = True

    End Sub
    Private Sub ComboADM_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboADM.SelectionChangeCommitted
        str4 = "select Distinct MP_MLA_MLC from Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' AND Fund_Dist_Year = '" & ComboYr.SelectedValue & "' AND ADM_No = '" & ComboADM.SelectedValue & "' "
        com4 = New OleDbCommand(str4, con)
        oledbda = New OleDbDataAdapter(com4)
        ds4 = New DataSet
        oledbda.Fill(ds4, "Testing")
        ComboMP.DataSource = ds4.Tables("Testing")
        ComboMP.ValueMember = "MP_MLA_MLC"
        ComboMP.DisplayMember = "MP_MLA_MLC"

        CheckBox4.Visible = True
        ComboMP.Visible = True
        LabelH5.Visible = True

    End Sub
    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            CheckBox2.Visible = False
            CheckBox3.Visible = False
            CheckBox4.Visible = False
            LabelH2.Visible = False
            LabelH3.Visible = False
            LabelH4.Visible = False
            LabelH5.Visible = False
            ComboDiv.Visible = False
            ComboYr.Visible = False
            ComboADM.Visible = False
            ComboMP.Visible = False
            List()
        Else
            ComboDiv.Visible = True
            LabelH2.Visible = True
        End If

    End Sub
    Private Sub CheckBox5_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox5.CheckedChanged
        If CheckBox5.Checked = True Then
            CheckBox2.Visible = False
            CheckBox3.Visible = False
            CheckBox4.Visible = False
            LabelH3.Visible = False
            LabelH4.Visible = False
            LabelH5.Visible = False
            ComboDiv.Visible = False
            ComboADM.Visible = False
            ComboYr.Visible = False
            ComboMP.Visible = False
            List()
        Else
            ComboDiv.Visible = True
            CheckBox3.Visible = True
            CheckBox2.Visible = True

            ComboDiv.Visible = True
            LabelH3.Visible = True
        End If

    End Sub
    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = True Then
            CheckBox5.Visible = False
            CheckBox3.Visible = False
            CheckBox4.Visible = False
            LabelH3.Visible = False
            LabelH4.Visible = False
            LabelH5.Visible = False
            ComboYr.Visible = False
            ComboADM.Visible = False
            ComboMP.Visible = False
            List()
        Else
            CheckBox5.Visible = True

            ComboYr.Visible = True
            LabelH3.Visible = True
        End If

    End Sub
    Private Sub CheckBox3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked = True Then
            LabelH4.Visible = False
            LabelH5.Visible = False
            ComboADM.Visible = False
            ComboMP.Visible = False
            CheckBox4.Visible = False
            List()
        Else
            ComboADM.Visible = True
            LabelH4.Visible = True
        End If

    End Sub
    Private Sub CheckBox4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox4.CheckedChanged
        If CheckBox4.Checked = True Then
            LabelH5.Visible = False
            ComboMP.Visible = False
            List()
        Else
            ComboMP.Visible = True
            LabelH5.Visible = True
        End If

    End Sub
    Public Sub List()
        Dim dt As New DataTable
        DataGridView1.DataMember = Nothing

        If CheckBox1.Checked = True Then
            da = New OleDbDataAdapter("SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' ", con)
            da.Fill(dt)
        ElseIf CheckBox5.Checked = True Then
            da = New OleDbDataAdapter("SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND ( Div_Name = 'EAST' OR Div_Name = 'WEST')", con)
            da.Fill(dt)
        ElseIf CheckBox2.Checked = True Then
            da = New OleDbDataAdapter("SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "'", con)
            da.Fill(dt)
        ElseIf CheckBox3.Checked = True Then
            da = New OleDbDataAdapter("SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' AND Fund_Dist_Year = '" & ComboYr.SelectedValue & "'", con)
            da.Fill(dt)
        ElseIf CheckBox4.Checked = True Then
            da = New OleDbDataAdapter("SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' AND Fund_Dist_Year = '" & ComboYr.SelectedValue & "' AND ADM_No = '" & ComboADM.SelectedValue & "'", con)
            da.Fill(dt)
        Else
            da = New OleDbDataAdapter("SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' AND Fund_Dist_Year = '" & ComboYr.SelectedValue & "' AND ADM_No = '" & ComboADM.SelectedValue & "' AND MP_MLA_MLC = '" & ComboMP.SelectedValue & "' ", con)
            da.Fill(dt)
        End If

        totadm = 0
        totexp = 0
        totbal = 0
        totpend = 0
        totfdrec = 0
        billpd = 0
        billunpd = 0
        paidcount = 0
        unpaidcount = 0
        totPendWorkamt = 0
        totTend = 0
        cowto = 0
        cowfrom = 0
        canc = 0
        cowamt = 0
        cancamt = 0
        cowtoFndamt = 0
        cowtoADMamt = 0
        cowfromFndamt = 0
        cowfromADMamt = 0

        For Each dr As DataRow In dt.Rows
            Me.DataGridView1.Rows.Add()
            With Me.DataGridView1.Rows(Me.DataGridView1.Rows.Count - 1)
                .Cells("ADM No.").Value = dr("ADM_No")
                .Cells("ADM Date").Value = dr("Adm_Date")
                .Cells("Name of work").Value = dr("Work_Name")
                .Cells("ADM Amount").Value = dr("ADM_Amt")

                .Cells("Order1 Rec No").Value = dr("Fund_Rec_Order1")
                .Cells("Order2 Rec No").Value = dr("Fund_Rec_Order2")
                .Cells("Order3 Rec No").Value = dr("Fund_Rec_Order3")
                .Cells("Order4 Rec No").Value = dr("Fund_Rec_Order4")

                .Cells("Tot Fund Rec").Value = dr("Tot_Fund_Rec")

                .Cells("Work Expend. Amt").Value = dr("Exp_Amt")
                .Cells("Tender Bal. Amt").Value = dr("Tender_Bal_Amt")
                .Cells("Pending Work Amt").Value = dr("Pending_Work_Amt")

                totadm = totadm + Val(dr("ADM_Amt").ToString)
                totexp = totexp + Val(dr("Exp_Amt").ToString)

                If Len(dr("Cheque_Rtgs_No").ToString) > 0 Then
                    billpd = billpd + Val(dr("Exp_Amt").ToString)
                    totbal = totbal + Val(dr("Tender_Bal_Amt").ToString)
                    paidcount = paidcount + 1
                Else
                    billunpd = billunpd + Val(dr("Exp_Amt").ToString)
                    unpaidcount = unpaidcount + 1
                End If

                totpend = totpend + Val(dr("Pending_Work_Amt").ToString)
                totfdrec = totfdrec + Val(dr("Tot_Fund_Rec").ToString)

            End With

            If dr("order_status").ToString = "COW" Then
                If Len(dr("cow_to").ToString) > 0 Then
                    cowto = cowto + 1
                    If Val(dr("Tot_Fund_Rec").ToString) > 0 Then
                        cowtoFndamt = cowtoFndamt + Val(dr("Tot_Fund_Rec").ToString)
                    Else
                        cowtoADMamt = cowtoADMamt + Val(dr("ADM_Amt").ToString)
                    End If
                End If

                If Len(dr("cow_from").ToString) > 0 Then
                    cowfrom = cowfrom + 1
                    If Val(dr("Tot_Fund_Rec").ToString) > 0 Then
                        cowfromFndamt = cowfromFndamt + Val(dr("Tot_Fund_Rec").ToString)
                    Else
                        cowfromADMamt = cowfromADMamt + Val(dr("ADM_Amt").ToString)
                    End If
                End If
            End If

            If dr("order_status").ToString = "Cancel" Then
                canc = canc + 1
                If Val(dr("Tot_Fund_Rec").ToString) > 0 Then
                    cancamt = cancamt + Val(dr("Tot_Fund_Rec").ToString)
                Else
                    cancamt = cancamt + Val(dr("ADM_Amt").ToString)
                End If
            End If

  
        Next

        TextCanc.Text = canc
        TextCancAmt.Text = cancamt

        TextCowTo.Text = cowto
        TextCowToAmt.Text = cowtoADMamt

        TextCowFrom.Text = cowfrom
        TextCowFrAmt.Text = cowfromADMamt

        TextADM.Text = totadm
        TextExp.Text = totexp
        TextFdRec.Text = totfdrec
        TextBillPd.Text = billpd
        TextBal.Text = totbal

        TextBilUnPd.Text = Val(TextFdRec.Text) - Val(TextBillPd.Text) - Val(TextBal.Text)
        TextPend.Text = Val(TextADM.Text) - Val(TextFdRec.Text)
        TextNoPd.Text = paidcount
        TextNoUnPd.Text = unpaidcount
        TextTotNo.Text = Val(paidcount) + Val(unpaidcount)

        con.Close()

    End Sub
    Private Sub ComboBox5_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboMP.SelectionChangeCommitted

        List()

    End Sub
    Private Sub Btn_View_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_View.Click
        'str = "select * from Testing where Fund_Name = '" & ComboBox1.SelectedValue & "' AND Div_Name = '" & ComboBox2.SelectedValue & "' AND Fund_Dist_Year = '" & ComboBox3.SelectedValue & "' AND ADM_No = '" & ComboBox4.SelectedValue & "' AND MP_MLA_MLC = '" & ComboBox5.SelectedValue & "' "

        If CheckBox1.Checked = True Then
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "'  "
            Label7.Text = "All Divisions"
        ElseIf CheckBox5.Checked = True Then
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND ( Div_Name = 'EAST' OR Div_Name = 'WEST')"
            Label7.Text = "EAST & WEST"
        ElseIf CheckBox2.Checked = True Then
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' "
            Label7.Text = ComboDiv.SelectedValue.ToString
        ElseIf CheckBox3.Checked = True Then
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' AND Fund_Dist_Year = '" & ComboYr.SelectedValue & "' "
            Label7.Text = ComboDiv.SelectedValue.ToString + ", Year - " + ComboYr.SelectedValue.ToString
        ElseIf CheckBox4.Checked = True Then
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' AND Fund_Dist_Year = '" & ComboYr.SelectedValue & "' AND ADM_No = '" & ComboADM.SelectedValue & "' "
            Label7.Text = ComboDiv.SelectedValue.ToString + ", Year - " + ComboYr.SelectedValue.ToString + ", ADM - " + ComboADM.SelectedValue.ToString
        ElseIf Len(ComboMP.SelectedValue) > 0 Then
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' AND Fund_Dist_Year = '" & ComboYr.SelectedValue & "' AND ADM_No = '" & ComboADM.SelectedValue & "' AND MP_MLA_MLC = '" & ComboMP.SelectedValue & "' "
            Label7.Text = ComboDiv.SelectedValue.ToString + ", Year-" + ComboYr.SelectedValue.ToString + ", ADM-" + ComboADM.SelectedValue.ToString + ", MP/MLA-" + ComboMP.SelectedValue.ToString
        End If

        Dim dscmd As New OleDbDataAdapter(str, con)
        Dim ds As New DataSet
        dscmd.Fill(ds, "Testing")

        Dim rptDoc As CrystalDecisions.CrystalReports.Engine.ReportDocument
        Dim user As String = "Admin"
        Dim pwd As String = "apms"

        rptDoc = New Head_rep
        rptDoc.SetDatabaseLogon(user, pwd)
        rptDoc.SetDataSource(ds.Tables(0))
        rptDoc.SetDataSource(ds)

        rptDoc.SetParameterValue(0, TextBillPd.Text)
        rptDoc.SetParameterValue(1, TextBilUnPd.Text)
        rptDoc.SetParameterValue(2, TextBal.Text)
        rptDoc.SetParameterValue(3, TextPend.Text)
        rptDoc.SetParameterValue(4, TextNoPd.Text)
        rptDoc.SetParameterValue(5, TextNoUnPd.Text)
        rptDoc.SetParameterValue(6, TextTotNo.Text)
        rptDoc.SetParameterValue(7, Label7.Text)

        report.CrystalReportViewer1.ReportSource = rptDoc
        report.ShowDialog()
        con.Close()
        Me.Close()
    End Sub
    Private Sub Btn_Print_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Print.Click

        If CheckBox1.Checked = True Then
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "'  "
        ElseIf CheckBox5.Checked = True Then
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND ( Div_Name = 'EAST' OR Div_Name = 'WEST')"
            da.Fill(dt)
        ElseIf CheckBox2.Checked = True Then
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' "
        ElseIf CheckBox3.Checked = True Then
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' AND Fund_Dist_Year = '" & ComboYr.SelectedValue & "' "
        ElseIf CheckBox4.Checked = True Then
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' AND Fund_Dist_Year = '" & ComboYr.SelectedValue & "' AND ADM_No = '" & ComboADM.SelectedValue & "' "
        Else
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' AND Fund_Dist_Year = '" & ComboYr.SelectedValue & "' AND ADM_No = '" & ComboADM.SelectedValue & "' AND MP_MLA_MLC = '" & ComboMP.SelectedValue & "' "
        End If

        Dim dscmd As New OleDbDataAdapter(str, con)
        Dim ds As New DataSet
        dscmd.Fill(ds, "Testing")

        Dim rptDoc As CrystalDecisions.CrystalReports.Engine.ReportDocument
        Dim user As String = "Admin"
        Dim pwd As String = "apms"

        rptDoc = New Head_rep
        rptDoc.SetDatabaseLogon(user, pwd)
        rptDoc.SetDataSource(ds.Tables(0))
        rptDoc.SetDataSource(ds)

        rptDoc.SetParameterValue(0, TextBillPd.Text)
        rptDoc.SetParameterValue(1, TextBilUnPd.Text)
        rptDoc.SetParameterValue(2, TextBal.Text)
        rptDoc.SetParameterValue(3, TextPend.Text)
        rptDoc.SetParameterValue(4, TextNoPd.Text)
        rptDoc.SetParameterValue(5, TextNoUnPd.Text)
        rptDoc.SetParameterValue(6, TextTotNo.Text)
        rptDoc.SetParameterValue(7, Label7.Text)

        rptDoc.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.PaperA4
        rptDoc.PrintOptions.PaperOrientation = CrystalDecisions.Shared.PaperOrientation.Portrait
        rptDoc.PrintToPrinter(1, False, 0, 0)

        con.Close()
        Me.Close()

    End Sub
    Private Sub Btn_Pdf_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Pdf.Click
        If CheckBox1.Checked = True Then
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "'  "
        ElseIf CheckBox5.Checked = True Then
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND ( Div_Name = 'EAST' OR Div_Name = 'WEST')"
            da.Fill(dt)
        ElseIf CheckBox2.Checked = True Then
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' "
        ElseIf CheckBox3.Checked = True Then
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' AND Fund_Dist_Year = '" & ComboYr.SelectedValue & "' "
        ElseIf CheckBox4.Checked = True Then
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' AND Fund_Dist_Year = '" & ComboYr.SelectedValue & "' AND ADM_No = '" & ComboADM.SelectedValue & "' "
        Else
            str = "SELECT * FROM Testing where Fund_Name = '" & ComboHead.SelectedValue & "' AND Div_Name = '" & ComboDiv.SelectedValue & "' AND Fund_Dist_Year = '" & ComboYr.SelectedValue & "' AND ADM_No = '" & ComboADM.SelectedValue & "' AND MP_MLA_MLC = '" & ComboMP.SelectedValue & "' "
        End If

        Dim dscmd As New OleDbDataAdapter(str, con)
        Dim ds As New DataSet
        dscmd.Fill(ds, "NGMPS60")

        Dim rptDoc As CrystalDecisions.CrystalReports.Engine.ReportDocument
        Dim user As String = "Admin"
        Dim pwd As String = "apms"

        rptDoc = New Head_rep
        rptDoc.SetDatabaseLogon(user, pwd)
        rptDoc.SetDataSource(ds.Tables(0))
        rptDoc.SetDataSource(ds)

        rptDoc.SetParameterValue(0, TextBillPd.Text)
        rptDoc.SetParameterValue(1, TextBilUnPd.Text)
        rptDoc.SetParameterValue(2, TextBal.Text)
        rptDoc.SetParameterValue(3, TextPend.Text)
        rptDoc.SetParameterValue(4, TextNoPd.Text)
        rptDoc.SetParameterValue(5, TextNoUnPd.Text)
        rptDoc.SetParameterValue(6, TextTotNo.Text)
        rptDoc.SetParameterValue(7, Label7.Text)

        CType(rptDoc, ReportDocument).ExportToDisk(ExportFormatType.PortableDocFormat, "D:\AllPDF\Report Headwise -" & ComboHead.SelectedValue.ToString.Trim & ".pdf")

        MsgBox("PDF file of Bill is successfully save on D Drive." + " - D:\AllPDF\Headwise Report-" & ComboHead.SelectedValue.ToString.Trim & ".pdf", vbInformation)
        con.Close()
        Me.Close()

    End Sub

    Private Sub Btn_close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_close.Click
        con.Close()
        Me.Close()
    End Sub

 
  
    Private Sub ComboDiv_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboDiv.SelectedIndexChanged

    End Sub
End Class