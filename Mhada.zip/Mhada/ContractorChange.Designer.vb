﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ContractorChange
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ComboName = New System.Windows.Forms.ComboBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Button_Exit = New System.Windows.Forms.Button
        Me.Button_save = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.TextPhone = New System.Windows.Forms.TextBox
        Me.TextEmail = New System.Windows.Forms.TextBox
        Me.TextGst = New System.Windows.Forms.TextBox
        Me.TextPan = New System.Windows.Forms.TextBox
        Me.TextMob = New System.Windows.Forms.TextBox
        Me.TextAdd = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.TextName = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.TextBankifsc = New System.Windows.Forms.TextBox
        Me.TextBankacc = New System.Windows.Forms.TextBox
        Me.TextBanknm = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'ComboName
        '
        Me.ComboName.FormattingEnabled = True
        Me.ComboName.Location = New System.Drawing.Point(153, 75)
        Me.ComboName.Name = "ComboName"
        Me.ComboName.Size = New System.Drawing.Size(297, 28)
        Me.ComboName.TabIndex = 121
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Monotype Corsiva", 24.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(349, 3)
        Me.Label8.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(284, 39)
        Me.Label8.TabIndex = 120
        Me.Label8.Text = "Contractor  Updation"
        '
        'Button_Exit
        '
        Me.Button_Exit.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Button_Exit.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Exit.Location = New System.Drawing.Point(512, 539)
        Me.Button_Exit.Margin = New System.Windows.Forms.Padding(7, 9, 7, 9)
        Me.Button_Exit.Name = "Button_Exit"
        Me.Button_Exit.Size = New System.Drawing.Size(76, 44)
        Me.Button_Exit.TabIndex = 119
        Me.Button_Exit.Text = "Close"
        Me.Button_Exit.UseVisualStyleBackColor = False
        '
        'Button_save
        '
        Me.Button_save.BackColor = System.Drawing.Color.PaleGreen
        Me.Button_save.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_save.Location = New System.Drawing.Point(207, 539)
        Me.Button_save.Margin = New System.Windows.Forms.Padding(7, 9, 7, 9)
        Me.Button_save.Name = "Button_save"
        Me.Button_save.Size = New System.Drawing.Size(91, 44)
        Me.Button_save.TabIndex = 118
        Me.Button_save.Text = "Update"
        Me.Button_save.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(31, 78)
        Me.Label2.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 20)
        Me.Label2.TabIndex = 117
        Me.Label2.Text = "Select  :"
        '
        'TextPhone
        '
        Me.TextPhone.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextPhone.Location = New System.Drawing.Point(661, 127)
        Me.TextPhone.Margin = New System.Windows.Forms.Padding(7)
        Me.TextPhone.MaxLength = 15
        Me.TextPhone.Name = "TextPhone"
        Me.TextPhone.Size = New System.Drawing.Size(193, 26)
        Me.TextPhone.TabIndex = 129
        '
        'TextEmail
        '
        Me.TextEmail.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextEmail.Location = New System.Drawing.Point(152, 282)
        Me.TextEmail.Margin = New System.Windows.Forms.Padding(7)
        Me.TextEmail.MaxLength = 50
        Me.TextEmail.Name = "TextEmail"
        Me.TextEmail.Size = New System.Drawing.Size(170, 26)
        Me.TextEmail.TabIndex = 128
        '
        'TextGst
        '
        Me.TextGst.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextGst.Location = New System.Drawing.Point(152, 241)
        Me.TextGst.Margin = New System.Windows.Forms.Padding(7)
        Me.TextGst.MaxLength = 15
        Me.TextGst.Name = "TextGst"
        Me.TextGst.Size = New System.Drawing.Size(171, 26)
        Me.TextGst.TabIndex = 127
        '
        'TextPan
        '
        Me.TextPan.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextPan.Location = New System.Drawing.Point(153, 203)
        Me.TextPan.Margin = New System.Windows.Forms.Padding(7)
        Me.TextPan.MaxLength = 10
        Me.TextPan.Name = "TextPan"
        Me.TextPan.Size = New System.Drawing.Size(170, 26)
        Me.TextPan.TabIndex = 126
        '
        'TextMob
        '
        Me.TextMob.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextMob.Location = New System.Drawing.Point(153, 165)
        Me.TextMob.Margin = New System.Windows.Forms.Padding(7)
        Me.TextMob.MaxLength = 10
        Me.TextMob.Name = "TextMob"
        Me.TextMob.Size = New System.Drawing.Size(170, 26)
        Me.TextMob.TabIndex = 125
        '
        'TextAdd
        '
        Me.TextAdd.Location = New System.Drawing.Point(661, 165)
        Me.TextAdd.MaxLength = 250
        Me.TextAdd.Multiline = True
        Me.TextAdd.Name = "TextAdd"
        Me.TextAdd.Size = New System.Drawing.Size(332, 112)
        Me.TextAdd.TabIndex = 130
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(486, 127)
        Me.Label7.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(55, 20)
        Me.Label7.TabIndex = 137
        Me.Label7.Text = "Phone"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(35, 285)
        Me.Label6.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(74, 20)
        Me.Label6.TabIndex = 136
        Me.Label6.Text = "E-Mail ID"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(486, 171)
        Me.Label5.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(68, 20)
        Me.Label5.TabIndex = 135
        Me.Label5.Text = "Address"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(35, 247)
        Me.Label4.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(66, 20)
        Me.Label4.TabIndex = 134
        Me.Label4.Text = "GST No"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(35, 209)
        Me.Label3.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 20)
        Me.Label3.TabIndex = 133
        Me.Label3.Text = "PAN No"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(35, 171)
        Me.Label9.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(79, 20)
        Me.Label9.TabIndex = 132
        Me.Label9.Text = "Mobile No"
        '
        'TextName
        '
        Me.TextName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextName.Location = New System.Drawing.Point(152, 124)
        Me.TextName.Margin = New System.Windows.Forms.Padding(7)
        Me.TextName.MaxLength = 30
        Me.TextName.Name = "TextName"
        Me.TextName.ReadOnly = True
        Me.TextName.Size = New System.Drawing.Size(287, 26)
        Me.TextName.TabIndex = 124
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(35, 133)
        Me.Label10.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(51, 20)
        Me.Label10.TabIndex = 131
        Me.Label10.Text = "Name"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(31, 429)
        Me.Label12.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(118, 20)
        Me.Label12.TabIndex = 140
        Me.Label12.Text = "Bank IFS Code"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(31, 389)
        Me.Label11.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(101, 20)
        Me.Label11.TabIndex = 139
        Me.Label11.Text = "Bank Acc No"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(31, 340)
        Me.Label1.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 20)
        Me.Label1.TabIndex = 138
        Me.Label1.Text = "Bank Name"
        '
        'TextBankifsc
        '
        Me.TextBankifsc.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextBankifsc.Location = New System.Drawing.Point(153, 426)
        Me.TextBankifsc.Margin = New System.Windows.Forms.Padding(7)
        Me.TextBankifsc.MaxLength = 10
        Me.TextBankifsc.Name = "TextBankifsc"
        Me.TextBankifsc.Size = New System.Drawing.Size(170, 26)
        Me.TextBankifsc.TabIndex = 143
        '
        'TextBankacc
        '
        Me.TextBankacc.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextBankacc.Location = New System.Drawing.Point(153, 383)
        Me.TextBankacc.Margin = New System.Windows.Forms.Padding(7)
        Me.TextBankacc.MaxLength = 15
        Me.TextBankacc.Name = "TextBankacc"
        Me.TextBankacc.Size = New System.Drawing.Size(170, 26)
        Me.TextBankacc.TabIndex = 142
        '
        'TextBanknm
        '
        Me.TextBanknm.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextBanknm.Location = New System.Drawing.Point(152, 337)
        Me.TextBanknm.Margin = New System.Windows.Forms.Padding(7)
        Me.TextBanknm.MaxLength = 30
        Me.TextBanknm.Name = "TextBanknm"
        Me.TextBanknm.Size = New System.Drawing.Size(171, 26)
        Me.TextBanknm.TabIndex = 141
        '
        'ContractorChange
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1005, 615)
        Me.Controls.Add(Me.TextBankifsc)
        Me.Controls.Add(Me.TextBankacc)
        Me.Controls.Add(Me.TextBanknm)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextPhone)
        Me.Controls.Add(Me.TextEmail)
        Me.Controls.Add(Me.TextGst)
        Me.Controls.Add(Me.TextPan)
        Me.Controls.Add(Me.TextMob)
        Me.Controls.Add(Me.TextAdd)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TextName)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.ComboName)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Button_Exit)
        Me.Controls.Add(Me.Button_save)
        Me.Controls.Add(Me.Label2)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ContractorChange"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ContractorChange"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ComboName As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Button_Exit As System.Windows.Forms.Button
    Friend WithEvents Button_save As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextPhone As System.Windows.Forms.TextBox
    Friend WithEvents TextEmail As System.Windows.Forms.TextBox
    Friend WithEvents TextGst As System.Windows.Forms.TextBox
    Friend WithEvents TextPan As System.Windows.Forms.TextBox
    Friend WithEvents TextMob As System.Windows.Forms.TextBox
    Friend WithEvents TextAdd As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TextName As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBankifsc As System.Windows.Forms.TextBox
    Friend WithEvents TextBankacc As System.Windows.Forms.TextBox
    Friend WithEvents TextBanknm As System.Windows.Forms.TextBox
End Class
