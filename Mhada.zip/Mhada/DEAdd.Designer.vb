﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DEAdd
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Button_Exit = New System.Windows.Forms.Button
        Me.Button_save = New System.Windows.Forms.Button
        Me.txtDE = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.MhadaDataSet1 = New Mhada.mhadaDataSet1
        Me.DElistBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DElistTableAdapter = New Mhada.mhadaDataSet1TableAdapters.DElistTableAdapter
        Me.DENameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Label9 = New System.Windows.Forms.Label
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MhadaDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DElistBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button_Exit
        '
        Me.Button_Exit.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Button_Exit.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Exit.Location = New System.Drawing.Point(339, 234)
        Me.Button_Exit.Margin = New System.Windows.Forms.Padding(7, 9, 7, 9)
        Me.Button_Exit.Name = "Button_Exit"
        Me.Button_Exit.Size = New System.Drawing.Size(72, 46)
        Me.Button_Exit.TabIndex = 96
        Me.Button_Exit.Text = "Close"
        Me.Button_Exit.UseVisualStyleBackColor = False
        '
        'Button_save
        '
        Me.Button_save.BackColor = System.Drawing.Color.PaleGreen
        Me.Button_save.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_save.Location = New System.Drawing.Point(124, 234)
        Me.Button_save.Margin = New System.Windows.Forms.Padding(7, 9, 7, 9)
        Me.Button_save.Name = "Button_save"
        Me.Button_save.Size = New System.Drawing.Size(64, 46)
        Me.Button_save.TabIndex = 95
        Me.Button_save.Text = "Save"
        Me.Button_save.UseVisualStyleBackColor = False
        '
        'txtDE
        '
        Me.txtDE.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtDE.Location = New System.Drawing.Point(124, 89)
        Me.txtDE.Margin = New System.Windows.Forms.Padding(7)
        Me.txtDE.MaxLength = 50
        Me.txtDE.Name = "txtDE"
        Me.txtDE.Size = New System.Drawing.Size(287, 26)
        Me.txtDE.TabIndex = 93
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(38, 92)
        Me.Label2.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(51, 20)
        Me.Label2.TabIndex = 94
        Me.Label2.Text = "Name"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Monotype Corsiva", 24.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(172, 0)
        Me.Label8.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(382, 39)
        Me.Label8.TabIndex = 108
        Me.Label8.Text = "Deputy Engineer Entry Form"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DENameDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.DElistBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(489, 86)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(209, 254)
        Me.DataGridView1.TabIndex = 109
        '
        'MhadaDataSet1
        '
        Me.MhadaDataSet1.DataSetName = "mhadaDataSet1"
        Me.MhadaDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DElistBindingSource
        '
        Me.DElistBindingSource.DataMember = "DElist"
        Me.DElistBindingSource.DataSource = Me.MhadaDataSet1
        '
        'DElistTableAdapter
        '
        Me.DElistTableAdapter.ClearBeforeFill = True
        '
        'DENameDataGridViewTextBoxColumn
        '
        Me.DENameDataGridViewTextBoxColumn.DataPropertyName = "DE_Name"
        Me.DENameDataGridViewTextBoxColumn.HeaderText = "DE_Name"
        Me.DENameDataGridViewTextBoxColumn.Name = "DENameDataGridViewTextBoxColumn"
        Me.DENameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial Rounded MT Bold", 15.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(511, 61)
        Me.Label9.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(144, 24)
        Me.Label9.TabIndex = 110
        Me.Label9.Text = "Engineer List"
        '
        'AddDepE
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(744, 421)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Button_Exit)
        Me.Controls.Add(Me.Button_save)
        Me.Controls.Add(Me.txtDE)
        Me.Controls.Add(Me.Label2)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "AddDepE"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AddDepE"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MhadaDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DElistBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button_Exit As System.Windows.Forms.Button
    Friend WithEvents Button_save As System.Windows.Forms.Button
    Friend WithEvents txtDE As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents MhadaDataSet1 As Mhada.mhadaDataSet1
    Friend WithEvents DElistBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DElistTableAdapter As Mhada.mhadaDataSet1TableAdapters.DElistTableAdapter
    Friend WithEvents DENameDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label9 As System.Windows.Forms.Label
End Class
