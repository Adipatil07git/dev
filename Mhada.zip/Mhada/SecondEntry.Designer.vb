﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SecondEntry
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox
        Me.txtgst = New System.Windows.Forms.TextBox
        Me.datecomplete = New System.Windows.Forms.DateTimePicker
        Me.datestart = New System.Windows.Forms.DateTimePicker
        Me.txtpan = New System.Windows.Forms.TextBox
        Me.txtconnm = New System.Windows.Forms.TextBox
        Me.txtagree = New System.Windows.Forms.TextBox
        Me.txtworkkey = New System.Windows.Forms.TextBox
        Me.txttndrdamt = New System.Windows.Forms.TextBox
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.txttndramt = New System.Windows.Forms.TextBox
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'ComboBox3
        '
        Me.ComboBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Items.AddRange(New Object() {"BELOW ", "ABOVE", "AT PAR"})
        Me.ComboBox3.Location = New System.Drawing.Point(548, 24)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(177, 28)
        Me.ComboBox3.TabIndex = 2
        '
        'txtgst
        '
        Me.txtgst.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgst.Location = New System.Drawing.Point(184, 276)
        Me.txtgst.MaxLength = 15
        Me.txtgst.Name = "txtgst"
        Me.txtgst.Size = New System.Drawing.Size(175, 26)
        Me.txtgst.TabIndex = 8
        '
        'datecomplete
        '
        Me.datecomplete.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.datecomplete.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.datecomplete.Location = New System.Drawing.Point(548, 282)
        Me.datecomplete.Name = "datecomplete"
        Me.datecomplete.Size = New System.Drawing.Size(169, 26)
        Me.datecomplete.TabIndex = 10
        Me.datecomplete.Value = New Date(2023, 8, 16, 11, 25, 31, 0)
        '
        'datestart
        '
        Me.datestart.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.datestart.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.datestart.Location = New System.Drawing.Point(548, 223)
        Me.datestart.Name = "datestart"
        Me.datestart.Size = New System.Drawing.Size(169, 26)
        Me.datestart.TabIndex = 9
        Me.datestart.Value = New Date(2023, 8, 16, 11, 25, 31, 0)
        '
        'txtpan
        '
        Me.txtpan.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpan.Location = New System.Drawing.Point(186, 229)
        Me.txtpan.MaxLength = 10
        Me.txtpan.Name = "txtpan"
        Me.txtpan.Size = New System.Drawing.Size(175, 26)
        Me.txtpan.TabIndex = 7
        '
        'txtconnm
        '
        Me.txtconnm.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtconnm.Location = New System.Drawing.Point(183, 190)
        Me.txtconnm.Name = "txtconnm"
        Me.txtconnm.Size = New System.Drawing.Size(175, 26)
        Me.txtconnm.TabIndex = 6
        '
        'txtagree
        '
        Me.txtagree.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtagree.Location = New System.Drawing.Point(182, 151)
        Me.txtagree.Name = "txtagree"
        Me.txtagree.Size = New System.Drawing.Size(175, 26)
        Me.txtagree.TabIndex = 5
        '
        'txtworkkey
        '
        Me.txtworkkey.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtworkkey.Location = New System.Drawing.Point(182, 107)
        Me.txtworkkey.Name = "txtworkkey"
        Me.txtworkkey.Size = New System.Drawing.Size(175, 26)
        Me.txtworkkey.TabIndex = 4
        '
        'txttndrdamt
        '
        Me.txttndrdamt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttndrdamt.Location = New System.Drawing.Point(182, 67)
        Me.txttndrdamt.Name = "txttndrdamt"
        Me.txttndrdamt.Size = New System.Drawing.Size(175, 26)
        Me.txttndrdamt.TabIndex = 3
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(398, 229)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(109, 20)
        Me.Label27.TabIndex = 215
        Me.Label27.Text = "Date of Start :"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(28, 151)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(120, 20)
        Me.Label20.TabIndex = 214
        Me.Label20.Text = "Agreement No :"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(29, 107)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(108, 20)
        Me.Label19.TabIndex = 213
        Me.Label19.Text = "Work Key No :"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(28, 70)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(145, 20)
        Me.Label18.TabIndex = 212
        Me.Label18.Text = "Tendered Amount :"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(398, 30)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(115, 20)
        Me.Label17.TabIndex = 211
        Me.Label17.Text = "Tender Quote :"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(28, 30)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(127, 20)
        Me.Label16.TabIndex = 210
        Me.Label16.Text = "Tender Amount :"
        '
        'txttndramt
        '
        Me.txttndramt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttndramt.Location = New System.Drawing.Point(182, 24)
        Me.txttndramt.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txttndramt.Name = "txttndramt"
        Me.txttndramt.Size = New System.Drawing.Size(175, 26)
        Me.txttndramt.TabIndex = 1
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(27, 282)
        Me.Label29.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(153, 20)
        Me.Label29.TabIndex = 209
        Me.Label29.Text = "Contractor GST No :"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(30, 233)
        Me.Label24.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(148, 20)
        Me.Label24.TabIndex = 206
        Me.Label24.Text = "Contractor PAN No:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(29, 192)
        Me.Label23.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(124, 20)
        Me.Label23.TabIndex = 205
        Me.Label23.Text = "Contract Name :"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(398, 282)
        Me.Label22.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(154, 20)
        Me.Label22.TabIndex = 204
        Me.Label22.Text = "Date of Completion :"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Turquoise
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(525, 370)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(93, 52)
        Me.Button2.TabIndex = 217
        Me.Button2.Text = "Close"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.LightGreen
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(253, 370)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 52)
        Me.Button1.TabIndex = 216
        Me.Button1.Text = "Save "
        Me.Button1.UseVisualStyleBackColor = False
        '
        'SecondEntry
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(791, 453)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ComboBox3)
        Me.Controls.Add(Me.txtgst)
        Me.Controls.Add(Me.datecomplete)
        Me.Controls.Add(Me.datestart)
        Me.Controls.Add(Me.txtpan)
        Me.Controls.Add(Me.txtconnm)
        Me.Controls.Add(Me.txtagree)
        Me.Controls.Add(Me.txtworkkey)
        Me.Controls.Add(Me.txttndrdamt)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.txttndramt)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "SecondEntry"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "SecondEntry"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents txtgst As System.Windows.Forms.TextBox
    Friend WithEvents datecomplete As System.Windows.Forms.DateTimePicker
    Friend WithEvents datestart As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtpan As System.Windows.Forms.TextBox
    Friend WithEvents txtconnm As System.Windows.Forms.TextBox
    Friend WithEvents txtagree As System.Windows.Forms.TextBox
    Friend WithEvents txtworkkey As System.Windows.Forms.TextBox
    Friend WithEvents txttndrdamt As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txttndramt As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
