﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ContractorRem
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextPhone = New System.Windows.Forms.TextBox
        Me.TextEmail = New System.Windows.Forms.TextBox
        Me.TextGst = New System.Windows.Forms.TextBox
        Me.TextPan = New System.Windows.Forms.TextBox
        Me.TextMob = New System.Windows.Forms.TextBox
        Me.TextAdd = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.TextName = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.ComboName = New System.Windows.Forms.ComboBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Button_Exit = New System.Windows.Forms.Button
        Me.Button_save = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'TextPhone
        '
        Me.TextPhone.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextPhone.Location = New System.Drawing.Point(576, 175)
        Me.TextPhone.Margin = New System.Windows.Forms.Padding(7)
        Me.TextPhone.MaxLength = 15
        Me.TextPhone.Name = "TextPhone"
        Me.TextPhone.Size = New System.Drawing.Size(193, 26)
        Me.TextPhone.TabIndex = 148
        '
        'TextEmail
        '
        Me.TextEmail.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextEmail.Location = New System.Drawing.Point(107, 355)
        Me.TextEmail.Margin = New System.Windows.Forms.Padding(7)
        Me.TextEmail.MaxLength = 50
        Me.TextEmail.Name = "TextEmail"
        Me.TextEmail.Size = New System.Drawing.Size(287, 26)
        Me.TextEmail.TabIndex = 147
        '
        'TextGst
        '
        Me.TextGst.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextGst.Location = New System.Drawing.Point(106, 312)
        Me.TextGst.Margin = New System.Windows.Forms.Padding(7)
        Me.TextGst.MaxLength = 15
        Me.TextGst.Name = "TextGst"
        Me.TextGst.Size = New System.Drawing.Size(161, 26)
        Me.TextGst.TabIndex = 146
        '
        'TextPan
        '
        Me.TextPan.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextPan.Location = New System.Drawing.Point(107, 269)
        Me.TextPan.Margin = New System.Windows.Forms.Padding(7)
        Me.TextPan.MaxLength = 10
        Me.TextPan.Name = "TextPan"
        Me.TextPan.Size = New System.Drawing.Size(160, 26)
        Me.TextPan.TabIndex = 145
        '
        'TextMob
        '
        Me.TextMob.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextMob.Location = New System.Drawing.Point(107, 224)
        Me.TextMob.Margin = New System.Windows.Forms.Padding(7)
        Me.TextMob.MaxLength = 10
        Me.TextMob.Name = "TextMob"
        Me.TextMob.Size = New System.Drawing.Size(160, 26)
        Me.TextMob.TabIndex = 144
        '
        'TextAdd
        '
        Me.TextAdd.Location = New System.Drawing.Point(576, 223)
        Me.TextAdd.MaxLength = 250
        Me.TextAdd.Multiline = True
        Me.TextAdd.Name = "TextAdd"
        Me.TextAdd.Size = New System.Drawing.Size(332, 112)
        Me.TextAdd.TabIndex = 149
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(476, 178)
        Me.Label7.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(55, 20)
        Me.Label7.TabIndex = 156
        Me.Label7.Text = "Phone"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(14, 358)
        Me.Label6.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(74, 20)
        Me.Label6.TabIndex = 155
        Me.Label6.Text = "E-Mail ID"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(476, 226)
        Me.Label5.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(68, 20)
        Me.Label5.TabIndex = 154
        Me.Label5.Text = "Address"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(14, 315)
        Me.Label4.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(66, 20)
        Me.Label4.TabIndex = 153
        Me.Label4.Text = "GST No"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(14, 272)
        Me.Label3.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 20)
        Me.Label3.TabIndex = 152
        Me.Label3.Text = "PAN No"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(14, 227)
        Me.Label9.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(79, 20)
        Me.Label9.TabIndex = 151
        Me.Label9.Text = "Mobile No"
        '
        'TextName
        '
        Me.TextName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.TextName.Location = New System.Drawing.Point(106, 175)
        Me.TextName.Margin = New System.Windows.Forms.Padding(7)
        Me.TextName.MaxLength = 30
        Me.TextName.Name = "TextName"
        Me.TextName.ReadOnly = True
        Me.TextName.Size = New System.Drawing.Size(287, 26)
        Me.TextName.TabIndex = 143
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(14, 181)
        Me.Label10.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(51, 20)
        Me.Label10.TabIndex = 150
        Me.Label10.Text = "Name"
        '
        'ComboName
        '
        Me.ComboName.FormattingEnabled = True
        Me.ComboName.Location = New System.Drawing.Point(106, 88)
        Me.ComboName.Name = "ComboName"
        Me.ComboName.Size = New System.Drawing.Size(297, 28)
        Me.ComboName.TabIndex = 142
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Monotype Corsiva", 24.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(339, 0)
        Me.Label8.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(259, 39)
        Me.Label8.TabIndex = 141
        Me.Label8.Text = "Contractor  Remove"
        '
        'Button_Exit
        '
        Me.Button_Exit.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Button_Exit.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Exit.Location = New System.Drawing.Point(495, 455)
        Me.Button_Exit.Margin = New System.Windows.Forms.Padding(7, 9, 7, 9)
        Me.Button_Exit.Name = "Button_Exit"
        Me.Button_Exit.Size = New System.Drawing.Size(76, 44)
        Me.Button_Exit.TabIndex = 140
        Me.Button_Exit.Text = "Close"
        Me.Button_Exit.UseVisualStyleBackColor = False
        '
        'Button_save
        '
        Me.Button_save.BackColor = System.Drawing.Color.Coral
        Me.Button_save.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_save.Location = New System.Drawing.Point(190, 455)
        Me.Button_save.Margin = New System.Windows.Forms.Padding(7, 9, 7, 9)
        Me.Button_save.Name = "Button_save"
        Me.Button_save.Size = New System.Drawing.Size(103, 44)
        Me.Button_save.TabIndex = 139
        Me.Button_save.Text = "Remove"
        Me.Button_save.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(30, 91)
        Me.Label2.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 20)
        Me.Label2.TabIndex = 138
        Me.Label2.Text = "Select  :"
        '
        'ContractorRem
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(932, 543)
        Me.Controls.Add(Me.TextPhone)
        Me.Controls.Add(Me.TextEmail)
        Me.Controls.Add(Me.TextGst)
        Me.Controls.Add(Me.TextPan)
        Me.Controls.Add(Me.TextMob)
        Me.Controls.Add(Me.TextAdd)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TextName)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.ComboName)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Button_Exit)
        Me.Controls.Add(Me.Button_save)
        Me.Controls.Add(Me.Label2)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ContractorRem"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ContractorRem"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextPhone As System.Windows.Forms.TextBox
    Friend WithEvents TextEmail As System.Windows.Forms.TextBox
    Friend WithEvents TextGst As System.Windows.Forms.TextBox
    Friend WithEvents TextPan As System.Windows.Forms.TextBox
    Friend WithEvents TextMob As System.Windows.Forms.TextBox
    Friend WithEvents TextAdd As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TextName As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents ComboName As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Button_Exit As System.Windows.Forms.Button
    Friend WithEvents Button_save As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
