﻿Imports System.Data.OleDb
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Public Class Abstract
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"
    Dim con As New OleDbConnection(connectionString)
    Dim adapter As New OleDbDataAdapter()
    Dim str, str1, STR2 As String
    Dim com, COM1, COM2 As OleDbCommand
    Dim oledbda As OleDbDataAdapter
    Dim ds As DataSet
    Dim dt As New DataTable
    Dim invdt As String
    Public dr As OleDbDataReader
    Dim da As OleDb.OleDbDataAdapter
    Dim rowno As Integer

    Dim totadm, totexp, totbal, totpend As Int64

    Private Sub Abstract_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboBox1.DropDownStyle = ComboBoxStyle.DropDownList
        ComboAdmYr.DropDownStyle = ComboBoxStyle.DropDownList

        con.Open()
        str = "select Distinct Div_Name from alldata"
        com = New OleDbCommand(str, con)
        oledbda = New OleDbDataAdapter(com)
        ds = New DataSet
        oledbda.Fill(ds, "alldata")
        ComboBox1.DataSource = ds.Tables("alldata")
        ComboBox1.ValueMember = "Div_Name"
        ComboBox1.DisplayMember = "Div_Name"

        rowno = 1


    End Sub
    Private Sub ComboBox1_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectionChangeCommitted

        STR2 = "select Distinct ADM_Year from alldata where dIV_Name='" & ComboBox1.SelectedValue & "' "
        com2 = New OleDbCommand(str2, con)
        oledbda = New OleDbDataAdapter(com2)
        ds = New DataSet
        oledbda.Fill(ds, "alldata")
        ComboAdmYr.DataSource = ds.Tables("alldata")
        ComboAdmYr.ValueMember = "ADM_Year"
        ComboAdmYr.DisplayMember = "ADM_Year"




    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub ComboAdmYr_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboAdmYr.SelectedIndexChanged

    End Sub

    Private Sub ComboAdmYr_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboAdmYr.SelectionChangeCommitted
        'Dim names() As String = {"2014-15", "2015-16", "2016-17", "2017-18", "2018-19", "2019-21", "2021-22", "2022-23"}
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
        ListBox3.Items.Clear()
        ListBox4.Items.Clear()
        ListBox5.Items.Clear()
        ListBox6.Items.Clear()
        rowno = 1


        'Label17.Text = ComboBox1.SelectedValue
        Dim dt As New DataTable

        da = New OleDbDataAdapter("SELECT * FROM alldata where Div_Name = '" & ComboBox1.SelectedValue & "' AND ADM_Year='" & ComboAdmYr.SelectedValue & "' ", con)
        da.Fill(dt)

        Dim ADMamt = dt.Compute("SUM(Adm_Amt)", "")
        Dim ExpAmt = Convert.ToInt64(dt.Compute("SUM(Exp_Amt)", ""))
        Dim TenderBalAmt = Convert.ToInt64(dt.Compute("SUM(Tender_Bal_Amt)", ""))
        Dim PendingWorkAmt = Convert.ToInt64(dt.Compute("SUM(Pending_Work_Amt)", ""))

        ListBox1.Items.Add(rowno)
        ListBox2.Items.Add(ComboAdmYr.SelectedValue)
        ListBox3.Items.Add(ADMamt)
        ListBox4.Items.Add(ExpAmt)
        ListBox5.Items.Add(TenderBalAmt)
        ListBox6.Items.Add(PendingWorkAmt)

        rowno = rowno + 1
        ADMamt = ""
        ExpAmt = 0
        TenderBalAmt = 0
        PendingWorkAmt = 0






    End Sub
End Class