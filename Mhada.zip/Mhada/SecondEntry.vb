﻿Public Class SecondEntry

End Class