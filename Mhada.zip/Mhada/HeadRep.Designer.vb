﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HeadRep
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Label1 = New System.Windows.Forms.Label
        Me.LabelH3 = New System.Windows.Forms.Label
        Me.ComboHead = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Btn_Pdf = New System.Windows.Forms.Button
        Me.Btn_View = New System.Windows.Forms.Button
        Me.Btn_Print = New System.Windows.Forms.Button
        Me.Btn_close = New System.Windows.Forms.Button
        Me.LabelH2 = New System.Windows.Forms.Label
        Me.LabelH4 = New System.Windows.Forms.Label
        Me.LabelH5 = New System.Windows.Forms.Label
        Me.ComboDiv = New System.Windows.Forms.ComboBox
        Me.ComboYr = New System.Windows.Forms.ComboBox
        Me.ComboADM = New System.Windows.Forms.ComboBox
        Me.ComboMP = New System.Windows.Forms.ComboBox
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.CheckBox2 = New System.Windows.Forms.CheckBox
        Me.CheckBox3 = New System.Windows.Forms.CheckBox
        Me.CheckBox4 = New System.Windows.Forms.CheckBox
        Me.TextBilUnPd = New System.Windows.Forms.TextBox
        Me.TextBillPd = New System.Windows.Forms.TextBox
        Me.Label50 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.TextFdRec = New System.Windows.Forms.TextBox
        Me.TextExp = New System.Windows.Forms.TextBox
        Me.TextPend = New System.Windows.Forms.TextBox
        Me.TextADM = New System.Windows.Forms.TextBox
        Me.TextBal = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.TextTotNo = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.TextNoUnPd = New System.Windows.Forms.TextBox
        Me.TextNoPd = New System.Windows.Forms.TextBox
        Me.Label40 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.CheckBox5 = New System.Windows.Forms.CheckBox
        Me.TextCowFrAmt = New System.Windows.Forms.TextBox
        Me.TextCowFrom = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.TextCowToAmt = New System.Windows.Forms.TextBox
        Me.TextCancAmt = New System.Windows.Forms.TextBox
        Me.TextCowTo = New System.Windows.Forms.TextBox
        Me.TextCanc = New System.Windows.Forms.TextBox
        Me.Label36 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Cambria", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.Location = New System.Drawing.Point(561, 1)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(267, 32)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "Division wise Report"
        '
        'LabelH3
        '
        Me.LabelH3.AutoSize = True
        Me.LabelH3.Location = New System.Drawing.Point(382, 51)
        Me.LabelH3.Name = "LabelH3"
        Me.LabelH3.Size = New System.Drawing.Size(38, 18)
        Me.LabelH3.TabIndex = 52
        Me.LabelH3.Text = "Year"
        Me.LabelH3.Visible = False
        '
        'ComboHead
        '
        Me.ComboHead.FormattingEnabled = True
        Me.ComboHead.Location = New System.Drawing.Point(17, 72)
        Me.ComboHead.Name = "ComboHead"
        Me.ComboHead.Size = New System.Drawing.Size(128, 26)
        Me.ComboHead.TabIndex = 51
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(31, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(87, 18)
        Me.Label2.TabIndex = 50
        Me.Label2.Text = "Head Name"
        '
        'Btn_Pdf
        '
        Me.Btn_Pdf.BackColor = System.Drawing.Color.LightGreen
        Me.Btn_Pdf.Location = New System.Drawing.Point(211, 551)
        Me.Btn_Pdf.Name = "Btn_Pdf"
        Me.Btn_Pdf.Size = New System.Drawing.Size(80, 35)
        Me.Btn_Pdf.TabIndex = 57
        Me.Btn_Pdf.Text = "PDF"
        Me.Btn_Pdf.UseVisualStyleBackColor = False
        '
        'Btn_View
        '
        Me.Btn_View.BackColor = System.Drawing.Color.LightGreen
        Me.Btn_View.Location = New System.Drawing.Point(56, 551)
        Me.Btn_View.Name = "Btn_View"
        Me.Btn_View.Size = New System.Drawing.Size(80, 35)
        Me.Btn_View.TabIndex = 56
        Me.Btn_View.Text = "View"
        Me.Btn_View.UseVisualStyleBackColor = False
        '
        'Btn_Print
        '
        Me.Btn_Print.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Btn_Print.Location = New System.Drawing.Point(56, 633)
        Me.Btn_Print.Name = "Btn_Print"
        Me.Btn_Print.Size = New System.Drawing.Size(80, 35)
        Me.Btn_Print.TabIndex = 55
        Me.Btn_Print.Text = "Print"
        Me.Btn_Print.UseVisualStyleBackColor = False
        '
        'Btn_close
        '
        Me.Btn_close.BackColor = System.Drawing.Color.NavajoWhite
        Me.Btn_close.Location = New System.Drawing.Point(211, 633)
        Me.Btn_close.Name = "Btn_close"
        Me.Btn_close.Size = New System.Drawing.Size(80, 35)
        Me.Btn_close.TabIndex = 59
        Me.Btn_close.Text = "Close"
        Me.Btn_close.UseVisualStyleBackColor = False
        '
        'LabelH2
        '
        Me.LabelH2.AutoSize = True
        Me.LabelH2.Location = New System.Drawing.Point(193, 48)
        Me.LabelH2.Name = "LabelH2"
        Me.LabelH2.Size = New System.Drawing.Size(60, 18)
        Me.LabelH2.TabIndex = 69
        Me.LabelH2.Text = "Division"
        Me.LabelH2.Visible = False
        '
        'LabelH4
        '
        Me.LabelH4.AutoSize = True
        Me.LabelH4.Location = New System.Drawing.Point(517, 48)
        Me.LabelH4.Name = "LabelH4"
        Me.LabelH4.Size = New System.Drawing.Size(41, 18)
        Me.LabelH4.TabIndex = 70
        Me.LabelH4.Text = "ADM"
        Me.LabelH4.Visible = False
        '
        'LabelH5
        '
        Me.LabelH5.AutoSize = True
        Me.LabelH5.Location = New System.Drawing.Point(706, 48)
        Me.LabelH5.Name = "LabelH5"
        Me.LabelH5.Size = New System.Drawing.Size(77, 18)
        Me.LabelH5.TabIndex = 71
        Me.LabelH5.Text = "MP / MLA "
        Me.LabelH5.Visible = False
        '
        'ComboDiv
        '
        Me.ComboDiv.FormattingEnabled = True
        Me.ComboDiv.Location = New System.Drawing.Point(164, 72)
        Me.ComboDiv.Name = "ComboDiv"
        Me.ComboDiv.Size = New System.Drawing.Size(148, 26)
        Me.ComboDiv.TabIndex = 72
        Me.ComboDiv.Visible = False
        '
        'ComboYr
        '
        Me.ComboYr.FormattingEnabled = True
        Me.ComboYr.Location = New System.Drawing.Point(341, 72)
        Me.ComboYr.Name = "ComboYr"
        Me.ComboYr.Size = New System.Drawing.Size(121, 26)
        Me.ComboYr.TabIndex = 73
        Me.ComboYr.Visible = False
        '
        'ComboADM
        '
        Me.ComboADM.FormattingEnabled = True
        Me.ComboADM.Location = New System.Drawing.Point(481, 72)
        Me.ComboADM.Name = "ComboADM"
        Me.ComboADM.Size = New System.Drawing.Size(121, 26)
        Me.ComboADM.TabIndex = 74
        Me.ComboADM.Visible = False
        '
        'ComboMP
        '
        Me.ComboMP.FormattingEnabled = True
        Me.ComboMP.Location = New System.Drawing.Point(632, 72)
        Me.ComboMP.Name = "ComboMP"
        Me.ComboMP.Size = New System.Drawing.Size(279, 26)
        Me.ComboMP.TabIndex = 75
        Me.ComboMP.Visible = False
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.DataGridView1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.DataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(17, 132)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(1314, 359)
        Me.DataGridView1.TabIndex = 54
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(101, 101)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(42, 22)
        Me.CheckBox1.TabIndex = 76
        Me.CheckBox1.Text = "All"
        Me.CheckBox1.UseVisualStyleBackColor = True
        Me.CheckBox1.Visible = False
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(273, 100)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(42, 22)
        Me.CheckBox2.TabIndex = 77
        Me.CheckBox2.Text = "All"
        Me.CheckBox2.UseVisualStyleBackColor = True
        Me.CheckBox2.Visible = False
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(420, 102)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(42, 22)
        Me.CheckBox3.TabIndex = 78
        Me.CheckBox3.Text = "All"
        Me.CheckBox3.UseVisualStyleBackColor = True
        Me.CheckBox3.Visible = False
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Location = New System.Drawing.Point(558, 101)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(42, 22)
        Me.CheckBox4.TabIndex = 79
        Me.CheckBox4.Text = "All"
        Me.CheckBox4.UseVisualStyleBackColor = True
        Me.CheckBox4.Visible = False
        '
        'TextBilUnPd
        '
        Me.TextBilUnPd.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBilUnPd.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBilUnPd.Location = New System.Drawing.Point(1204, 630)
        Me.TextBilUnPd.Name = "TextBilUnPd"
        Me.TextBilUnPd.ReadOnly = True
        Me.TextBilUnPd.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextBilUnPd.Size = New System.Drawing.Size(100, 22)
        Me.TextBilUnPd.TabIndex = 123
        '
        'TextBillPd
        '
        Me.TextBillPd.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBillPd.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBillPd.Location = New System.Drawing.Point(1204, 581)
        Me.TextBillPd.Name = "TextBillPd"
        Me.TextBillPd.ReadOnly = True
        Me.TextBillPd.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextBillPd.Size = New System.Drawing.Size(100, 22)
        Me.TextBillPd.TabIndex = 122
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(1000, 584)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(124, 20)
        Me.Label50.TabIndex = 120
        Me.Label50.Text = "Bill Paid Amount"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(998, 561)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(155, 20)
        Me.Label8.TabIndex = 119
        Me.Label8.Text = "Total Fund Received"
        '
        'TextFdRec
        '
        Me.TextFdRec.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextFdRec.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextFdRec.Location = New System.Drawing.Point(1204, 561)
        Me.TextFdRec.Name = "TextFdRec"
        Me.TextFdRec.ReadOnly = True
        Me.TextFdRec.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextFdRec.Size = New System.Drawing.Size(100, 22)
        Me.TextFdRec.TabIndex = 118
        '
        'TextExp
        '
        Me.TextExp.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextExp.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextExp.Location = New System.Drawing.Point(1204, 535)
        Me.TextExp.Name = "TextExp"
        Me.TextExp.ReadOnly = True
        Me.TextExp.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextExp.Size = New System.Drawing.Size(100, 22)
        Me.TextExp.TabIndex = 117
        '
        'TextPend
        '
        Me.TextPend.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextPend.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextPend.Location = New System.Drawing.Point(1203, 656)
        Me.TextPend.Name = "TextPend"
        Me.TextPend.ReadOnly = True
        Me.TextPend.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextPend.Size = New System.Drawing.Size(100, 22)
        Me.TextPend.TabIndex = 116
        '
        'TextADM
        '
        Me.TextADM.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextADM.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextADM.Location = New System.Drawing.Point(1204, 510)
        Me.TextADM.Name = "TextADM"
        Me.TextADM.ReadOnly = True
        Me.TextADM.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextADM.Size = New System.Drawing.Size(100, 22)
        Me.TextADM.TabIndex = 115
        '
        'TextBal
        '
        Me.TextBal.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBal.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBal.Location = New System.Drawing.Point(1204, 602)
        Me.TextBal.Name = "TextBal"
        Me.TextBal.ReadOnly = True
        Me.TextBal.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextBal.Size = New System.Drawing.Size(100, 22)
        Me.TextBal.TabIndex = 114
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(1001, 659)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(166, 20)
        Me.Label13.TabIndex = 113
        Me.Label13.Text = "Amount to be Receive"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(999, 535)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(152, 20)
        Me.Label12.TabIndex = 112
        Me.Label12.Text = "Bill Pass Amount Rs"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(998, 607)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(154, 20)
        Me.Label11.TabIndex = 111
        Me.Label11.Text = "Tender Balance Amt"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(999, 510)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(133, 20)
        Me.Label10.TabIndex = 110
        Me.Label10.Text = "ADM Amount Rs."
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(936, 510)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 20)
        Me.Label6.TabIndex = 109
        Me.Label6.Text = "Total  -"
        '
        'TextTotNo
        '
        Me.TextTotNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextTotNo.Location = New System.Drawing.Point(595, 570)
        Me.TextTotNo.Name = "TextTotNo"
        Me.TextTotNo.ReadOnly = True
        Me.TextTotNo.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextTotNo.Size = New System.Drawing.Size(56, 26)
        Me.TextTotNo.TabIndex = 178
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(358, 573)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(133, 20)
        Me.Label5.TabIndex = 177
        Me.Label5.Text = "Total ADM Works"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(357, 542)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(232, 20)
        Me.Label7.TabIndex = 176
        Me.Label7.Text = "Number of UnPaid ADM Works "
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(358, 512)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(211, 20)
        Me.Label9.TabIndex = 175
        Me.Label9.Text = "Number of Paid ADM Works "
        '
        'TextNoUnPd
        '
        Me.TextNoUnPd.Location = New System.Drawing.Point(595, 541)
        Me.TextNoUnPd.Name = "TextNoUnPd"
        Me.TextNoUnPd.ReadOnly = True
        Me.TextNoUnPd.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextNoUnPd.Size = New System.Drawing.Size(56, 24)
        Me.TextNoUnPd.TabIndex = 174
        '
        'TextNoPd
        '
        Me.TextNoPd.Location = New System.Drawing.Point(595, 510)
        Me.TextNoPd.Name = "TextNoPd"
        Me.TextNoPd.ReadOnly = True
        Me.TextNoPd.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextNoPd.Size = New System.Drawing.Size(56, 24)
        Me.TextNoPd.TabIndex = 173
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(1001, 633)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(168, 20)
        Me.Label40.TabIndex = 179
        Me.Label40.Text = "Pending Work Amount"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(52, 704)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(81, 20)
        Me.Label3.TabIndex = 180
        Me.Label3.Text = "Div. Name"
        Me.Label3.Visible = False
        '
        'CheckBox5
        '
        Me.CheckBox5.AutoSize = True
        Me.CheckBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox5.Location = New System.Drawing.Point(164, 99)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(109, 20)
        Me.CheckBox5.TabIndex = 181
        Me.CheckBox5.Text = "East + West"
        Me.CheckBox5.UseVisualStyleBackColor = True
        Me.CheckBox5.Visible = False
        '
        'TextCowFrAmt
        '
        Me.TextCowFrAmt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextCowFrAmt.Location = New System.Drawing.Point(595, 677)
        Me.TextCowFrAmt.Name = "TextCowFrAmt"
        Me.TextCowFrAmt.ReadOnly = True
        Me.TextCowFrAmt.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextCowFrAmt.Size = New System.Drawing.Size(101, 26)
        Me.TextCowFrAmt.TabIndex = 441
        '
        'TextCowFrom
        '
        Me.TextCowFrom.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextCowFrom.Location = New System.Drawing.Point(492, 677)
        Me.TextCowFrom.Name = "TextCowFrom"
        Me.TextCowFrom.ReadOnly = True
        Me.TextCowFrom.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextCowFrom.Size = New System.Drawing.Size(56, 26)
        Me.TextCowFrom.TabIndex = 440
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(357, 677)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(135, 20)
        Me.Label15.TabIndex = 439
        Me.Label15.Text = "No. of COW-From"
        '
        'TextCowToAmt
        '
        Me.TextCowToAmt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextCowToAmt.Location = New System.Drawing.Point(595, 642)
        Me.TextCowToAmt.Name = "TextCowToAmt"
        Me.TextCowToAmt.ReadOnly = True
        Me.TextCowToAmt.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextCowToAmt.Size = New System.Drawing.Size(101, 26)
        Me.TextCowToAmt.TabIndex = 438
        '
        'TextCancAmt
        '
        Me.TextCancAmt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextCancAmt.Location = New System.Drawing.Point(595, 610)
        Me.TextCancAmt.Name = "TextCancAmt"
        Me.TextCancAmt.ReadOnly = True
        Me.TextCancAmt.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextCancAmt.Size = New System.Drawing.Size(101, 26)
        Me.TextCancAmt.TabIndex = 437
        '
        'TextCowTo
        '
        Me.TextCowTo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextCowTo.Location = New System.Drawing.Point(492, 645)
        Me.TextCowTo.Name = "TextCowTo"
        Me.TextCowTo.ReadOnly = True
        Me.TextCowTo.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextCowTo.Size = New System.Drawing.Size(56, 26)
        Me.TextCowTo.TabIndex = 436
        '
        'TextCanc
        '
        Me.TextCanc.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextCanc.Location = New System.Drawing.Point(492, 610)
        Me.TextCanc.Name = "TextCanc"
        Me.TextCanc.ReadOnly = True
        Me.TextCanc.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextCanc.Size = New System.Drawing.Size(56, 26)
        Me.TextCanc.TabIndex = 435
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(358, 648)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(116, 20)
        Me.Label36.TabIndex = 434
        Me.Label36.Text = "No. of COW-To"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(358, 613)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(135, 20)
        Me.Label24.TabIndex = 433
        Me.Label24.Text = "No. Cancel Works"
        '
        'HeadRep
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.Controls.Add(Me.TextCowFrAmt)
        Me.Controls.Add(Me.TextCowFrom)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.TextCowToAmt)
        Me.Controls.Add(Me.TextCancAmt)
        Me.Controls.Add(Me.TextCowTo)
        Me.Controls.Add(Me.TextCanc)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.CheckBox5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label40)
        Me.Controls.Add(Me.TextTotNo)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TextNoUnPd)
        Me.Controls.Add(Me.TextNoPd)
        Me.Controls.Add(Me.TextBilUnPd)
        Me.Controls.Add(Me.TextBillPd)
        Me.Controls.Add(Me.Label50)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TextFdRec)
        Me.Controls.Add(Me.TextExp)
        Me.Controls.Add(Me.TextPend)
        Me.Controls.Add(Me.TextADM)
        Me.Controls.Add(Me.TextBal)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.CheckBox4)
        Me.Controls.Add(Me.CheckBox3)
        Me.Controls.Add(Me.CheckBox2)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.ComboMP)
        Me.Controls.Add(Me.ComboADM)
        Me.Controls.Add(Me.ComboYr)
        Me.Controls.Add(Me.ComboDiv)
        Me.Controls.Add(Me.LabelH5)
        Me.Controls.Add(Me.LabelH4)
        Me.Controls.Add(Me.LabelH2)
        Me.Controls.Add(Me.Btn_close)
        Me.Controls.Add(Me.Btn_Pdf)
        Me.Controls.Add(Me.Btn_View)
        Me.Controls.Add(Me.Btn_Print)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.LabelH3)
        Me.Controls.Add(Me.ComboHead)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "HeadRep"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.Text = "Head wise"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LabelH3 As System.Windows.Forms.Label
    Friend WithEvents ComboHead As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Btn_Pdf As System.Windows.Forms.Button
    Friend WithEvents Btn_View As System.Windows.Forms.Button
    Friend WithEvents Btn_Print As System.Windows.Forms.Button
    Friend WithEvents Btn_close As System.Windows.Forms.Button
    Friend WithEvents LabelH2 As System.Windows.Forms.Label
    Friend WithEvents LabelH4 As System.Windows.Forms.Label
    Friend WithEvents LabelH5 As System.Windows.Forms.Label
    Friend WithEvents ComboDiv As System.Windows.Forms.ComboBox
    Friend WithEvents ComboYr As System.Windows.Forms.ComboBox
    Friend WithEvents ComboADM As System.Windows.Forms.ComboBox
    Friend WithEvents ComboMP As System.Windows.Forms.ComboBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents TextBilUnPd As System.Windows.Forms.TextBox
    Friend WithEvents TextBillPd As System.Windows.Forms.TextBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextFdRec As System.Windows.Forms.TextBox
    Friend WithEvents TextExp As System.Windows.Forms.TextBox
    Friend WithEvents TextPend As System.Windows.Forms.TextBox
    Friend WithEvents TextADM As System.Windows.Forms.TextBox
    Friend WithEvents TextBal As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextTotNo As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TextNoUnPd As System.Windows.Forms.TextBox
    Friend WithEvents TextNoPd As System.Windows.Forms.TextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents CheckBox5 As System.Windows.Forms.CheckBox
    Friend WithEvents TextCowFrAmt As System.Windows.Forms.TextBox
    Friend WithEvents TextCowFrom As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TextCowToAmt As System.Windows.Forms.TextBox
    Friend WithEvents TextCancAmt As System.Windows.Forms.TextBox
    Friend WithEvents TextCowTo As System.Windows.Forms.TextBox
    Friend WithEvents TextCanc As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
End Class
