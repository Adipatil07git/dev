﻿Imports System.Data.OleDb

Public Class ContractorChange
    Public dr As OleDbDataReader
    Dim connectionString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source= D:\Data\mhada.accdb;Jet OLEDB:Database Password=apms;"
    Dim con As New OleDbConnection(connectionString)
    Dim adapter As New OleDbDataAdapter()
    Dim str As String
    Dim com As OleDbCommand
    Dim oledbda As OleDbDataAdapter
    Dim ds As DataSet
    Dim dt As New DataTable
    Private Sub ContractorChange_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboName.DropDownStyle = ComboBoxStyle.DropDownList
        con.Open()
        str = "select Distinct Agency_Name from Contractor_List"
        com = New OleDbCommand(str, con)
        oledbda = New OleDbDataAdapter(com)
        ds = New DataSet
        oledbda.Fill(ds, "Contractor_List")
        ComboName.DataSource = ds.Tables("Contractor_List")
        ComboName.ValueMember = "Agency_Name"
        ComboName.DisplayMember = "Agency_Name"
    End Sub
    Private Sub ComboName_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboName.SelectionChangeCommitted
        str = "SELECT * from Contractor_List where Agency_Name = '" & ComboName.SelectedValue & "' "
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        dr = cmd.ExecuteReader
        While dr.Read()
            TextName.Text = dr("Agency_Name").ToString
            TextPan.Text = dr("Ag_PAN_No").ToString
            TextGst.Text = dr("Ag_GST_No").ToString
            TextAdd.Text = dr("Ag_Branch_Address").ToString
            TextMob.Text = dr("Ag_Mobile").ToString
            TextPhone.Text = dr("Ag_Phone").ToString
            TextEmail.Text = dr("Ag_Email").ToString
            TextBanknm.Text = dr("Ag_Bank_Name")
            TextBankacc.Text = dr("Ag_Acc_No")
            TextBankifsc.Text = dr("Ag_IFSC")

        End While
    End Sub
    Private Sub Button_save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_save.Click
        str = "update Contractor_List set Agency_Name ='" & TextName.Text & "', Ag_PAN_No = '" & TextPan.Text & "', Ag_GST_No = '" & TextGst.Text & "', Ag_Branch_Address = '" & TextAdd.Text & "', Ag_Mobile= '" & TextMob.Text & "', Ag_Phone ='" & TextPhone.Text & "', Ag_Email ='" & TextEmail.Text & "', Ag_Bank_Name ='" & TextBanknm.Text & "',  Ag_Acc_No ='" & TextBankacc.Text & "', Ag_IFSC ='" & TextBankifsc.Text & "', Entry_By = 'New', created = '" & Now() & "' where Agency_Name = '" & ComboName.SelectedValue & "' "
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            MsgBox("Contractor details updated.")
            'con.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        TextName.Text = ""
        TextPan.Text = ""
        TextGst.Text = ""
        TextMob.Text = ""
        TextPhone.Text = ""
        TextEmail.Text = ""
        TextBanknm.Text = ""
        TextBankacc.Text = ""
        TextBankifsc.Text = ""
    End Sub
    Private Sub Button_Exit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Exit.Click
        con.Close()
        Me.Close()
    End Sub

    Private Sub ComboName_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboName.SelectedIndexChanged

    End Sub
End Class